from data_access import KnowledgeBaseDataAcess
from flask import jsonify
import os
from werkzeug.utils import secure_filename
from flask import current_app
from azure.storage.filedatalake import DataLakeServiceClient
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
import gtts
from moviepy.editor import *
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient  
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from spire.doc import *
from spire.doc.common import *
import pandas as pd
import logging
from opencensus.ext.azure.log_exporter import AzureLogHandler

#-----------------------------------------------------------
'''credential = ManagedIdentityCredential()
KEYVAULT_NAME = os.environ['KEYVAULT_NAME']
client = SecretClient(f"https://{KEYVAULT_NAME}.vault.azure.net/",credential)

vector_store_password = client.get_secret("cognetive-service-password")
vector_store_password = vector_store_password.value

vector_store_address = client.get_secret("cognetive-service-endpoint")
vector_store_address = vector_store_address.value

account_key = client.get_secret("ai-knowledge-base-account-key")
account_key = account_key.value
print("account key is",account_key)
instrumentation_key = client.get_secret("application-insights-instrumentation-key")
instrumentation_key = instrumentation_key.value

container_name = os.environ['STORAGE_CONTAINER_NAME']
account_name = os.environ['STORAGE_ACCOUNT_NAME'] '''

#------------------------------------------------------------
container_name = os.environ['STORAGE_CONTAINER_NAME']
account_name = os.environ['STORAGE_ACCOUNT_NAME']
instrumentation_key = os.getenv('Instrumentation_Key')
vector_store_address = os.getenv('cognetive-service-endpoint')
vector_store_password = os.getenv('cognetive-service-password')
api_base = os.getenv('openai-api-base')
openai_api_token = os.getenv('openai-api-token')
account_key = os.getenv('ai-knowledge-base-account-key')
application_token = os.getenv('ai-application-token')

api_type = "azure"
api_version =  "2024-08-01-preview"
region = "eastus"
#---------------remove--------------
#---------------remove--------------

#------------------------------Intializing the client for storage account------------------------------

from datetime import datetime
today = datetime.today()
month = today.month
year=today.year
File_directory = f"Uploaded-files/{year}/month{month}/"
service_url = f"https://{account_name}.dfs.core.windows.net"

service_client = DataLakeServiceClient(account_url=service_url, credential=account_key)
try:
    file_system_client = service_client.create_file_system(file_system=container_name)
except:
    file_system_client = service_client.get_file_system_client(container_name)

Id_directory = "File_ids/"
credential = AzureKeyCredential(vector_store_password)
index_name = "test-indexes"
blob_service_client = BlobServiceClient(account_url=f"https://{account_name}.blob.core.windows.net", credential=account_key)

#------------------------#Intializing the logging-------------------------

logger = logging.getLogger(__name__)
logger.addHandler(AzureLogHandler(
    connection_string=f'InstrumentationKey={instrumentation_key}')
)


ALLOWED_EXTENSIONS = {'pdf', 'docx','doc', 'csv', 'mp3','mp4','wav','xls','xlsx'}

class KnowledgeBaseBusinessLogic:
    #checking the extension only pdf and docx allowed
    @staticmethod
    def __allowed_file(filename):
        return '.' in filename and \
            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

    #checking the extension and on the basis of extension respective function will call 
    @staticmethod
    def __process_document_cases(fileExt, file_path_to_save, filename, file_present, user_role):
        print(f"Processing document cases for extension: {fileExt} with user role: {user_role}")

        if fileExt == 'pdf':
            response = KnowledgeBaseDataAcess.process_pdf(file_path_to_save, filename, file_present, user_role)
            return response
        elif fileExt == 'docx':
            response = KnowledgeBaseDataAcess.process_docx(file_path_to_save, filename, file_present, user_role)
            return response
        elif fileExt == 'doc':
            output = os.path.join(current_app.config['UPLOAD_FOLDER'], "output.docx")
            document = Document()
            input = document.LoadFromFile(file_path_to_save)
            document.SaveToFile(output, FileFormat.Docx2016)
            document.Close()
            response = KnowledgeBaseDataAcess.process_docx(output, filename, file_present, user_role)
            os.remove(output)
            return response
        elif fileExt == 'csv':
            response = KnowledgeBaseDataAcess.process_csv(file_path_to_save, filename, file_present, user_role)
            return response
        elif fileExt in ['xlsx', 'xls']:
            if fileExt == 'xlsx':
                output = os.path.join(current_app.config['UPLOAD_FOLDER'], "output.xlsx")
            else:
                output = os.path.join(current_app.config['UPLOAD_FOLDER'], "output.xls")

            df = pd.read_excel(file_path_to_save, header=0)
            df.to_csv(output, index=False)
            response = KnowledgeBaseDataAcess.process_excel(output, filename, file_present, user_role)
            os.remove(output)
            return response
        else:
            raise AttributeError('Extension is not valid')

        
    #api for getting the files in the admin portal
    @staticmethod
    def getfiles():
        paths = file_system_client.get_paths("Uploaded-files/")
        file={}
        for path in paths:
            file_client = file_system_client.get_file_client(path.name)
            file_size = file_client.get_file_properties()
            byte = file_size.size
            mb = round(byte/(1024 * 1024),2)
            if(mb<1):
                mb = str(round(byte/1024,2))+"KiB"
            elif(mb>1000):
                mb = str(round(byte/(1024 * 1024 * 1024),2))+"GiB"
            else:
                mb=str(mb)+"MiB"
            present_file_date = path.last_modified.strftime("%d-%m-%Y %H:%M:%S")       
            CreatedOn = path.creation_time.strftime("%d-%m-%Y %H:%M:%S")  
            res = path.name.split('/')[-1]
            ext=res.split('.')[-1]
            if((ext=='mp4')or (ext=='mp3') or (ext=='xlsx') or (ext=='pdf') or (ext=='docx') or (ext=='doc') or (ext=='csv') or (ext=='xls')):
                if res in file.keys():
                    continue
                else:
                    file[res] = [{'FileName':res,'LastModifiedOn': present_file_date,'CreatedOn':CreatedOn,'FileType':ext,'FilePath':path.name,'Filesize':mb}]
        return file
    
    #function for deleting the file from storage account and from the cognitive search service
    @staticmethod 
    def deletefiles(filename,filepath,last_update_file):
        
        try:
            if((filename.rsplit('.', 1)[1].lower()=="mp4") or (filename.rsplit('.', 1)[1].lower()=="mp3")):
                try:
                    file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                    download=file_client.download_file()
                    file_client_file = file_system_client.get_file_client(filepath)
                    file_client_file.delete_file() 
                except:
                    dt = datetime.now()
                    current_date = dt.strftime("%d-%m-%Y %H:%M:%S")
                    current_date_time = datetime.strptime(current_date,"%d-%m-%Y %H:%M:%S")
                    file_datetime=datetime.strptime(last_update_file,"%d-%m-%Y %H:%M:%S")
                    delta=current_date_time-file_datetime
                    hours=delta.total_seconds()/3600
                    if(hours<5):
                        return jsonify({'success': False, 'message': 'Please wait the file is under processing'})
                    else:
                        file_client_file = file_system_client.get_file_client(filepath)
                        file_client_file.delete_file() 
                        return jsonify({'success': True, 'message': f"{filename} is deleted"})
            else:
                try: 
                    file_client_file = file_system_client.get_file_client(filepath)
                    file_client_file.delete_file()
                   
                except Exception as e:
                    logger.exception('An error occurred while deleting file: %s', str(e))
                    return jsonify({'success': True, 'message': f"{filename} is deleted"})
                   
                try:
                    file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                    download=file_client.download_file() 
                except:
                    return jsonify({'success': True, 'message': f"{filename} is deleted"})

        except Exception as e:
            logger.exception('An error occurred while deleting file: %s', str(e))
            return jsonify({'success': True, 'message': f"{filename} is deleted"})

        with open("./vector_id.txt", "wb") as my_file:
            my_file.write(download.readall())
            my_file.close()
            file_client.delete_file()
        file = open("vector_id.txt", "r")
        content = file.readlines()
        search_client = SearchClient(vector_store_address,index_name, credential)
        for id in content:
            id = id.replace("\n","")
            print(id)
            search_client.delete_documents(documents=[{"id": id}])
        os.remove('vector_id.txt')
        return jsonify({'success': True, 'message': f"{filename} is deleted"})

    #main function for deleting file
    @staticmethod
    def delete_present_file(filename,filepath,file_datetime):
        try:
            return KnowledgeBaseBusinessLogic.deletefiles(filename,filepath,file_datetime)
        except Exception as e:
            logger.exception('An error occurred while deleting file: %s', str(e))
            # return jsonify({'success': False, 'message': f'{e}'})
    @staticmethod
    def delete_edit_file(filename,filepath,last_update_file):
        
        if((filename.rsplit('.', 1)[1].lower()=="mp4") or (filename.rsplit('.', 1)[1].lower()=="mp3")):
            try:
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                download=file_client.download_file()
                file_client_file = file_system_client.get_file_client(filepath)
                file_client_file.delete_file() 
            except:
                dt = datetime.now()
                current_date = dt.strftime("%d-%m-%Y %H:%M:%S")
                current_date_time = datetime.strptime(current_date,"%d-%m-%Y %H:%M:%S")
                file_datetime=datetime.strptime(last_update_file,"%d-%m-%Y %H:%M:%S")
                delta=current_date_time-file_datetime
                hours=delta.total_seconds()/3600
                if(hours<5):
                    # return jsonify({'success': False, 'message': 'Please wait the file is under processing'})
                    return False
                else:
                    file_client_file = file_system_client.get_file_client(filepath)
                    file_client_file.delete_file() 
                    return True
                    # return jsonify({'success': True, 'message': f"{filename} is deleted"})
        else:
            try: 
                file_client_file = file_system_client.get_file_client(filepath)
                file_client_file.delete_file()
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                download=file_client.download_file() 
            except:
                return False

        with open("./vector_id.txt", "wb") as my_file:
            my_file.write(download.readall())
            my_file.close()
            file_client.delete_file()
        file = open("vector_id.txt", "r")
        content = file.readlines()
        search_client = SearchClient(vector_store_address,index_name, credential)
        for id in content:
            id = id.replace("\n","")
            print(id)
            search_client.delete_documents(documents=[{"id": id}])
        os.remove('vector_id.txt')
        return jsonify({'success': True, 'message': f"{filename} is deleted"})


    #main fucntion for editing file
    @staticmethod
    def editfile(Present_filename,New_filename,Present_filepath,file_datetime):
        try:
            stat = KnowledgeBaseBusinessLogic.delete_edit_file(Present_filename,Present_filepath,file_datetime)
        except Exception as e:
            logger.exception('An error occurred while deleting file for editing file: %s', str(e))
            # return jsonify({'success': False, 'message': f'{e}'})
        print("status is",stat)
        if(stat==False):
            return jsonify({'success': False, 'message': 'Please wait the file is under processing'})
        else:
            return KnowledgeBaseBusinessLogic.processDocument(New_filename)

    #Uploading the document in storage account
    @staticmethod
    def file_exist_check(filename,file_path_to_save):
        
        file_system_client.get_directory_client(f'{File_directory}')
    
        file_system_client.get_directory_client(f'{Id_directory}')

        #checking the file in storage account if present then delete the previous file and upload recent file
        paths = file_system_client.get_paths("Uploaded-files/")
        for path in paths:  
            res = path.name.split('/')[-1]
            filename = filename.replace(" ", "_")
            if(filename==res):
                file_client = file_system_client.get_file_client(path.name)
                file_client.delete_file()

        file_client = file_system_client.get_file_client(f"{File_directory}{filename}")
        with open(file_path_to_save, "rb") as local_file:
            file_client.upload_data(local_file, overwrite=True,connection_timeout=300000)

        #adding the indexes of the respective file that is already present in storage account in vector_id.txt for deleting the vectors from cognitive service.
        paths = file_system_client.get_paths(f'{Id_directory}')
        for path in paths:  
            name = path.name
            res = name.index('/')
            val = name[res:].split('/')[1]
            val = val.rsplit('.', 1)[0]
        
            if (filename==val):
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                download=file_client.download_file() 
                with open("./vector_id.txt", "wb") as my_file:
                    my_file.write(download.readall())
                    my_file.close()
                    file_client.delete_file()
                    return "True"
                    
                        
        return "False"
    
    #function for uploading the file in storage account 
    @staticmethod
    def audio_video_upload(filename,file_path_to_save):
        
        file_system_client.get_directory_client(f'{File_directory}')
        paths = file_system_client.get_paths("Uploaded-files/")
        for path in paths:  
            res = path.name.split('/')[-1]
            filename = filename.replace(" ", "_")
            if(filename==res):
                file_client = file_system_client.get_file_client(path.name)
                file_client.delete_file()
        file_video_dir = f"{File_directory}audio_video_files/"
        try:
            file_system_client.create_directory(f'{file_video_dir}')
        except:
            file_system_client.get_directory_client(f'{file_video_dir}')

        file_client = file_system_client.get_file_client(f"{file_video_dir}{filename}")
        container_client = blob_service_client.get_container_client(container_name)
        with open(file_path_to_save, "rb") as data:
            blob_client = container_client.get_blob_client(f"{file_video_dir}{filename}")
            blob_client.upload_blob(data, overwrite=True,connection_timeout=30000000)

        return "False"

    # Static method to process the document (PDF, DOCX, etc.) or URL
    @staticmethod
    def processDocument(file, user_role):
        try:
            if file and KnowledgeBaseBusinessLogic.__allowed_file(file.filename):
                filename = secure_filename(file.filename)
                extension = filename.rsplit('.', 1)[1].lower()
                file_path_to_save = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path_to_save)

                print(f"File saved at {file_path_to_save}. Extension: {extension}. User roles: {user_role}")

                if extension in ['mp3', 'mp4']:
                    KnowledgeBaseBusinessLogic.audio_video_upload(filename, file_path_to_save)
                    os.remove(file_path_to_save)
                    return jsonify({'success': True, 'message': f'{filename} is uploaded'})

                status = KnowledgeBaseBusinessLogic.file_exist_check(filename, file_path_to_save)
                file_present = "True" if str(status) == "True" else "False"
                response = KnowledgeBaseBusinessLogic.__process_document_cases(extension, file_path_to_save, filename, file_present, user_role)

                os.remove(file_path_to_save)
                return jsonify({'success': True, 'message': 'Vectorstore successfully created', 'summary': response})

            return jsonify({'success': False, 'message': 'File type not supported'})

        except Exception as e:
            logger.exception('An error occurred while uploading document: %s', str(e))
            return jsonify({'success': False, 'message': str(e)})

    #answering the user asked question
    @staticmethod
    def answerAskedQuestion(question, session_id, user_role):
        try:
            # Pass the list of user roles to handle_user_asked_question
            answer = KnowledgeBaseDataAcess.handle_user_asked_question(question, session_id, user_role)
            return answer  # Return the response directly
        except Exception as e:
            logger.exception('An error occurred while asking question: %s', str(e))
            return jsonify({'success': False, 'message': str(e)}), 500