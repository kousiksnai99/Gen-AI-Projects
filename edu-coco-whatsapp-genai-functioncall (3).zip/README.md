# Introduction 
This project is a Flask-based chatbot that integrates with OpenAI's GPT-4 model to handle user interactions, process function calls (e.g., leave applications, claims requests), and manage chat history in a SQL database. The chatbot can dynamically route function calls to external APIs based on predefined configurations.

#Create Virtual Environment:


python -m venv chatbotEnv && source chatbotEnv/bin/activate  # macOS/Linux

python -m venv chatbotEnv && chatbotEnv\Scripts\activate  # Windows
Install Dependencies:


pip install -r requirements.txt
Set Up .env:

echo "OPENAI_API_KEY=your_openai_api_key" > .env
echo "DB_SERVER=sql-edubot-dev.database.windows.net" >> .env
echo "DB_USER=sqladmin" >> .env
echo "DB_PASSWORD=your_db_password" >> .env
echo "DB_NAME=sqldb-edu-coco-dev" >> .env
Run App:


python main_integrated.py
API Endpoint
URL: http://localhost:5000/chat

Method: POST

Body:

json
{
    "session_id": "optional_session_id",
    "user_input": "Your message here"
}
Example
Start Server:


python main_integrated.py
Test with Postman:

URL: http://localhost:5000/chat

Body:

json
{
    "user_input": "I want to apply for leave."
}
Troubleshooting
Database Issues: Check .env credentials.

API Errors: Verify OPENAI_API_KEY.

Function Failures: Ensure external APIs are running.