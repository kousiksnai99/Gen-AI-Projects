# Setup
+ Setup Python environment version `3.10.9`
+ Create Virtual Environment    
    + RUN `python -m venv kbEnv`
    + Activate environment 
+ Run cmd `pip install -r requirements.txt`
+ open .env file and setup all API keys
+ RunApp  `python app.py`


## API Endpoints


+ To Feed the PDF or docx file or excel file
    + [POST] /api/coco/kb/process/document
        + Request Body - 
            ``` 'file' : 'attchment' ```

+ Ask Question to the model
    + [POST] /api/coco/kb/ask-question
        + Request Body - 
            ``` 
            {
                    "question": "ask anything from the document"
                } 
            ```




