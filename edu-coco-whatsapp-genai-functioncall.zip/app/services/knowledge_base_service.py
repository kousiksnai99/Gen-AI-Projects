from flask import jsonify, current_app
from werkzeug.utils import secure_filename
import logging
from app.repositories.knowledge_base_repo import KnowledgeBaseDataAccess
from app.utils.file_utils import save_file_temp
from app.config.settings import ALLOWED_EXTENSIONS

class KnowledgeBaseBusinessLogic:
    @staticmethod
    def allowed_file(filename):
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

    @staticmethod
    def process_document(file):
        try:
            if not KnowledgeBaseBusinessLogic.allowed_file(file.filename):
                return jsonify({'success': False, 'message': 'File type not supported'})

            filename = secure_filename(file.filename)
            extension = filename.rsplit('.', 1)[1].lower()
            file_path = save_file_temp(file, filename)

            logging.info(f"File saved at {file_path}. Extension: {extension}")

            file_present = KnowledgeBaseDataAccess.file_exist_check(filename, file_path)

            if extension == 'pdf':
                response = KnowledgeBaseDataAccess.process_pdf(file_path, filename, file_present)
            elif extension == 'docx':
                response = KnowledgeBaseDataAccess.process_docx(file_path, filename, file_present)

            import os
            os.remove(file_path)
            return jsonify({'success': True, 'message': 'Vectorstore successfully created', 'summary': response})

        except Exception as e:
            logging.error(f"Error processing document: {e}", exc_info=True)
            return jsonify({'success': False, 'message': str(e)})