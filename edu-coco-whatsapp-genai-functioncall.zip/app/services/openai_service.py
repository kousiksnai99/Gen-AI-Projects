import json
import requests
import openai
from urllib.parse import quote
from app.config.settings import get_static_values, OPENAI_CONFIG, PGVECTOR_CONFIG, VECTOR_STORE_TYPE
from flask_caching import Cache
from app.repositories.vector_store import get_vector_store

GPT_MODEL = "gpt-4o-mini"

class DynamicFunctionHandler:
    def __init__(self, cache: Cache):
        self.static_values = get_static_values()
        self.dynamic_enums = self.static_values.get("dynamic_enums", {})
        self.cache = cache

    def fetch_dynamic_enum(self, enum_name, user_id):
        api_config = self.dynamic_enums.get(enum_name, {})
        cache_key = f"{enum_name}_{user_id}" if "{user_id}" in api_config.get("url", "") else enum_name

        cached_data = self.cache.get(cache_key)
        if cached_data is not None:
            return cached_data

        result = self._fetch_dynamic_enum(enum_name, user_id)
        ttl = api_config.get("ttl", 3600)
        self.cache.set(cache_key, result, timeout=ttl)
        return result

    def _fetch_dynamic_enum(self, enum_name, user_id):
        import logging
        logger = logging.getLogger(__name__)
        if enum_name not in self.dynamic_enums:
            logger.error(f"Enum {enum_name} not found in dynamic_enums configuration")
            return []

        api_config = self.dynamic_enums[enum_name]
        url = api_config["url"].replace("{user_id}", str(user_id))

        try:
            response = requests.request(
                method=api_config["method"],
                headers=api_config.get("headers", {}),
                url=url,
                timeout=30
            )

            if response.status_code != 200:
                logger.error(f"API call for {enum_name} failed: {response.status_code} - {response.text}")
                return []

            json_response = response.json()
            response_key = api_config.get("response_key", "")

            # Handle both direct lists and nested 'data' structures
            items = json_response.get("data", json_response) if isinstance(json_response, dict) else json_response

            if not isinstance(items, list):
                logger.error(f"Unexpected response format for {enum_name}: {json_response}")
                return []

            if response_key:
                result = [str(item[response_key]) for item in items if isinstance(item, dict) and response_key in item]
            else:
                result = [str(item) for item in items if isinstance(item, str) and item]

            if not result:
                logger.error(f"No valid enum values extracted for {enum_name}: {json_response}")
                return []

            return result

        except Exception as e:
            logger.error(f"Error fetching dynamic enum {enum_name}: {e}", exc_info=True)
            return []

    def update_functions(self, functions, user_id):
        updated_functions = []
        for func in functions.copy():
            if "parameters" in func and "properties" in func["parameters"]:
                properties = func["parameters"]["properties"]
                for param_name, param_config in properties.items():
                    if "dynamic_enum" in param_config:
                        enum_name = param_config["dynamic_enum"]
                        param_config["enum"] = self.fetch_dynamic_enum(enum_name, user_id)
                        del param_config["dynamic_enum"]
            updated_functions.append(func)
        return updated_functions

def process_function_call(fn_name, arguments):
    import logging
    logger = logging.getLogger(__name__)
    static_values = get_static_values()
    apis = static_values.get("apis", {})
    original_query = arguments.get("query", json.dumps(arguments))
    platform = arguments.get("platform", "Unknown Platform")

    logger.info(f"Processing function call: {fn_name} with arguments: {arguments}")

    if fn_name in apis:
        api_details = apis[fn_name]
        api_url = api_details["url"]
        method = api_details["method"]
        headers = api_details.get("headers", {})

        if "{user_id}" in api_url:
            user_id = arguments.get("userID", "Unknown Number")
            api_url = api_url.replace("{user_id}", str(user_id))
            logger.info(f"Replaced {user_id} in URL: {api_url}")

        if method == "GET":
            response = requests.get(api_url, headers=headers, timeout=30)
        elif method == "POST":
            body = json.dumps(arguments)
            response = requests.post(api_url, headers=headers, data=body, timeout=30)
        else:
            raise ValueError(f"Unsupported method: {method}")

        logger.info(f"API response for {fn_name}: status={response.status_code}, text={response.text}")

        if response.status_code == 200:
            try:
                raw_response = response.json() if response.text else "Request processed successfully."
            except ValueError:
                raw_response = response.text or "No response body."
            return refine_with_llm(raw_response, original_query, fn_name, platform)
        else:
            raw_error = f"Error: {response.status_code} - {response.text or 'No details provided'}"
            return refine_with_llm(raw_error, original_query, fn_name, platform)

    elif fn_name == "search":
        query = arguments["query"]
        logger.info(f"Performing vector search for query: {query}")

        try:
            vector_store = get_vector_store(VECTOR_STORE_TYPE)
            search_results = vector_store.search(query=query, k=5)
            logger.debug(f"Vector search results for '{query}': {search_results}")

            if not search_results:
                raw_response = f"Sorry, I couldn’t find any information for '{query}' in the knowledge base."
            else:
                context = " ".join(search_results)
                raw_response = context if context.strip() else f"No relevant content found for '{query}' in the knowledge base."

            return refine_with_llm(raw_response, query, fn_name, platform)

        except Exception as e:
            logger.error(f"Error in vector search: {e}")
            raw_response = f"Error searching knowledge base: {str(e)}"
            return refine_with_llm(raw_response, query, fn_name, platform)

    else:
        raw_response = f"No API or logic configuration found for function: {fn_name}"
        return refine_with_llm(raw_response, original_query, fn_name, platform)

def refine_with_llm(raw_response, original_query, fn_name, platform):
    import logging
    logger = logging.getLogger(__name__)
    llm_prompt = [
        {
            "role": "system",
            "content": f"You are a helpful assistant. Based on this raw data from the '{fn_name}' function: {raw_response}, provide a concise, {platform}-friendly response. "
                       f"If the data contains status details (e.g., leave type, dates, reason), summarize them clearly for the user. "
                       f"If the data is empty (e.g., [], or no relevant entries), say no requests were found. "
                       f"Use the user's original query '{original_query}' to tailor the response. "
                       f"For WhatsApp, use simple text with *bold* for emphasis where appropriate."
        },
        {"role": "user", "content": original_query}
    ]

    try:
        llm_response = openai.ChatCompletion.create(
            engine=GPT_MODEL,
            model=GPT_MODEL,
            messages=llm_prompt
        )
        refined_content = llm_response["choices"][0]["message"]["content"].replace("**", "*")
        logger.info(f"LLM refined response for {fn_name} on {platform}: {refined_content}")
        return refined_content
    except Exception as e:
        logger.error(f"Error refining with LLM: {e}")
        return raw_response

def chat_completion_request(messages, username, userID, platform, functions=None, function_call="auto", model=GPT_MODEL, cache=None):
    try:
        openai.api_key = OPENAI_CONFIG["OPENAI_API_KEY"]
        openai.api_base = OPENAI_CONFIG["OPENAI_API_BASE"]
        openai.api_type = "azure"
        openai.api_version = "2025-01-01-preview"

        enum_handler = DynamicFunctionHandler(cache)
        updated_functions = enum_handler.update_functions(functions or [], userID)

        response = openai.ChatCompletion.create(
            engine=model,
            messages=messages,
            functions=updated_functions,
            function_call=function_call,
        )

        assistant_message = response["choices"][0]["message"]
        flow_complete = False

        if assistant_message.get("function_call"):
            fn_name = assistant_message["function_call"]["name"]
            arguments = json.loads(assistant_message["function_call"]["arguments"])
            arguments.update({"username": username, "userID": userID, "platform": platform})
            result = process_function_call(fn_name, arguments)
            assistant_message["content"] = result
            flow_complete = True

        response["flow_complete"] = flow_complete
        return response

    except Exception as e:
        return {"error": str(e)}