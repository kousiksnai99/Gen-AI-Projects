from flask import Flask
from flask_cors import CORS
from flask_caching import Cache
import threading
import queue
import logging
from app.config.settings import configure_logging
from app.api.endpoints import register_endpoints

def create_app():
    app = Flask(__name__)
    CORS(app)

    # Configure logging
    configure_logging()

    # Initialize cache
    app.config['CACHE_TYPE'] = 'simple'
    app.config['CACHE_DEFAULT_TIMEOUT'] = 3600
    cache = Cache(app)

    # Queue for write-behind operations to the database
    write_queue = queue.Queue()

    # Background worker to process the queue and write to the database
    def db_write_worker():
        from app.services.database_service import save_chat_to_db
        while True:
            try:
                session_id, user_input, assistant_response = write_queue.get()
                logging.info(f"Writing to DB from queue: Session ID: {session_id}, Input: {user_input}")
                save_chat_to_db(session_id, user_input, assistant_response)
                write_queue.task_done()
            except Exception as e:
                logging.error(f"Error in DB write worker: {e}")

    threading.Thread(target=db_write_worker, daemon=True).start()

    # Register endpoints
    register_endpoints(app, cache, write_queue)

    return app