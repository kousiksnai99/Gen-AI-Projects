+ Setup Python environment version `3.10.9`
+ Create Virtual Environment    
    + RUN `python -m venv kbEnv`
    + Activate environment 
+ Run cmd `pip install -r requirements.txt`
+ open .env file and setup all API keys
+ RunApp  `streamlit run voice_assist.py`


