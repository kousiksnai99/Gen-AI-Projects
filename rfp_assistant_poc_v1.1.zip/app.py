from flask import Flask, request, jsonify, send_file, Response
from flask_cors import CORS, cross_origin
import os
import requests
from extraction_text import Extraction
from werkzeug.utils import secure_filename
from langchain_openai import AzureOpenAIEmbeddings
from azure.identity import ManagedIdentityCredential
from azure.storage.blob import BlobServiceClient, BlobClient
from io import BytesIO
from langchain_community.vectorstores import AzureSearch
from langchain_community.chat_models import AzureChatOpenAI


app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = '/uploads'

# Load the API key and endpoint from environment variables
openai_api_token = os.getenv("openai_api_token")
api_base = os.getenv("api_base")
api_type = "azure"
api_key = os.getenv('AZURE_OPENAI_API_KEY')
endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')

app.embeddingsModel = AzureOpenAIEmbeddings(
    deployment="text-embedding-ada-002",
    model="text-embedding-ada-002",
    chunk_size=1,
    openai_api_key=openai_api_token,
    azure_endpoint=api_base,
    openai_api_type=api_type
)

# Making the temp folder
try:
    path = os.path.dirname(os.path.abspath(__file__))
    upload_folder = os.path.join(path.replace(UPLOAD_FOLDER, ""), "tmp")
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder
except Exception as e:
    print("An error occurred while creating temp folder")
    print("Exception occurred : {}".format(e))

@app.route('/', methods=['GET'])
@cross_origin()
def welcome_to():
    return 'Welcome to RFP Use Case:)'

# API for uploading the document
@app.route('/RFP/document', methods=['POST'])
@cross_origin()
def process_document():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'})
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'})
    if file:
        print("file name is ", file)
        return Extraction.processDocument(file)

# API for getting the list of files
@app.route('/get_files', methods=['GET'])
@cross_origin()
def get_files():
    connect_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    container_name = os.getenv("container_name")
    folder_path = "rfp-assistant-api/Rfp_Files"  # Define the folder path

    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    container_client = blob_service_client.get_container_client(container_name)

    blob_list = container_client.list_blobs(name_starts_with=folder_path)
    files = [blob.name.split('/')[-1] for blob in blob_list if blob.name.lower().endswith('.xlsx')]  # Filter by file extension

    return jsonify({'success': True, 'files': files})

# API for downloading a file
@app.route('/download_file/<filename>', methods=['GET'])
@cross_origin()
def download_file(filename):
    connect_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    container_name = os.getenv("container_name")
    blob_path = f"rfp-assistant-api/Rfp_Files/{filename}"  # Define the full path to the blob

    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_path)

    try:
        download_stream = blob_client.download_blob()
        file_content = download_stream.readall()
        
        # Save the file locally
        local_file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        with open(local_file_path, 'wb') as local_file:
            local_file.write(file_content)

        return send_file(local_file_path, as_attachment=True, download_name=filename)
    except Exception as e:
        return jsonify({'success': False, 'message': 'Failed to download file', 'error': str(e)})

@app.route('/generate_headings', methods=['POST'])
@cross_origin()
def generate_headings():
    data = request.get_json()
    keyword = data.get('keyword')
    tone = data.get('tone')
    
    if not keyword or not tone:
        return jsonify({"Success": False, "error": "Keyword and tone are required"}), 400
    
    try:
        headings = create_headings(keyword, tone)
        response = {
            "Success": True,
            "data": {
                "Suggestions": headings
            }
        }
        return jsonify(response), 200
    
    except Exception as e:
        return jsonify({"Success": False, "error": str(e)}), 500

@app.route('/manipulate_text', methods=['POST'])
@cross_origin()
def manipulate_text():
    """
    Endpoint to manipulate text based on type and text provided in POST request.
    """
    data = request.get_json()
    type_ = data.get('type')
    text = data.get('text')

    if not type_ or not text:
        return jsonify({
            "Success": False,
            "data": {
                "text": "Type and text are required"
            }
        }), 400

    try:
        response = process_text(type_, text)
        return jsonify({
            "Success": True,
            "data": {
                "text": response
            }
        })
    except Exception as e:
        return jsonify({
            "Success": False,
            "data": {
                "text": str(e)
            }
        }), 500

@app.route('/generate_buttons', methods=['POST'])
@cross_origin()
def generate_buttons():
    data = request.get_json()
    text = data.get('text')
    tone = data.get('tone')
    
    if not text or not tone:
        return jsonify({"error": "Text and tone are required"}), 400
    
    try:
        response = create_button_names(text, tone)
        return jsonify(response), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def call_openai(prompt):
    url = f"{endpoint}/openai/deployments/gpt-35-turbo/chat/completions?api-version=2024-02-15-preview"
    headers = {
        "Content-Type": "application/json",
        "api-key": api_key
    }
    data = {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    response.raise_for_status()
    result = response.json()
    content = result['choices'][0]['message']['content'].strip().strip('"')
    return content

def create_headings(keyword, tone):
    prompt = f"Create a short, concise heading (4-5 words) based on the keyword '{keyword}' with a tone '{tone}':"
    headings = [call_openai(prompt) for _ in range(5)]  # Generate five headings
    return headings

def process_text(type_, text):
    """
    Process the text based on the specified type using Azure OpenAI.
    """
    prompt = generate_prompt(type_, text)
    return call_openai(prompt)

def generate_prompt(type_, text):
    """
    Generate prompt based on the type to be performed on the text.
    """
    prompts = {
        'fix_spelling_grammar': f"Fix the spelling and grammar in the following text:\n{text}",
        'expand_text': f"Expand the following text:\n{text}",
        'summarize_text': f"Summarize the following text in a few sentences:\n{text}",
        'rephrase_text': f"Rephrase the following text:\n{text}",
        'make_friendly': f"Make the following text friendly:\n{text}",
        'make_formal': f"Make the following text formal:\n{text}"
    }
    return prompts.get(type_, "Invalid type")

def create_button_names(text, tone):
    prompt = f"Generate five button names based on the text '{text}' with a '{tone}' tone:"
    response_text = call_openai(prompt)
    
    # Clean up the response to remove unnecessary numbers, quotes, and slashes
    button_names = [name.strip('1234567890."\\ ') for name in response_text.split("\n") if name.strip()]
    
    # Construct the final response
    response = {
        "Success": True,
        "data": {
            "Suggestions": button_names[:5]  # Return the first five cleaned names
        }
    }
    return response

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5002)