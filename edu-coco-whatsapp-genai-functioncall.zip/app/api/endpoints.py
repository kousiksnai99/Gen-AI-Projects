from flask import jsonify, request
import uuid
from datetime import date
import copy
import logging
from app.services.openai_service import chat_completion_request
from app.services.knowledge_base_service import KnowledgeBaseBusinessLogic
from app.config.settings import get_static_values

def register_endpoints(app, cache, write_queue):
    static_values = get_static_values()
    functions = static_values["functions"]
    initial_messages = static_values["initial_messages"]

    @app.route('/', methods=['GET'])
    def welcome_to():
        return 'Welcome to AI Knowledge Base Module :)'

    @app.route("/chat", methods=["POST"])
    def chat():
        try:
            data = request.json
            session_id = data.get("session_id", str(uuid.uuid4()))
            user_input = data.get("user_input", "").strip()

            if not user_input:
                return jsonify({"error": "User input is required."}), 400

            username = data.get("username", "Unknown User")
            userID = data.get("userID")
            platform = data.get("platform")

            if not userID:
                return jsonify({"error": "userID is required."}), 400
            if not platform:
                return jsonify({"error": "platform is required."}), 400

            masked_id = userID[:2] + "*" * (len(userID) - 4) + userID[-2:]
            logging.info(f"Received input: {user_input} (Session ID: {session_id}, User: {username}, UserID: {masked_id}, Platform: {platform})")

            cache_key = f"chat_history_{session_id}"
            chat_history = cache.get(cache_key)
            if chat_history is None:
                from app.services.database_service import get_chat_history_from_db
                chat_history = get_chat_history_from_db(session_id)
                cache.set(cache_key, chat_history)
                logging.info(f"Retrieved chat history from DB and cached for Session ID: {session_id}")
            else:
                logging.info(f"Retrieved chat history from cache for Session ID: {session_id}")

            messages = copy.deepcopy(initial_messages)
            messages[0]["content"] = messages[0]["content"].replace("{current_date}", date.today().strftime("%B %d, %Y"))

            for entry in chat_history:
                messages.append({"role": "user", "content": entry["user_input"]})
                messages.append({"role": "assistant", "content": entry["assistant_response"]})

            messages.append({"role": "user", "content": user_input})

            chat_response = chat_completion_request(messages, username, userID, platform, functions=functions, cache=cache)
            assistant_message = chat_response.get("choices", [{}])[0].get("message", {})
            flow_complete = chat_response.get("flow_complete", False)
            response_content = {}

            if "content" in assistant_message:
                response_content["response"] = assistant_message["content"]
                chat_history.append({"user_input": user_input, "assistant_response": assistant_message["content"]})
                cache.set(cache_key, chat_history)
                logging.info(f"Updated cache for Session ID: {session_id}")
                write_queue.put((session_id, user_input, assistant_message["content"]))
            elif "function_call" in assistant_message:
                import json
                fn_name = assistant_message["function_call"]["name"]
                try:
                    arguments = json.loads(assistant_message["function_call"]["arguments"])
                except json.JSONDecodeError:
                    logging.error(f"Invalid JSON in function arguments: {assistant_message['function_call']['arguments']}")
                    return jsonify({"error": "Invalid function arguments format."}), 400

                response_content["function_call"] = {"name": fn_name, "arguments": arguments}

            response_content["flow_complete"] = flow_complete
            return jsonify(response_content)

        except Exception as e:
            logging.error(f"An error occurred: {e}", exc_info=True)
            return jsonify({"error": "Internal server error. Please try again later."}), 500

    @app.route('/savekb', methods=['POST'])
    def process_document():
        try:
            if 'file' not in request.files:
                return jsonify({'success': False, 'message': 'No file part'}), 400

            file = request.files['file']
            if file.filename == '':
                return jsonify({'success': False, 'message': 'No selected file'}), 400

            logging.info(f"Processing file: {file.filename}")
            response = KnowledgeBaseBusinessLogic.process_document(file)
            return response

        except Exception as e:
            logging.error(f"Error processing document: {e}", exc_info=True)
            return jsonify({'success': False, 'message': 'Internal server error'}), 500