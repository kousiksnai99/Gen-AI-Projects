import streamlit as st
import base64
import pptx
from pptx.util import Pt, Inches
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from dotenv import load_dotenv
import openai
import os
import io
import requests

# Load environment variables
load_dotenv()

# Load your OpenAI API key
openai.api_key = os.getenv('openai-api-token')
openai.api_type = "azure"
openai.api_base = os.getenv('openai-api-base')
openai.api_version = "2024-08-01-preview"

# Define custom formatting options
TITLE_FONT_SIZE = Pt(44)
SLIDE_FONT_SIZE = Pt(18)
TEXT_BOX_WIDTH = Inches(6)
TEXT_BOX_HEIGHT = Inches(3.5)
BACKGROUND_COLOR = RGBColor(255, 255, 255)
TITLE_TEXT_COLOR = RGBColor(0, 140, 186)
SLIDE_TEXT_COLOR = RGBColor(0, 0, 0)

class Presentation():
    
    @staticmethod
    def generate_slide_titles(topic, num_slides=5):
        slide_titles = []
        for i in range(num_slides):
            user_message = f"Generate a title for slide {i + 1} on the topic: {topic}"
            response = openai.ChatCompletion.create(
                engine="gpt-35-turbo",
                model="gpt-35-turbo",
                messages=[
                    {"role": "system", "content": "You are a chatbot that generates presentation titles."},
                    {"role": "user", "content": user_message},
                ],
                max_tokens=30
            )
            slide_titles.append(response.choices[0].message['content'].strip())
        return slide_titles

    @staticmethod
    def generate_slide_content(slide_title):
        user_message = f"Generate content for the slide titled: {slide_title}"
        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            model="gpt-35-turbo",
            messages=[
                {"role": "system", "content": "You are a chatbot that generates beautiful slide content."},
                {"role": "user", "content": user_message},
            ],
            max_tokens=140
        )
        return response.choices[0].message['content'].strip()

    @staticmethod
    def generate_image_description(slide_title):
        user_message = f"Generate an image description for the slide titled: '{slide_title}'. Ensure any written text in the image is in English."
        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            messages=[
                {"role": "system", "content": "You are a chatbot that generates image descriptions for slide titles."},
                {"role": "user", "content": user_message},
            ],
            max_tokens=60
        )
        return response.choices[0].message['content'].strip()

    @staticmethod
    def generate_image_from_description(image_description):
        detailed_description = f"{image_description}. Ensure that any text or written content in the image is professional, neutral, and in English."

        try:
            response = openai.Image.create(
                prompt=detailed_description,
                n=1,
                size="1024x1024"
            )
            image_url = response['data'][0]['url']
            return image_url
        except openai.error.OpenAIError as e:
            # Handle the failure gracefully
            print(f"Image generation failed: {e}")
            return None

    @staticmethod
    def download_image(image_url, save_path):
        response = requests.get(image_url)
        if response.status_code == 200:
            with open(save_path, 'wb') as f:
                f.write(response.content)
        else:
            print(f"Failed to download image from {image_url}")

    @staticmethod
    def create_presentation(topic, slide_titles, slide_contents):
        prs = pptx.Presentation()

        # Create a title slide
        title_slide_layout = prs.slide_layouts[0]
        title_slide = prs.slides.add_slide(title_slide_layout)
        title = title_slide.shapes.title
        title.text = topic
        title.text_frame.paragraphs[0].font.size = TITLE_FONT_SIZE
        title.text_frame.paragraphs[0].font.bold = True
        title.text_frame.paragraphs[0].font.color.rgb = TITLE_TEXT_COLOR
        title.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

        # Set the background color of the title slide
        background = title_slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = BACKGROUND_COLOR

        # Create content slides
        slide_layout = prs.slide_layouts[5]

        # Create a folder for storing images if it doesn't exist
        if not os.path.exists('images'):
            os.makedirs('images')

        for i, (slide_title, slide_content) in enumerate(zip(slide_titles, slide_contents)):
            slide = prs.slides.add_slide(slide_layout)

            # Set title
            title = slide.shapes.title
            title.text = slide_title
            title.text_frame.paragraphs[0].font.size = TITLE_FONT_SIZE
            title.text_frame.paragraphs[0].font.bold = True
            title.text_frame.paragraphs[0].font.color.rgb = TITLE_TEXT_COLOR
            title.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

            # Add slide content
            left_inch = Inches(0.5)  # Start text near left side
            top_inch = Inches(1.0)   # Adjusting position for better fit
            content = slide.shapes.add_textbox(left_inch, top_inch, TEXT_BOX_WIDTH, TEXT_BOX_HEIGHT)
            text_frame = content.text_frame
            p = text_frame.add_paragraph()
            p.text = slide_content
            p.space_before = Pt(12)
            p.space_after = Pt(12)
            text_frame.word_wrap = True

            # Align the content text properly
            p.alignment = PP_ALIGN.LEFT  # Align text to the left
            text_frame.paragraphs[0].font.size = SLIDE_FONT_SIZE
            text_frame.paragraphs[0].font.color.rgb = SLIDE_TEXT_COLOR

            # Generate and add an image to the slide
            image_description = Presentation.generate_image_description(slide_title)
            image_url = Presentation.generate_image_from_description(image_description)
            if image_url:
                image_path = f"images/image_{i}.jpg"
                Presentation.download_image(image_url, image_path)
                img_left = Inches(6.5)  # Move image to the right to avoid overlap
                img_top = Inches(1.0)   # Adjust image vertical position
                img_width = Inches(3)   # Set image width
                slide.shapes.add_picture(image_path, img_left, img_top, img_width)

        ppt_filename = f"{topic}_presentation.pptx"
        prs.save(ppt_filename)
        return ppt_filename

    @staticmethod
    def get_ppt_download_link(ppt_filename):
        with open(ppt_filename, "rb") as file:
            ppt_contents = file.read()

        b64_ppt = base64.b64encode(ppt_contents).decode()
        return f'<a href="data:application/vnd.openxmlformats-officedocument.presentationml.presentation;base64,{b64_ppt}" download="{ppt_filename}">Download the PowerPoint Presentation</a>'

    @staticmethod
    def main(topic):
        # Generate slide titles and content
        slide_titles = Presentation.generate_slide_titles(topic)
        slide_contents = [Presentation.generate_slide_content(title) for title in slide_titles]
        
        # Create the presentation
        ppt_filename = Presentation.create_presentation(topic, slide_titles, slide_contents)
        
        return ppt_filename