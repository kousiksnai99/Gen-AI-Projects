"""ServiceNow agent logic: the Foundry agent + the six ServiceNow operations.

FLOW FOR EVERY OPERATION (this is the whole design):

    app.py endpoint  ->  ServiceNowAgent.<method>()
                              1. _agent()      ask the Foundry agent for the wording
                              2. _call()       hit the real ServiceNow API
                              3. return        the number ServiceNow issued

The ticket number always comes from ServiceNow. The agent writes text only -- it is asked
for the literal "{ticket}" and never for a number, so it cannot invent one.

If Foundry is unreachable the fallback text is used and the ServiceNow call still happens.
A model problem must never cost a ticket.
"""
import json
import os
import re
import threading
import time

import requests
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

# Corporate laptop: the proxy re-signs TLS, so trust the OS certificate store or every
# call dies with CERTIFICATE_VERIFY_FAILED. Not needed on Azure.
if os.getenv("USE_OS_CERT_STORE", "").lower() in ("1", "true", "yes"):
    import truststore
    truststore.inject_into_ssl()

# -- ServiceNow ------------------------------------------------------------
TENANT_ID = os.getenv("SN_TENANT_ID", "3f991a7b-ea93-4169-b28c-c36ff3e5b0d1")
CLIENT_ID = os.getenv("SN_CLIENT_ID", "e91e93ca-955f-47d5-a491-a41985414c57")
CLIENT_SECRET = os.getenv("SN_CLIENT_SECRET", "")
SCOPE = os.getenv("SN_SCOPE", "api://7f70f393-ab7d-4e6b-a92e-952c23dbcba9/.default")
BASE_URL = os.getenv("SN_BASE_URL", "https://apidev.tevapharm.com/gateway/serviceNowTicketingAPI/1.0")
RESOURCE_PATH = os.getenv("SN_RESOURCE_PATH", "a96d6adb3ba2cf1079901b9aa4e45a2f")
API_KEY = os.getenv("SN_API_KEY", "").strip()

TOKEN_URL = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
INCIDENT_URL = f"{BASE_URL}/api/tpi/tevagenericwebservice/incident/{RESOURCE_PATH}"
TIMEOUT = int(os.getenv("SN_TIMEOUT", "60"))

# THE INTERACTION TABLE (IMS numbers) IS NOT ON THIS GATEWAY YET.
#
# In ServiceNow, `interaction` and `incident` are different tables with different number
# prefixes -- IMS0001234 vs INC0001234 -- and create_interaction below WILL return an IMS
# number as soon as the route exists. It does not today: GET and POST both answer
# 404 "API Gateway Error" on every variant tried (re-proven 2026-09-12):
#     /api/tpi/tevagenericwebservice/interaction/{resourcePath}
#     /api/tpi/tevagenericwebservice/sn_customerservice_interaction/{resourcePath}
#     /api/now/table/interaction
# A 404 from the API Gateway means the path is not in its route list -- the request never
# reaches ServiceNow, so this is not an ACL or a table problem and no code can work around
# it. The client's own Postman collection only exposes incident, sys_user, sc_task and
# submitCatalog. (Compare: a registered route answers 200, e.g. the incident path returns
# {"hasError": true, "errorMsg": "Query is invalid / empty"} for an empty query.)
#
# ASK THE CLIENT FOR: the gateway route for the `interaction` table plus its own
# registration id / resourcePath. Put that id in SN_INTERACTION_PATH and IMS numbers start
# flowing with no code change. Until then create_interaction opens the INC that represents
# the conversation and says so in the response (`record: "incident"`).
INTERACTION_PATH = os.getenv("SN_INTERACTION_PATH", "").strip()
INTERACTION_TABLE = os.getenv("SN_INTERACTION_TABLE", "interaction").strip()
INTERACTION_URL = (
    f"{BASE_URL}/api/tpi/tevagenericwebservice/{INTERACTION_TABLE}/{INTERACTION_PATH}"
)
# ServiceNow's interaction state choice list, not free text.
INTERACTION_OPEN = os.getenv("SN_INTERACTION_OPEN_STATE", "new")
INTERACTION_CLOSED = os.getenv("SN_INTERACTION_CLOSED_STATE", "closed_complete")

# Mandatory on create: short_description, description, u_ticket_source, u_customer_ci.
# Mandatory on resolve: all six sent in resolve(). SN_CUSTOMER_CI is a PLACEHOLDER the
# business still has to confirm.
TICKET_SOURCE = os.getenv("SN_TICKET_SOURCE", "Self-service")
CUSTOMER_CI = os.getenv("SN_CUSTOMER_CI", "5df3b00a4f775a004e1e3c728110c702")
RESOLUTION_METHOD = os.getenv("SN_RESOLUTION_METHOD", "Automated")
CLOSE_CODE = os.getenv("SN_CLOSE_CODE", "Solved (Permanently)")
RESOLVED_STATE = "6"

STATES = {"1": "New", "2": "In Progress", "3": "On Hold", "6": "Resolved",
          "7": "Closed", "8": "Cancelled"}

# -- Foundry agent ---------------------------------------------------------
FOUNDRY_ENDPOINT = os.getenv("AZURE_FOUNDRY_PROJECT_ENDPOINT", "")
FOUNDRY_AGENT = os.getenv("SN_FOUNDRY_AGENT_NAME", "ITOA-Project-Agentic-AI-ServiceNow-Agent")
SP_TENANT = os.getenv("AZURE_SP_TENANT_ID", "")
SP_CLIENT = os.getenv("AZURE_SP_CLIENT_ID", "")
SP_SECRET = os.getenv("AZURE_SP_CLIENT_SECRET", "")

# Used when Foundry is off or unreachable. Cannot be removed: description is mandatory on
# create and close_notes on resolve, so a ticket raised during an outage still needs text.
FALLBACK = {
    # ticket text
    "summary": "Support chat: issue reported by the user",
    "note": "Updated by the support assistant.",
    # one message per operation -- they are NOT interchangeable: "has been raised" under
    # an update or a close tells the user the wrong thing happened.
    "create_interaction": "Your ticket {ticket} has been raised with the service desk.",
    "create_incident": "Your ticket {ticket} has been raised with the service desk.",
    "update_incident": "Ticket {ticket} has been updated with the latest details.",
    "close_interaction": "Ticket {ticket} stays with the service desk. The chat is now closed.",
    "resolve": "Ticket {ticket} has been resolved.",
    "pending": "Ticket {ticket} has been sent for closure and is awaiting confirmation.",
    "get_status": "Ticket {ticket} is currently showing as {status}.",
}


class ServiceNowError(Exception):
    """ServiceNow answered 200 with {"result": {"hasError": true, "errorMsg": ...}}."""


# Module-level so the token and the TCP pool survive across requests.
#
# RLock, NOT Lock: _bearer() holds this while calling _http(), which wants it too. With a
# plain Lock that is a deadlock -- the first request hangs forever.
_lock = threading.RLock()
_session = None
_token = {"value": "", "expires": 0.0}
_client = {"built": False, "obj": None}
# After 3 failures in a row, stop calling Foundry for 5 minutes. Without this every
# operation pays the full timeout during an outage, and a request that should take 3
# seconds takes 30.
_broken = {"fails": 0, "until": 0.0}


def _http():
    global _session
    if _session is None:
        with _lock:
            if _session is None:
                _session = requests.Session()
                adapter = requests.adapters.HTTPAdapter(pool_connections=20, pool_maxsize=20)
                _session.mount("https://", adapter)
    return _session


def _bearer():
    """Entra ID access token, cached and refreshed 5 minutes before expiry."""
    if _token["value"] and time.time() < _token["expires"]:
        return _token["value"]
    if not CLIENT_SECRET:
        raise ServiceNowError("SN_CLIENT_SECRET is not set. Put it in .env.")
    with _lock:
        if _token["value"] and time.time() < _token["expires"]:
            return _token["value"]      # another thread fetched it while we waited
        response = _http().post(TOKEN_URL, timeout=TIMEOUT, data={
            "client_id": CLIENT_ID, "client_secret": CLIENT_SECRET,
            "scope": SCOPE, "grant_type": "client_credentials",
        })
        response.raise_for_status()
        payload = response.json()
        _token["value"] = payload["access_token"]
        _token["expires"] = time.time() + int(payload.get("expires_in", 3600)) - 300
    return _token["value"]


def _safe(value):
    """Strip characters that are operators in a ServiceNow encoded query.

    Everything we put in ?sysparm_query= is an identifier. Without this, a
    conversation_id of "x^ORstate=1" would widen the lookup onto someone else's ticket.
    """
    return re.sub(r"[^A-Za-z0-9_.:-]", "", str(value or ""))


def _openai():
    """The Foundry client, built once per process. None if it cannot be built."""
    if _client["built"]:
        return _client["obj"]
    with _lock:
        _client["built"] = True
        if not (FOUNDRY_ENDPOINT and FOUNDRY_AGENT):
            return None
        try:
            from azure.ai.projects import AIProjectClient
            from azure.identity import ClientSecretCredential, DefaultAzureCredential
            credential = (
                ClientSecretCredential(SP_TENANT, SP_CLIENT, SP_SECRET)
                if SP_CLIENT and SP_SECRET else DefaultAzureCredential()
            )
            project = AIProjectClient(endpoint=FOUNDRY_ENDPOINT, credential=credential)
            try:
                client = project.get_openai_client()           # azure-ai-projects 2.x
            except (TypeError, ValueError):
                client = project.get_openai_client(api_version="2025-04-01-preview")  # 1.x
            _client["obj"] = client.with_options(timeout=20, max_retries=1)
        except Exception as exc:
            print(f"[agent] unavailable, using fallback text: {exc}")
            _client["obj"] = None
    return _client["obj"]


class ServiceNowAgent:
    """The six ServiceNow operations. Each one asks the agent, then calls ServiceNow."""

    label = "servicenow"

    # ---------------------------------------------------------------- agent
    def _agent(self, action, **facts):
        """Ask the Foundry agent for this operation's wording. {} means use the fallback.

        The facts go over as one JSON value, so a user's own words can never become a
        second instruction. Never raises: the ServiceNow call must happen regardless.
        """
        client = _openai()
        if client is None or time.time() < _broken["until"]:
            return {}
        try:
            reply = client.responses.create(
                input=json.dumps({"action": action, **facts}, ensure_ascii=False),
                extra_body={"agent_reference": {"name": FOUNDRY_AGENT,
                                                "type": "agent_reference"}},
            )
            text = getattr(reply, "output_text", "") or ""
            start, end = text.find("{"), text.rfind("}")
            data = json.loads(text[start:end + 1]) if start >= 0 < end else {}
            _broken["fails"] = 0
        except Exception as exc:
            _broken["fails"] += 1
            if _broken["fails"] >= 3:
                _broken["until"] = time.time() + 300
                _broken["fails"] = 0
                print("[agent] disabled for 5 min after 3 failures; ServiceNow unaffected")
            print(f"[agent] {action} failed, using fallback text: {str(exc)[:120]}")
            return {}
        if not isinstance(data, dict):
            return {}

        # Validate. The prompt asks; this guarantees.
        out = {}
        for key, limit in (("short_description", 160), ("description", 1500),
                           ("work_notes", 500), ("close_notes", 500),
                           ("u_what_was_done", 500), ("message", 300),
                           ("message_pending", 300)):
            value = " ".join(str(data.get(key) or "").split())[:limit]
            if value:
                out[key] = value
        for key in ("impact", "urgency"):
            # Whitelisted: ServiceNow rejects a whole write over one bad choice value.
            if str(data.get(key, "")) in ("1", "2", "3"):
                out[key] = str(data[key])
        return out

    @staticmethod
    def _message(written, fallback, number, status=""):
        """The user-facing line, with the real ticket number substituted in.

        The agent writes "{ticket}", never a number -- at the moment it writes, the number
        does not exist yet. A line carrying an INC of its own was invented, so it is
        dropped in favour of the fallback.
        """
        line = written or ""
        if not line or "{ticket}" not in line or re.search(r"\bINC\d+\b", line):
            line = fallback
        return line.replace("{ticket}", number).replace("{status}", status or "open").strip()

    # ------------------------------------------------------------ servicenow
    def _call(self, method, query="", body=None, url=""):
        """One ServiceNow call. The record is ALWAYS selected by ?sysparm_query=.

        An identifier in the BODY is silently ignored by this gateway, and PATCH is 405.
        `url` defaults to the incident table; pass INTERACTION_URL for the interaction one.
        """
        headers = {"Authorization": f"Bearer {_bearer()}", "Accept": "application/json"}
        if API_KEY:
            headers["x-Gateway-APIKey"] = API_KEY
        response = _http().request(
            method, url or INCIDENT_URL, headers=headers, json=body,
            params={"sysparm_query": query} if query else None, timeout=TIMEOUT,
        )
        response.raise_for_status()
        result = (response.json() or {}).get("result") or {}
        if result.get("hasError"):
            raise ServiceNowError(result.get("errorMsg") or "ServiceNow rejected the request.")
        return result

    def _find(self, conversation_id, incident_id=""):
        """The ticket for this conversation, or "". Never raises.

        u_inbound_key = conversation_id is stamped at create time (it persists on POST
        only), so every later operation finds the same ticket with no state of our own.
        """
        if incident_id:
            return str(incident_id).strip()
        if not conversation_id:
            return ""
        try:
            return self._call("GET", f"u_inbound_key={_safe(conversation_id)}").get("number", "")
        except Exception:
            return ""   # includes "No record found", which is normal

    def _new(self, conversation_id, written, text):
        """POST a new incident and return the number ServiceNow issued."""
        body = {
            "short_description": (written.get("short_description") or text)[:160],
            "description": written.get("description") or text,
            "u_ticket_source": TICKET_SOURCE,
            "u_customer_ci": CUSTOMER_CI,
        }
        for key in ("impact", "urgency"):
            if written.get(key):
                body[key] = written[key]
        if conversation_id:
            body["u_inbound_key"] = conversation_id
        return self._call("POST", body=body).get("number", "")

    # ------------------------------------------------------- the six actions
    def create_interaction(self, conversation_id, user_id="", details=""):
        """Open the interaction for this conversation. Returns its number.

        WITH SN_INTERACTION_PATH SET this POSTs the real ServiceNow `interaction` record
        and returns an IMS number -- a different table and a different number series from
        the incident, which is what it should be.

        WITHOUT IT -- the situation today, because the route 404s on the gateway (see the
        note at the top of this file) -- it opens the INC that represents the conversation
        and returns that. `record` in the response says which one you got, so a caller is
        never left guessing whether an id is an IMS or an INC.

        PASS `details` IF YOU ALREADY KNOW THE ISSUE. This gateway's PUT cannot write
        short_description, so the summary is fixed the moment the record is created and can
        never be corrected afterwards.
        """
        text = str(details or "").strip()
        written = self._agent("create_interaction", user=user_id, details=text)

        if INTERACTION_PATH:
            # The real interaction table's own fields -- not the incident's. `type` and
            # `channel` say the contact arrived over chat; `state` is from the interaction
            # choice list. opened_for needs a sys_user sys_id, which the gateway's stub
            # lookup cannot give us, so the user is recorded in the note instead.
            body = {
                "short_description": (written.get("short_description") or text
                                      or FALLBACK["summary"])[:160],
                "type": "chat",
                "channel": "chat",
                "state": INTERACTION_OPEN,
                "work_notes": f"Chat opened for '{user_id}' (conversation {conversation_id}).",
            }
            number = self._call("POST", body=body, url=INTERACTION_URL).get("number", "")
            record = "interaction"
        else:
            number = self._new(conversation_id, written, text or FALLBACK["summary"])
            record = "incident"

        return {
            "interaction_id": number,
            "conversation_id": conversation_id,
            "record": record,
            "message": self._message(written.get("message"),
                                     FALLBACK["create_interaction"], number),
        }

    def create_incident(self, conversation_id, details, issue_type="", interaction_id=""):
        """Create the incident, or record the issue on the one this conversation has.

        FIND OR CREATE, so a second call for the same conversation adds a work note
        instead of raising a duplicate ticket.
        """
        text = str(details or "").strip()
        if not text:
            raise ServiceNowError("'details' is required.")
        written = self._agent("create_incident", issue_type=issue_type, details=text)

        # An IMS interaction number is NOT something the incident table can be queried by,
        # so once real interactions are enabled the incident is found by conversation only.
        number = self._find(conversation_id, "" if INTERACTION_PATH else interaction_id)
        if number:
            note = written.get("work_notes") or (f"{issue_type}: {text}" if issue_type else text)
            self._call("PUT", f"number={_safe(number)}", {"work_notes": note})
        else:
            number = self._new(conversation_id, written, f"{issue_type}: {text}" if issue_type else text)
        return {
            "incident_id": number,
            "conversation_id": conversation_id,
            "issue_type": issue_type,
            "message": self._message(written.get("message"), FALLBACK["create_incident"], number),
        }

    def update_incident(self, conversation_id, note, incident_id=""):
        """Add a work note. Journal fields are the only thing a PUT can write here."""
        number = self._find(conversation_id, incident_id)
        if not number:
            raise ServiceNowError("No incident found for this conversation.")
        written = self._agent("update_incident", note=note, incident_id=number)
        self._call("PUT", f"number={_safe(number)}",
                   {"work_notes": written.get("work_notes") or note})
        return {
            "incident_id": number,
            "conversation_id": conversation_id,
            "message": self._message(written.get("message"), FALLBACK["update_incident"], number),
        }

    def resolve(self, conversation_id, incident_id="", interaction_id=""):
        """Resolve the incident, then RE-READ it and report what actually stored.

        This gateway's PUT writes journal fields only -- it accepts `state`, echoes it
        back, and drops it. So the response is never trusted: we read the record and tell
        the user the truth instead of claiming a closure that did not happen.
        """
        number = self._find(conversation_id, incident_id)
        if not number:
            raise ServiceNowError("No incident found for this conversation.")
        summary = self._call("GET", f"number={_safe(number)}").get("short_description", "")
        written = self._agent("resolve", incident_id=number, short_description=summary)
        note = written.get("close_notes") or summary or FALLBACK["note"]

        # All six mandatory fields go together or the transition is rejected outright.
        self._call("PUT", f"number={_safe(number)}", {
            "state": RESOLVED_STATE,
            "close_code": CLOSE_CODE,
            "close_notes": note,
            "comments": note,
            "u_what_was_done": written.get("u_what_was_done") or note,
            "u_resolution_method": RESOLUTION_METHOD,
            "cmdb_ci": CUSTOMER_CI,
        })
        state = self._call("GET", f"number={_safe(number)}").get("state", "")
        resolved = state == RESOLVED_STATE
        message = self._message(
            written.get("message") if resolved else written.get("message_pending"),
            FALLBACK["resolve"] if resolved else FALLBACK["pending"], number,
        )
        return {
            "incident_id": number,
            "conversation_id": conversation_id,
            "state": state,
            "status": STATES.get(state, "Open"),
            "resolved": resolved,
            "message": message,
        }

    def close_interaction(self, conversation_id, interaction_id=""):
        """Close the interaction.

        On the real interaction table this is a state change to "closed_complete". On the
        incident standing in for it, it is a WORK NOTE and deliberately NOT a state change:
        ending a chat is not the same event as fixing the problem, and a conversation that
        ends unsolved must leave the ticket open for the service desk. resolve() is the
        only thing that closes a ticket.
        """
        written = self._agent("close_interaction", incident_id=interaction_id)

        if INTERACTION_PATH:
            number = str(interaction_id or "").strip()
            if not number:
                raise ServiceNowError("interaction_id is required to close an interaction.")
            self._call("PUT", f"number={_safe(number)}", {
                "state": INTERACTION_CLOSED,
                "work_notes": written.get("work_notes") or "The support chat ended.",
            }, url=INTERACTION_URL)
            record = "interaction"
        else:
            number = self._find(conversation_id, interaction_id)
            if not number:
                raise ServiceNowError("No incident found for this conversation.")
            self._call("PUT", f"number={_safe(number)}",
                       {"work_notes": written.get("work_notes") or "The support chat ended."})
            record = "incident"

        return {
            "interaction_id": number,
            "conversation_id": conversation_id,
            "record": record,
            "message": self._message(written.get("message"), FALLBACK["close_interaction"], number),
        }

    def get_status(self, conversation_id="", incident_id=""):
        """Where the ticket stands: the stored state and its label. Writes nothing."""
        number = self._find(conversation_id, incident_id)
        if not number:
            return {"found": False, "incident_id": "", "state": "", "status": "",
                    "message": "No ticket found for this conversation."}
        record = self._call("GET", f"number={_safe(number)}")
        state = record.get("state", "")
        status = STATES.get(state, "Open")
        written = self._agent("get_status", incident_id=number, status=status)
        return {
            "found": True,
            "incident_id": number,
            "conversation_id": conversation_id,
            "state": state,
            "status": status,
            "short_description": record.get("short_description", ""),
            "resolved": state in (RESOLVED_STATE, "7"),
            "message": self._message(written.get("message"), FALLBACK["get_status"], number, status),
        }
