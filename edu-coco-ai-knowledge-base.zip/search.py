import logging
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
import json
from dotenv import load_dotenv
import os
from flask import jsonify
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
load_dotenv()

# Set Azure Search endpoint and key

#==================================================
'''credential = ManagedIdentityCredential()
KEYVAULT_NAME = os.environ['KEYVAULT_NAME']
client = SecretClient(f"https://{KEYVAULT_NAME}.vault.azure.net/",credential)

endpoint = client.get_secret("cognetive-service-endpoint")
endpoint = endpoint.value

key = client.get_secret("cognetive-service-password")
key = key.value'''
#==================================================
container_name = os.environ['STORAGE_CONTAINER_NAME']
account_name = os.environ['STORAGE_ACCOUNT_NAME']
instrumentation_key = os.getenv('Instrumentation_Key')
vector_store_address = os.getenv('cognetive-service-endpoint')
vector_store_password = os.getenv('cognetive-service-password')
api_base = os.getenv('openai-api-base')
openai_api_token = os.getenv('openai-api-token')
account_key = os.getenv('ai-knowledge-base-account-key')
application_token = os.getenv('ai-application-token')

# Your index name
index_name = "coco-procuremate-test"

# Create Azure SDK client
search_client = SearchClient(vector_store_address, index_name, AzureKeyCredential(vector_store_password))
class Search():
# returns obj like {authors: 'array', language_code:'string'}
    def read_facets(facetsString):
        # facets = facetsString.split(",")
        output = {}
        
        for x in facetsString:
            if x.find("*") != -1:
                newVal = x.replace("*", "")
                output[newVal] = "array"
            else:
                output[x] = "string"

        return output


    # creates filters in odata syntax
    def create_filter_expression(filter_list, facets):
        i = 0
        filter_expressions = []
        return_string = ""
        separator = " and "

        while i < len(filter_list):
            field = filter_list[i]["field"]
            value = filter_list[i]["value"]

            if facets[field] == "array":
                print("array")
                filter_expressions.append(f"{field}/any(t: search.in(t, '{value}', ','))")
            else:
                print("value")
                filter_expressions.append(f"{field} eq '{value}'")

            i += 1

        return_string = separator.join(filter_expressions)

        return return_string


    def new_shape(docs,param):

        old_api_shape = list(docs)

        client_side_expected_shape = []

        for item in old_api_shape:

            new_document = {}
            new_api_shape = {}

            for i in param:
                new_api_shape[i] = item[i]
                
            # new_document["score"] = item["@search.score"]
            # new_document["highlights"] = item["@search.highlights"
                
            # new_api_shape = {}
            # new_api_shape["id"] = item["id"]
            # new_api_shape["supplierid"] = item["supplierid"]
            # new_api_shape["supplier_name"] = item["supplier_name"]
            # new_api_shape["catalog_number"] = item["catalog_number"]
            # new_api_shape["category"] = item["category"]
            # new_api_shape["commodity_code"] = item["commodity_code"]
            # new_api_shape["product_description"] = item["product_description"]
            # new_api_shape["image_url"] = item["image_url"]
            # new_api_shape["business_unit"] = item["business_unit"]
            # new_api_shape["previous_purchase_date"] = item["previous_purchase_date"]
            # new_api_shape["price"] = item["price"]
            # new_api_shape["diversity"] = item["diversity"]
            
            # new_document["document"] = new_api_shape

            client_side_expected_shape.append(new_api_shape)

        return list(client_side_expected_shape)

    def main(q,top,skip,filters):

        
        facets = ["product_description"]
        facetKeys = Search.read_facets(facets)

        search_filter = ""
        if len(filters):
            search_filter = Search.create_filter_expression(filters, facetKeys)

        if q:
            logging.info(f"/Search q = {q}")

            search_results = search_client.search(
                search_text=q,
                top=top,
                skip=skip,
                facets=facetKeys,
                filter=search_filter,
                include_total_count=True,
            )
            param=["id","product_description","catalog_number"]
            returned_docs = Search.new_shape(search_results,param)

            # format the React app expects
            full_response = {}

            full_response["results"] = returned_docs
            data=json.dumps(full_response)
            json_data = json.loads(data)
            seen_descriptions = set()
            unique_results = []

            for item in json_data['results']:
                description = item['product_description']
                if description not in seen_descriptions:
                    unique_results.append(item)
                    seen_descriptions.add(description)

            filtered_json_data = {"results": unique_results}
            return jsonify({'success': True, 'message': filtered_json_data})

            
        else:
            return False
        

    def product_main(q, top, skip, filters, price, supplier_name):
        print("product_main")
        facets = ["product_description"]
        facetKeys = Search.read_facets(facets)

        search_filter = ""
        if len(filters):
            search_filter = Search.create_filter_expression(filters, facetKeys)

        if q:
            logging.info(f"/Search q = {q}")

            search_results = search_client.search(
                search_text=q,
                top=top,
                skip=skip,
                facets=facetKeys,
                filter=search_filter,
                include_total_count=True,
            )
            print("Raw search results:", search_results)
            param = ["id", "supplier_name", "product_description", "price"]
            returned_docs = Search.new_shape(search_results, param)
            print("returned_docs========", returned_docs)
            full_response = {}

            full_response["results"] = returned_docs
            data = json.dumps(full_response)
            data = json.loads(data)

            # Temporarily applying only the product_description filter
            filtered_results = [item for item in data['results'] if item['product_description'] == q]
            print("After product_description filter:", filtered_results)

            return jsonify({'success': True, 'message': filtered_results})

        else:
            return jsonify({'success': False, 'message': "Some error occurred"})

        
    def allsupplier(q,top,skip,filters):

        print("product_main")
        facets = ["catalog_number"]
        facetKeys = Search.read_facets(facets)
        
        
        search_filter = ""
        if len(filters):
            search_filter = Search.create_filter_expression(filters, facetKeys)
            print("product_main================")


        if q:
            logging.info(f"/Search q = {q}")

            search_results = search_client.search(
                search_text=q,
                top=top,
                skip=skip,
                facets=facetKeys,
                filter=search_filter,
                include_total_count=True,
            )
            param=["id","catalog_number","supplier_name","previous_purchase_date","product_description","price"]
            returned_docs = Search.new_shape(search_results,param)
            blob_url="https://steducocodev.blob.core.windows.net/output/Invoice?sp=r&st=2024-06-20T07:45:48Z&se=2024-06-20T15:45:48Z&spr=https&sv=2022-11-02&sr=b&sig=NQkOmKKcfp7dz%2B%2B2bi334YEA8z1%2FgyKtzNxcQXwYtC0%3D"
            returned_docs = [{**item, 'url': blob_url} for item in returned_docs]
            full_response = {}
            full_response["results"] = returned_docs
            data=json.dumps(full_response)
            data = json.loads(data)
            print("data ==== ",data)
            filtered_results = [item for item in data['results'] if item['catalog_number'] == q]
            return jsonify({'success': True, 'message': filtered_results})

            
        else:
            return jsonify({'success': False, 'message': "Some error occured"})