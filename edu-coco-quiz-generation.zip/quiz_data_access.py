from langchain_core.prompts import PromptTemplate
import openai
from langchain.chains.summarize import load_summarize_chain
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.chat_models import AzureChatOpenAI
#from azure.identity import ManagedIdentityCredential
#from azure.keyvault.secrets import SecretClient
import json
import os
from langchain.text_splitter import TokenTextSplitter

#-----------------------------------------------------------------
'''credential = ManagedIdentityCredential()
KEYVAULT_NAME = os.environ['KEYVAULT_NAME']
client = SecretClient(f"https://{KEYVAULT_NAME}.vault.azure.net/",credential)

openai_api_key = client.get_secret("openai-api-token")'''
openai_api_key = "8mMSCwDci0qPa3zxcJ1AmH1EWOqNcGOM9ooojxWoYFcszmIq8HFcJQQJ99ALACYeBjFXJ3w3AAABACOGutqQ"


#api_base = client.get_secret("openai-api-base")
api_base = "https://rfp-openai-service.openai.azure.com/"

openai.api_type = "azure"
openai.api_key = openai_api_key  
openai.api_base = api_base  
openai.api_version = "2024-08-01-preview"

#-----------------------------------------------------------------
#--------------------------------remove---------------------------------
#--------------------------------remove---------------------------------


class ContextToQuizDataAccess:

    #Summarize the text from load summarize chain
    @staticmethod
    def summarize_text(text):
        text_splitter = TokenTextSplitter(chunk_size=1000, chunk_overlap=100)
        try:
            chunks = text_splitter.split_documents(text)
        except:
            chunks = text_splitter.create_documents([text])

        chain = load_summarize_chain(llm=AzureChatOpenAI(
                deployment_name="gpt-35-turbo",
                model_name="gpt-35-turbo",openai_api_version="2024-08-01-preview",openai_api_key=openai_api_key,openai_api_base=api_base
            ),
            # llm = openai.ChatOpenAI(temperature=0,model_name='gpt-3.5-turbo',openai_api_key = openai.api_key),
            chain_type='map_reduce',
            verbose=False,
        )
        summary = chain.run(chunks)
        return summary
    
    @staticmethod
    def remove_repeated_que(data,key):
        unique_questions = []
        seen_questions = set()

        for question in data[key]:
            if question["questiontext"] not in seen_questions:
                seen_questions.add(question["questiontext"])
                unique_questions.append(question)

        # Create a new JSON with unique questions
        unique_json_data = {key: unique_questions}

        # Convert back to JSON string
        unique_json_string = json.dumps(unique_json_data, indent=2)
        return unique_json_string

            
    #Making Prompt for generating MCQ
    @staticmethod
    def create_prompt_level_true_false(question_count,output_summary,easy,medium,hard):
        template = """
                // AI role
                Your role and purpose is now as an AI multiple-choice automated quiz writer, a backend text processor. AI response must be only a valid json output. Required: no AI commentary or tutorial, no AI introduction nor markdown.
                Give me {question_count} True false questions  about {output_summary} and don't exceed to ${question_count} questions.
                - Questions should generate {easy} easy question and don't exceed from {easy} for the easy question.
                - Questions should generate {medium} medium question and don't exceed from {medium} for the medium question.
                - Question should generate {hard} hard question and don't exceed from {hard} for the hard question.
                - Generate the False question from the true question and give them in random order with the true and false question. Return your answer with the true or false with repect to the question. 
                - The JSON object should have a key named "truefalse" which is an array of the "code" ,"mark" , "questiontext", "rightanswer","level" (difficulty level of question),"Tags"(Generate main topics or tags for questions that are contextually relevant to the content of the {output_summary}. 
                        Ensure that the generated topics or tags are specific to each question and reflect the overall theme of the document, avoiding generic terms. 
                        The goal is to maintain the integrity of the document while providing meaningful and pertinent tags for each question. 
                        The tags should be as close to the theme of the question from the section in the document and not just overall topics from the document itself. 
                        Each tag or topic should preferably be 1 but should not exceed 3 words and the maximum tags allowed is 3 for each question). 
                - Each questiontext question should include the rightanswer. Don't include anything other than the JSON. The JSON properties of each truefalse should be "code" like q1 ,"mark" (which always be 1) "questiontext" (which is the question), "rightanswer" (which is the true false with repect to question),"level","Tags".Use should use this format only.
                - quiz format should have {question_count} unnumbered questions, with randomly deceptively incorrect or correct
                - quiz length should {question_count}
                - Should not have repeating questions

                ---
                RESPONSE
                ## Example output
                -answer should have true or false on the basis of question

                """
        prompt = PromptTemplate(
            input_variables=["question_count","output_summary","easy","medium","hard"],
            template=template,
        )
        
        final_prompt = prompt.format(question_count = question_count,output_summary=output_summary,easy=easy,medium=medium,
                                     hard=hard
                                    )
        return final_prompt
    
    #Generating True and False from Prompting
    @staticmethod
    def generate_level_true_and_false(question_count,output_summary,tf_difflevel):
        output_summary = output_summary
        easy = tf_difflevel[0]
        medium = tf_difflevel[1]
        hard = tf_difflevel[2]
        question_count=sum(tf_difflevel)
        final_prompt = ContextToQuizDataAccess.create_prompt_level_true_false(question_count,output_summary,easy,medium,hard)
        messages = [{"role": "user", "content": final_prompt}]

        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            model="gpt-35-turbo",
            messages=messages,
            temperature=0,
            max_tokens=4000,
            top_p=0.95,
            frequency_penalty=0,
            presence_penalty=0,
            stop=None
        )
        True_false = response.choices[0].message["content"]
        # print(True_false)
        True_false_json = json.loads(True_false)
        # print(True_false_json)
        True_false_json=ContextToQuizDataAccess.remove_repeated_que(True_false_json,"truefalse")
        True_false_json = json.loads(True_false_json)
        # print(True_false_json)
        return True_false_json['truefalse']

    #Making Prompt for generating True and false
    @staticmethod
    def create_prompt_true_false(question_count,output_summary):
        template = """
                // AI role
                Your role and purpose is now as an AI multiple-choice automated quiz writer, a backend text processor. AI response must be only a valid json output. Required: no AI commentary or tutorial, no AI introduction nor markdown.
                Give me {question_count} True false questions s about {output_summary} and don't exceed to ${question_count} questions.
                - The questions should be at easy,medium and hard level of question and it has atleast 1 easy, 1 medium, and 1 hard questions. Generate MCQs of different difficulty levels based on the context.
                - Generate the False question from the true question and give them in random order with the true and false question. Return your answer with the true or false with repect to the question. 
                - The JSON object should have a key named "truefalse" which is an array of the "code" ,"mark" , "questiontext", "rightanswer","level" (difficulty level of question),"Tags"(Generate main topics or tags for questions that are contextually relevant to the content of the {output_summary}. 
                        Ensure that the generated topics or tags are specific to each question and reflect the overall theme of the document, avoiding generic terms. 
                        The goal is to maintain the integrity of the document while providing meaningful and pertinent tags for each question. 
                        The tags should be as close to the theme of the question from the section in the document and not just overall topics from the document itself. 
                        Each tag or topic should preferably be 1 but should not exceed 3 words and the maximum tags allowed is 3 for each question). 
                - Each questiontext question should include the rightanswer. Don't include anything other than the JSON. The JSON properties of each truefalse should be "code" like q1 ,"mark" (which always be 1) "questiontext" (which is the question), "rightanswer" (which is the true false with repect to question),"level","Tags".Use should use this format only.
                - quiz format should have {question_count} unnumbered questions, with randomly deceptively incorrect or correct
                - quiz length should {question_count}
                - Should not have repeating questions

                ---
                RESPONSE
                ## Example output
                -answer should have true or false on the basis of question

                """
        prompt = PromptTemplate(
            input_variables=["question_count","output_summary"],
            template=template,
        )
        
        final_prompt = prompt.format(question_count = question_count,output_summary=output_summary
                                    )
        return final_prompt
    
    #Generating True and False from Prompting
    @staticmethod
    def generate_true_and_false(question_count,output_summary):
        output_summary = output_summary
        final_prompt = ContextToQuizDataAccess.create_prompt_true_false(question_count,output_summary)
        messages = [{"role": "user", "content": final_prompt}]

        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            model="gpt-35-turbo",
            messages=messages,
            temperature=0,
            max_tokens=4000,
            top_p=0.95,
            frequency_penalty=0,
            presence_penalty=0,
            stop=None
        )
        True_false = response.choices[0].message["content"]
        True_false_json = json.loads(True_false)
        True_false_json=ContextToQuizDataAccess.remove_repeated_que(True_false_json,"truefalse")
        True_false_json = json.loads(True_false_json)
        return True_false_json['truefalse']
    
    #Making Prompt for generating Fill in the blanks
    @staticmethod
    def create_prompt_fill(question_count,output_summary):
        template = """
                // AI role
                You are an expert for generating fill in the blank. Your role and purpose is now as an AI Fill in the blanks quiz writer, a backend text processor. AI response must be only a valid json output. Required: no AI commentary or tutorial, no AI introduction nor markdown.
                Give me ${question_count} fill in the blanks about ${output_summary} and don't exceed to ${question_count} questions. The questions should be at an medium level.Generate fill in the blanks question from the sentences of ${output_summary} and blank should be for analytical keyword and give them in random order. Return your answer with the correct word with repect to the fill in the blank question. The JSON object should have a key named "shortanswer" which is an array of the questions. Each quiz question should include the answer. Don't include anything other than the JSON.The JSON properties of each question should be "code" like q1, q2, q3, q4, q5 ,"mark" (which always be 1), "questiontext" (which is the question) "answer" (which is answer of fill in the blank and should have one word).Should use this format only.
                // quiz specifications
                - quiz purpose: evaluate skills of a customer
                - quiz format: ${question_count} unnumbered questions, with the blank 
                - quiz length: ${question_count} questions
                - quiz question: questions should have the sentence with the blank for the answer
                - quiz answer: should have sensible and analytical keyword not include helping verbs,pronouns in the keyword and keyword should be one word

                """
        prompt = PromptTemplate(
            input_variables=["question_count","output_summary"],
            template=template,
        )
        final_prompt = prompt.format(question_count=question_count,output_summary=output_summary
                                    )
        return final_prompt

    #Generating Fill in the blanks from Prompting
    @staticmethod
    def generate_fill_inthe_blanks(question_count,output_summary):
        output_summary = output_summary
        final_prompt = ContextToQuizDataAccess.create_prompt_fill(question_count,output_summary)
        messages = [{"role": "user", "content": final_prompt}]
        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            model="gpt-35-turbo",
            messages=messages,
            temperature=0,
            max_tokens=4000,
            top_p=0.95,
            frequency_penalty=0,
            presence_penalty=0,
            stop=None
        )
        fill_inthe_blanks = response.choices[0].message["content"]
        fill_inthe_blanks_json = json.loads(fill_inthe_blanks)

        return fill_inthe_blanks_json['shortanswer']
        

    @staticmethod
    def create_prompt_mcq(question_count,output_summary):
    #feedback = {'Question': '', 'Alloptions': '','Rightoption': ''}
        feedback = {"mcq": {"Tags": "", "code": "", "level": "", "mark": "","options":[{
                    "answertext": "New York",
                    "rightanswer": "false"
                },
                {
                    "answertext": "Berlin",
                    "rightanswer": "false"
                },
                {
                    "answertext": "Rome",
                    "rightanswer": "false"
                },
                {
                    "answertext": "Paris",
                    "rightanswer": "true"
                }],"questiontext": "What is the capital city of France?"}}

        template = """
                // AI role
                Your role and purpose is now as an AI multiple-choice automated quiz writer, a backend text processor. AI response must be only a valid json output. Required: no AI commentary or tutorial, no AI introduction nor markdown.
                Give me {question_count} non repeating multiple choice questions about {output_summary} and don't exceed to the count of easy,medium and hard questions.
                INSTRUCTIONS
                - You are an AI Bot that is very good at mcq generatoion.
                - The questions should be at easy,medium and hard level of question and it has atleast 1 easy, 1 medium, and 1 hard questions. Generate MCQs of different difficulty levels based on the context.
                - Return your answer entirely in the form of a JSON object. 
                - The JSON object should have a key named "mcq" which is an array of the questions. Each quiz question should include the "code" like q1 ,"mark" (which always be 1) ,"options" ,"level" (difficulty level of question),"Tags"(Generate main topics or tags for questions that are contextually relevant to the content of the {output_summary}. 
                        Ensure that the generated topics or tags are specific to each question and reflect the overall theme of the document, avoiding generic terms. 
                        The goal is to maintain the integrity of the document while providing meaningful and pertinent tags for each question. 
                        The tags should be as close to the theme of the question from the section in the document and not just overall topics from the document itself. 
                        Each tag or topic should preferably be 1 but should not exceed 3 words and the maximum tags allowed is 3 for each question). 
                - Don't include anything other than the JSON. The JSON properties of each question should be 
                  "options" (which is an array of "answertext"(should have only answers with respect to question) and "rightanswer" (whether that answer is correct or not if the answer is correct than True viseversa there should be only one true option)),
                  "questiontext" (which will be the question),"level","Tags".Use should use this format only. 
                - quiz options should not exceed 5 words
                - Should not use article,document,book etc in the question because user are not aware of any document or article.Give the proper context in the question.
                - Should not have repeating questions.
                - quiz should have only 4 options, with one true and three deceptively false, random order.
                - quiz questions and options should be related to {output_summary} only.Don't give any questions out of this context.
               
                 --- 
                RESPONSE
                ## Example output 
                {feedback}

                """
        prompt = PromptTemplate(
            input_variables=["question_count","output_summary","feedback"],
            template=template,
        )
        
        final_prompt = prompt.format(question_count=question_count,output_summary=output_summary,feedback=feedback
                                    )
        return final_prompt
    @staticmethod
    def generate_mcq(question_count,output_summary):
        output_summary = output_summary
        final_prompt = ContextToQuizDataAccess.create_prompt_mcq(question_count,output_summary)
        messages = [{"role": "user", "content": final_prompt}]
        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            model="gpt-35-turbo",
            messages=messages,
            temperature=0,
            max_tokens=4000,
            top_p=0.95,
            frequency_penalty=0,
            presence_penalty=0,
            stop=None
        )
        mcq = response.choices[0].message["content"]
        mcq_json = json.loads(mcq)
        mcq_json=ContextToQuizDataAccess.remove_repeated_que(mcq_json,"mcq")
        mcq_json = json.loads(mcq_json)

        return mcq_json['mcq']

    def create_prompt__level_mcq(question_count,output_summary,easy,medium,hard):
    #feedback = {'Question': '', 'Alloptions': '','Rightoption': ''}
        feedback = {"mcq": {"Tags": "", "code": "", "level": "", "mark": "","options":[{
                            "answertext": "",
                            "rightanswer": "false"
                        },
                        {
                            "answertext": "",
                            "rightanswer": "false"
                        },
                        {
                            "answertext": "",
                            "rightanswer": "false"
                        },
                        {
                            "answertext": "",
                            "rightanswer": "true"
                        }],"questiontext": ""}}
        template = """
                // AI role
                Your role and purpose is now as an AI multiple-choice automated quiz writer, a backend text processor. AI response must be only a valid json output. Required: no AI commentary or tutorial, no AI introduction nor markdown.
                Give me {question_count} non repeating multiple choice questions about {output_summary} and don't exceed to {question_count} question.
                INSTRUCTIONS
                - You are an AI Bot that is very good at mcq generation.
                - Questions should generate {easy} easy question and don't exceed from {easy} for the easy question.
                - Questions should generate {medium} medium question and don't exceed from {medium} for the medium question.
                - Question should generate {hard} hard question and don't exceed from {hard} for the hard question.
                - Return your answer entirely in the form of a JSON object. 
                - The JSON object should have a key named "mcq" which is an array of the questions. Each quiz question should include the "code" like q1 ,"mark" (which always be 1) ,"options" ,"level" (difficulty level of question),"Tags"(Generate main topics or tags for questions that are contextually relevant to the content of the {output_summary}. 
                        Ensure that the generated topics or tags are specific to each question and reflect the overall theme of the document, avoiding generic terms. 
                        The goal is to maintain the integrity of the document while providing meaningful and pertinent tags for each question. 
                        The tags should be as close to the theme of the question from the section in the document and not just overall topics from the document itself. 
                        Each tag or topic should preferably be 1 but should not exceed 3 words and the maximum tags allowed is 3 for each question). 
                - Don't include anything other than the JSON. The JSON properties of each question should be 
                  "options" (which is an array of "answertext"(should have only answers with respect to question) and "rightanswer" (whether that answer is correct or not if the answer is correct than True viseversa there should be only one true option)),
                  "questiontext" (which will be the question),"level","Tags".Use should use this format only. 
                - quiz options should not exceed 5 words.
                - Should not use article,document,book etc in the question because user are not aware of any document or article.Give the proper context in the question.
                - quiz should have only 4 options, with one true and three deceptively false, random order.
                - Should not have repeating questions.
                - quiz questions and options should be related to {output_summary} only.Don't give any questions out of this context.

                --- 
                RESPONSE
                ## Example output 
                {feedback}
                """
        prompt = PromptTemplate(
            input_variables=["question_count","output_summary","easy","medium","hard","feedback"],
            template=template,
        )
        
        final_prompt = prompt.format(question_count=question_count,output_summary=output_summary,easy=easy,feedback=feedback,
                                     medium=medium,hard=hard
                                    )
        return final_prompt
    
    @staticmethod
    def generate__level_mcq(question_count,output_summary,mcq_diffls):
        output_summary = output_summary
        easy = mcq_diffls[0]
        medium = mcq_diffls[1]
        hard = mcq_diffls[2]
        question_count=sum(mcq_diffls)
        final_prompt = ContextToQuizDataAccess.create_prompt__level_mcq(question_count,output_summary,easy,medium,hard)
        messages = [{"role": "user", "content": final_prompt}]
        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            model="gpt-35-turbo",
            messages=messages,
            temperature=0,
            max_tokens=4000,
            top_p=0.95,
            frequency_penalty=0,
            presence_penalty=0,
            stop=None
        )
        mcq = response.choices[0].message["content"]
        # print(mcq)
        mcq_json = json.loads(mcq)
        mcq_json=ContextToQuizDataAccess.remove_repeated_que(mcq_json,"mcq")
        mcq_json = json.loads(mcq_json)
        # print(mcq_json)
        return mcq_json['mcq']