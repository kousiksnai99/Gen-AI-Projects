import json
import requests
from static_values import get_static_values
import azure.search.documents as azure_search
from azure.core.credentials import AzureKeyCredential
import openai
import os
from dotenv import load_dotenv
import logging

# Load environment variables
load_dotenv()

# Azure Search configuration
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT")
AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY")
AZURE_SEARCH_INDEX = "test-indexes"

# OpenAI configuration (ensure it’s set up correctly)
openai.api_key = os.getenv("OPENAI_API_KEY")
openai.api_base = os.getenv("OPENAI_API_BASE")
openai.api_type = "azure"
openai.api_version = "2024-08-01-preview"

# Configure logging (set to WARNING to suppress verbose HTTP logs, enable DEBUG for tracing)
logging.basicConfig(level=logging.WARNING)
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

def refine_with_llm(raw_response, original_query, fn_name):
    """Refine the raw API response using LLM for a concise, user-friendly output."""
    llm_prompt = [
        {"role": "system", "content": f"You are a helpful assistant. Provide a concise, WhatsApp-friendly response based on this raw data from the '{fn_name}' function: {raw_response}"},
        {"role": "user", "content": original_query}
    ]

    try:
        llm_response = openai.ChatCompletion.create(
            engine="gpt-4o-mini",
            model="gpt-4o-mini",
            messages=llm_prompt
        )
        return llm_response["choices"][0]["message"]["content"].replace("**", "*")
    except Exception as e:
        logger.error(f"Error refining with LLM: {e}")
        return raw_response  # Fallback to raw response if LLM fails

def process_function_call(fn_name, arguments):
    """Processes function calls dynamically by routing to the appropriate API or logic, then refining with LLM."""
    try:
        static_values = get_static_values()
        apis = static_values.get("apis", {})
        original_query = arguments.get("query", json.dumps(arguments))  # Use query if available, else full arguments

        # Handle existing API-based functions
        if fn_name in apis:
            api_details = apis[fn_name]
            api_url = api_details["url"]
            method = api_details["method"]
            headers = api_details.get("headers", {})

            body = json.dumps(arguments)
            response = requests.request(method=method, url=api_url, headers=headers, data=body)

            if response.status_code == 200:
                try:
                    raw_response = response.json().get("message", "Request processed successfully.")
                except ValueError:
                    raw_response = response.text
                # Refine the raw API response with LLM
                final_response = refine_with_llm(raw_response, original_query, fn_name)
                return final_response
            else:
                raw_error = f"Error: {response.status_code} - {response.text}"
                # Refine error message with LLM for better user experience
                final_response = refine_with_llm(raw_error, original_query, fn_name)
                return final_response

        # Handle Azure Search function
        elif fn_name == "search_azure":
            query = arguments["query"]
            messages = [{"role": "user", "content": query}]  # Minimal chat history for context

            # Perform the Azure Search
            credential = AzureKeyCredential(AZURE_SEARCH_KEY)
            search_client = azure_search.SearchClient(endpoint=AZURE_SEARCH_ENDPOINT, index_name=AZURE_SEARCH_INDEX, credential=credential)
            search_results = search_client.search(search_text=query, top=5)
            results = list(search_results)

            # Log raw results for debugging (optional, enable by setting logging to DEBUG)
            logger.debug(f"Azure Search results for '{query}': {[doc.get('content', 'No content field') for doc in results]}")

            # Check if results were found
            if not results:
                raw_response = f"Sorry, I couldn’t find any information for '{query}' in the search index."
            else:
                # Extract content from results
                context = " ".join([doc.get("content", "") for doc in results if "content" in doc])
                if not context.strip():
                    raw_response = f"No relevant content found for '{query}' in the search index."
                else:
                    raw_response = context

            # Refine with LLM regardless of result (success or failure)
            final_response = refine_with_llm(raw_response, query, fn_name)
            return final_response

        else:
            raw_response = f"No API or logic configuration found for function: {fn_name}"
            final_response = refine_with_llm(raw_response, original_query, fn_name)
            return final_response

    except Exception as e:
        raw_response = f"Failed to process request for '{arguments.get('query', 'unknown')}': {str(e)}. Please try again or refine your question."
        final_response = refine_with_llm(raw_response, original_query, fn_name)
        return final_response