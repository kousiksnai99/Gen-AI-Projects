from pathlib import Path
from langchain.text_splitter import TokenTextSplitter
from flask import jsonify
from flask import current_app, jsonify
from langchain.chains import ConversationalRetrievalChain
from langchain.prompts import PromptTemplate
from langchain_community.vectorstores import AzureSearch
from langchain.vectorstores.azuresearch import AzureSearch
from flask import current_app
from langchain.document_loaders.pdf  import UnstructuredPDFLoader
from langchain_community.document_loaders import CSVLoader, UnstructuredCSVLoader
from langchain_community.document_loaders import UnstructuredPDFLoader, UnstructuredWordDocumentLoader, CSVLoader, UnstructuredCSVLoader
from langchain.document_loaders.word_document import UnstructuredWordDocumentLoader
from langchain.document_loaders import YoutubeLoader
from langchain.chains.summarize import load_summarize_chain
from dotenv import load_dotenv
import os
import pandas as pd
import azure.cognitiveservices.speech as speechsdk
from azure.identity import ManagedIdentityCredential
from azure.search.documents import SearchClient  
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import SearchIndex, SimpleField, SearchableField
from azure.core.credentials import AzureKeyCredential
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.storage.filedatalake import DataLakeServiceClient
import gtts
from moviepy.editor import *
from azure.keyvault.secrets import SecretClient
import codecs
from langchain.document_loaders.csv_loader import UnstructuredCSVLoader
import time
import logging
from opencensus.ext.azure.log_exporter import AzureLogHandler
from langchain.document_loaders.csv_loader import CSVLoader
import pymssql
import pymupdf
import fitz  # PyMuPDF
from PIL import Image
from flask import Flask, request, jsonify
import google.generativeai as genai
import re
import requests as req
import openpyxl
from openpyxl.styles import Font, Alignment
import hashlib
from docx import Document
import io
        
#--------------------------------------#
import requests
from urllib.request import Request,urlopen
import urllib.request
import bs4 as bs
from bs4 import BeautifulSoup
from langchain.document_loaders import UnstructuredURLLoader
from youtube_transcript_api import YouTubeTranscriptApi

load_dotenv()

#-----------------------------Intializing secrets------------------------------

'''credential = ManagedIdentityCredential()
KEYVAULT_NAME = os.environ['KEYVAULT_NAME']
client = SecretClient(f"https://{KEYVAULT_NAME}.vault.azure.net/",credential)

openai_api_token = client.get_secret("openai-api-token")
openai_api_token = openai_api_token.value

vector_store_password = client.get_secret("cognetive-service-password")
vector_store_password = vector_store_password.value

vector_store_address = client.get_secret("cognetive-service-endpoint")
vector_store_address = vector_store_address.value

api_base = client.get_secret("openai-api-base")
api_base = api_base.value


account_key = client.get_secret("ai-knowledge-base-account-key")
account_key = account_key.value


instrumentation_key = client.get_secret("application-insights-instrumentation-key")
instrumentation_key = instrumentation_key.value

container_name = os.environ['STORAGE_CONTAINER_NAME']
account_name = os.environ['STORAGE_ACCOUNT_NAME']'''

#-----------------------------------------------------------

container_name = os.environ['STORAGE_CONTAINER_NAME']
account_name = os.environ['STORAGE_ACCOUNT_NAME']
instrumentation_key = os.getenv('Instrumentation_Key')
vector_store_address = os.getenv('cognetive-service-endpoint')
vector_store_password = os.getenv('cognetive-service-password')
api_base = os.getenv('openai-api-base')
openai_api_token = os.getenv('openai-api-token')
account_key = os.getenv('ai-knowledge-base-account-key')
application_token = os.getenv('ai-application-token')

api_type = "azure"
api_version =  "2024-08-01-preview"
region = "eastus"


#----------------remove------------
#---------------remove--------------

#------------------------#Intializing the logging-------------------------

output_folder = "spireimages"
os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))


logger = logging.getLogger(__name__)
logger.addHandler(AzureLogHandler(
    connection_string=f'InstrumentationKey={instrumentation_key}')
)

server=os.getenv("server")
database=os.getenv("database")
username=os.getenv("db_username")
password=os.getenv("password")


class KnowledgeBaseDataAcess:
    #from the pdf file extracting the text
    @staticmethod
    def get_data_fromgemini(image_path):
        input_prompt = """
               You are an expert in understanding and analyzing images, flowcharts.
               You will receive images as input &
               you have to describe the image properly with all key information included.
               Describe the image and if the whole image is black or grey in color then give "Nothing" as a response.
               Don't make any assumption for the image.
               """
        img = Path(image_path)
        image_parts = [
            {
                "mime_type": "image/png",
                "data": img.read_bytes()
            }
        ]
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content([input_prompt, image_parts[0], "Give all the details of the image if there is text present"])
        print(response.text)
        return response.text

    @staticmethod
    def extract_images_unique(pdf_document, images_path):
        page_nums = len(pdf_document)
        images_list = []
        processed_hashes = set()
        saved_images = []

        for page_num in range(page_nums):
            page_content = pdf_document[page_num]
            images_list.extend(page_content.get_images(full=True))

        for i, img in enumerate(images_list, start=1):
            xref = img[0]
            base_image = pdf_document.extract_image(xref)
            image_bytes = base_image['image']
            image_ext = base_image['ext']

            image_hash = hashlib.md5(image_bytes).hexdigest()

            if image_hash not in processed_hashes:
                image_name = f"image_{i}.{image_ext}"
                image_path = os.path.join(images_path, image_name)
                with open(image_path, 'wb') as image_file:
                    image_file.write(image_bytes)
                processed_hashes.add(image_hash)
                saved_images.append(image_path)

        return saved_images


    @staticmethod
    def extract_text_and_images_from_pdf(pdf_path):
        pdf_document = pymupdf.open(pdf_path)
        os.makedirs(output_folder, exist_ok=True)
        extracted_content = ""
        all_image_descriptions = ""

        def process_page(page):
            text = page.get_text()
            print("Page text:", text)
            return text

        for page in pdf_document:
            extracted_content += process_page(page)

        unique_images = KnowledgeBaseDataAcess.extract_images_unique(pdf_document, output_folder)
        for img_path in unique_images:
            image_description = KnowledgeBaseDataAcess.get_data_fromgemini(img_path)
            all_image_descriptions += " " + image_description

        extracted_content += " " + all_image_descriptions
        extracted_content = re.sub(r'[^A-Za-z0-9\s]', '', extracted_content)
        extracted_content = re.sub(r'\s+', ' ', extracted_content)
        extracted_content = extracted_content.strip()

        with open("extracted_text.txt", "w", encoding="utf-8") as text_file:
            text_file.write(extracted_content)
        return extracted_content


    #Static method for web scraping
    @staticmethod
    def web_scrapping(sample_website):
        try:
            # Sample website URL
            print(f"Requested URL: {sample_website}")
            Requested_page = Request(sample_website)
            try:
                page = urlopen(Requested_page)
            except Exception as e:
                print(f"Error opening URL: {e}")
                return {"statusCode": 500,
                        "statusMessage": "Uploaded URL is incorrect. Please upload a correct one"
                        }

            soup = bs.BeautifulSoup(page, "lxml")
            links = []
            for link in soup.findAll("a"):
                href = link.get('href')
                if href and "http" in href:
                    links.append(href)

            print(f"Found links: {links}")

            loader = UnstructuredURLLoader(urls=links)
            data = loader.load()
            link = [info.metadata for info in data]
            records = [info.page_content for info in data]

            print(f"Raw records: {records}")

            remove_nc = [nc.replace("\n", " ") for nc in records]  # remove new lines
            remove_tab = [rt.replace("\t", " ") for rt in remove_nc]  # remove tabs
            final_data = [re.sub(' +', ' ', string) for string in remove_tab]  # remove extra spaces
            final_datas = [rt.replace("\r", " ") for rt in final_data]

            print(f"Processed data: {final_datas}")

            return {"statusCode": 200,
                    "statusMessage": "Uploaded URL is correct.",
                    "dataAttached": {"scrappedData": final_datas}
                    }
        except Exception as e:
            print(f"An error occurred: {e}")
            return {"statusCode": 500,
                    "statusMessage": "An error occurred during processing."
                    }

    #Making the chunks from the text
    @staticmethod
    def __get_text_chunks(text,doc=False):

        text_splitter = TokenTextSplitter(chunk_size=500, chunk_overlap=100)
        if(doc==False):
            chunks = text_splitter.split_text(text)
        else:
            text_splitter = TokenTextSplitter(chunk_size=500, chunk_overlap=100)
            chunks = text_splitter.split_documents(text)
        print("length of chunks are ",len(chunks))
        return chunks

    #getting the text from the document
    @staticmethod
    def __get_docx_to_text(docxPath):
        unDoc = UnstructuredWordDocumentLoader(docxPath)
        docs = unDoc.load()
        text = ""
        for doc in docs:
            text += doc.page_content

        return text

    #getting the image text from the document
    @staticmethod
    def extract_images_from_docx(docx_path, images_path):
        
        document = Document(docx_path)
        saved_images = []
        
        # Extract images from docx
        for rel in document.part.rels.values():
            if "image" in rel.target_ref:
                img = rel.target_part.blob
                image_hash = hashlib.md5(img).hexdigest()
                image_ext = rel.target_part.content_type.split('/')[-1]
                image_name = f"{image_hash}.{image_ext}"
                image_path = os.path.join(images_path, image_name)
                
                if not os.path.exists(image_path):
                    with open(image_path, 'wb') as f:
                        f.write(img)
                    saved_images.append(image_path)

        return saved_images
    
    #getting the text from csv file
    @staticmethod
    def __get_csv_data(csvPath):
        try:
            try:
                loader = loader = CSVLoader(file_path=csvPath, encoding="utf-8", csv_args={'delimiter':',|;'})
                data=loader.load()
                return data
            except:
                BLOCKSIZE = 1048576 # or some other, desired size in bytes
                with codecs.open(csvPath, "r",encoding='utf-8',errors='ignore') as sourceFile:
                    with codecs.open("targetcsv.csv", "w", "utf-8") as targetFile:
                        while True:
                            contents = sourceFile.read(BLOCKSIZE)
                            if not contents:
                                break
                            targetFile.write(contents)
                loader = loader = CSVLoader(file_path="targetcsv.csv", encoding="utf-8", csv_args={'delimiter':','})
                data=loader.load()
                return data
        except:
            try:
                loader = UnstructuredCSVLoader(csvPath)
                data=loader.load()
                return data
            except:
                BLOCKSIZE = 1048576 # or some other, desired size in bytes
                with codecs.open(csvPath, "r",encoding='utf-8',errors='ignore') as sourceFile:
                    with codecs.open("targetcsv.csv", "w", "utf-8") as targetFile:
                        while True:
                            contents = sourceFile.read(BLOCKSIZE)
                            if not contents:
                                break
                            targetFile.write(contents)
                loader = UnstructuredCSVLoader("targetcsv.csv")
                data=loader.load()
                return data

    #getting the text from excel file
    def __get_excel_text(excelfile):
        try:
            try:
                loader = loader = CSVLoader(file_path=excelfile, encoding="utf-8", csv_args={'delimiter':','})
                data=loader.load()
                return data
            except:
                BLOCKSIZE = 1048576 # or some other, desired size in bytes
                with codecs.open(excelfile, "r",encoding='utf-8',errors='ignore') as sourceFile:
                    with codecs.open("targetcsv.csv", "w", "utf-8") as targetFile:
                        while True:
                            contents = sourceFile.read(BLOCKSIZE)
                            if not contents:
                                break
                            targetFile.write(contents)
                loader = loader = CSVLoader(file_path="targetcsv.csv", encoding="utf-8", csv_args={'delimiter':','})
                data=loader.load()
                return data
        except:
            try:
                loader = UnstructuredCSVLoader(excelfile)
                data=loader.load()
                return data
            except:
                BLOCKSIZE = 1048576 # or some other, desired size in bytes
                with codecs.open(excelfile, "r",encoding='utf-8',errors='ignore') as sourceFile:
                    with codecs.open("targetcsv.csv", "w", "utf-8") as targetFile:
                        while True:
                            contents = sourceFile.read(BLOCKSIZE)
                            if not contents:
                                break
                            targetFile.write(contents)
                loader = UnstructuredCSVLoader("targetcsv.csv")
                data=loader.load()
                return data

    #adding the vectors to the cognitive search index
    @staticmethod
    def __get_vectorstore(data, filename, file_present, user_role, source=None, is_text_chunked=True):
        embeddings = current_app.embeddingsModel
        index_name = "test-indexes"
        vector_store = AzureSearch(
            azure_search_endpoint=vector_store_address,
            azure_search_key=vector_store_password,
            index_name=index_name,
            embedding_function=embeddings.embed_query,
        )

        Id_directory = "File_ids/"
        credential = AzureKeyCredential(vector_store_password)
        service_url = f"https://{account_name}.dfs.core.windows.net"
        service_client = DataLakeServiceClient(account_url=service_url, credential=account_key)
        file_system_client = service_client.get_file_system_client(file_system=container_name)

        # Handle deletion of existing vectors
        if file_present == "True":
            with open("vector_id.txt", "r") as file:
                content = file.readlines()
            search_client = SearchClient(vector_store_address, index_name, credential)
            for id in content:
                id = id.strip()  # Use strip() to clean new lines
                print(f"Deleting vector with id: {id}")
                search_client.delete_documents(documents=[{"id": id}])
            print("Deleted existing vectors")
        else:
            print("Vectors of this file don't exist")

        try:
            # Prepare metadata based on document content
            if is_text_chunked:
                # Create a metadata list with user_role and source for each document chunk
                metadata = [{"user_role": user_role, "source": source} for _ in data]
                print(f"Adding texts to vector store with user roles: {user_role} and source URL: {source}")

                vec = vector_store.add_texts(data, metadatas=metadata)
                
                with open('vector_id.txt', 'w') as f:
                    for i in vec:
                        f.write(f"{i}\n")

                id_file = filename.rsplit('.', 1)[0]
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                with open("vector_id.txt", "rb") as local_file:
                    file_client.upload_data(local_file, overwrite=True)
                print("Text is added in vector store")
            else:
                vector_list = []
                for ls in data:
                    # Create metadata list for each document
                    metadata = [{"user_role": user_role, "source": source} for _ in ls]
                    print(f"Adding documents to vector store with user roles: {user_role} and source URL: {source}")

                    vec = vector_store.add_documents(ls, metadatas=metadata)
                    vector_list.extend(vec)  # Use extend() to flatten the list of vectors
                    print("Added data", len(ls))
                    time.sleep(4)

                with open('vector_id.txt', 'w') as f:
                    for vectors in vector_list:
                        f.write(f"{vectors}\n")

                id_file = filename.rsplit('.', 1)[0]
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                with open("vector_id.txt", "rb") as local_file:
                    file_client.upload_data(local_file, overwrite=True)
                print("Document is added in vector store")
        except Exception as e:
            logger.exception('An error occurred: %s', str(e))
        print("-------Vector store Created----")

    #Making the conversation chain
    @staticmethod
    def __get_conversation_chain(user_role):
        print("inside conversation chain")
        llm = current_app.llmHuggingFace
        print("llm created")
        embeddings = current_app.embeddingsModel
        
        custom_prompt = """Use the following pieces of context to answer the question at the end.
        
        You must base your answer solely on the provided context without adding any external information or making assumptions. If the context does not provide a clear answer, respond with "Sorry, I don't have an answer to this question yet. Please rephrase your question or ask me another one.
        Context: {context}

        Question: {question}

        Instructions:
            Keep the answer in English always.
            Utilize the given information to construct your response.
            Should include forms of verbs as well.
            Offer specific answers without justification or additional input.
            When responding, refrain from using any terms that refer to the source of the information.
            Answer in user-friendly formatting such as bullets, digits, or multilevel lists if necessary for clarity."""

        custom_prompt_template = PromptTemplate(template=custom_prompt, input_variables=["context", "question"])
        print("created")
        index_name = "test-indexes"
        vector_store = AzureSearch(
            azure_search_endpoint=vector_store_address,
            azure_search_key=vector_store_password,
            index_name=index_name,
            embedding_function=embeddings.embed_query,
        )
        print("Retriever created")
        retriever = vector_store.as_retriever()
        
        conversation_chain = ConversationalRetrievalChain.from_llm(
            llm=llm,
            max_tokens_limit=4096,
            retriever=retriever,
            combine_docs_chain_kwargs={"prompt": custom_prompt_template},
            chain_type="stuff"
        )

        return conversation_chain
 
    
    #making chunk of 250 for processing large excel and csv files
    @staticmethod
    def make_chunk(text_chunks):
        sublists=[]
        for i in range(0, len(text_chunks), 250):
            sublist = text_chunks[i:i+250]
            sublists.append(sublist)
        return sublists

    #All the function will be call for the pdf extracting the text, dividing the text into chunks , adding the vectors in the cognitive search.    
    @staticmethod
    def process_pdf(pdfPath, filename, file_present, user_role):
        text = KnowledgeBaseDataAcess.extract_text_and_images_from_pdf(pdfPath)
        text_chunks = KnowledgeBaseDataAcess.__get_text_chunks(text)
        
        KnowledgeBaseDataAcess.__get_vectorstore(text_chunks, filename, file_present, user_role)
        
        try:
            os.remove('vector_id.txt')
        except:
            print("file not exist")
            
        return "summary"

    #All the function will be call for the docx extracting the text, dividing the text into chunks , adding the vectors in the cognitive search.    
    @staticmethod
    def process_docx(docxPath, filename, file_present, user_role):
        text = KnowledgeBaseDataAcess.__get_docx_to_text(docxPath)
        
        # Extract images and convert to text using Gemini
        os.makedirs(output_folder, exist_ok=True)
        images = KnowledgeBaseDataAcess.extract_images_from_docx(docxPath, output_folder)
        
        image_descriptions = ""
        for img_path in images:
            image_description = KnowledgeBaseDataAcess.get_data_fromgemini(img_path)
            image_descriptions += " " + image_description
        
        combined_content = text + " " + image_descriptions
        combined_content = re.sub(r'[^A-Za-z0-9\s]', '', combined_content)
        combined_content = re.sub(r'\s+', ' ', combined_content)
        combined_content = combined_content.strip()

        print("Combined content from DOCX:", combined_content)
        
        text_chunks = KnowledgeBaseDataAcess.__get_text_chunks(combined_content)
        KnowledgeBaseDataAcess.__get_vectorstore(text_chunks, filename, file_present, user_role)
        
        try:
            os.remove('vector_id.txt')
        except:
            print("file not exist")
        
        return "summary"
   
    #All the function will be call for the csv extracting the text, dividing the text into chunks , adding the vectors in the cognitive search   
    @staticmethod
    def process_csv(csvPath,filename, file_present, user_role):
        data = KnowledgeBaseDataAcess.__get_csv_data(csvPath)
        text_chunks = KnowledgeBaseDataAcess.__get_text_chunks(data,doc=True)
        chunked=KnowledgeBaseDataAcess.make_chunk(text_chunks)
        KnowledgeBaseDataAcess.__get_vectorstore(chunked,filename,file_present, user_role, is_text_chunked=False)
        try:
            os.remove("targetcsv.csv")
        except:
            print("No target.csv present")
        try:
            os.remove('vector_id.txt')
        except:
            print("file not exist")
        summary = "No Summary for CSV file"
        return  summary

    #All the function will be call for the excel extracting the text, dividing the text into chunks , adding the vectors in the cognitive search   
    @staticmethod
    def process_excel(excelPath, filename, file_present, user_role):
        text = KnowledgeBaseDataAcess.__get_excel_text(excelPath)
        text_chunks = KnowledgeBaseDataAcess.__get_text_chunks(text,doc=True)
        chunked=KnowledgeBaseDataAcess.make_chunk(text_chunks)
        KnowledgeBaseDataAcess.__get_vectorstore(chunked,filename,file_present,user_role,is_text_chunked=False)
        try:
            os.remove("targetcsv.csv")
        except:
            print("No target.csv present")
        try:
            os.remove('vector_id.txt')
        except:
            print("file not exist")
        summary = "No Summary for excel file"
        return  summary 
    
    @staticmethod
    def remove_special_characters_at_end(text):
        special_characters = set("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
        i = len(text) - 1
        while i >= 0 and text[i] in special_characters:
            i -= 1
        return text[:i+1]

    #handling the user asked question
    @staticmethod
    def handle_user_asked_question(user_question, session_id, user_role):
        user_question = KnowledgeBaseDataAcess.remove_special_characters_at_end(user_question)
        print("user_question is ====", user_question)
        
        # Get conversation chain with custom retriever
        conversation_chain = KnowledgeBaseDataAcess.__get_conversation_chain(user_role)
        print("till here")
        if not session_id or not user_question or not user_role:
            return jsonify({'error': 'Invalid input data'}), 400

        try:
            conn = pymssql.connect(server=server, user=username, password=password, database=database)
            cursor = conn.cursor()

            # Retrieve chat history for the session
            cursor.execute("SELECT Content FROM dbo.ChatHistory WHERE SessionID = %s", (session_id,))
            row = cursor.fetchone()

            if row:
                # Load existing chat history and limit it to the last 3 exchanges
                chat_history = row[0]
                history = re.findall(r"User: (.*?)\nBot: (.*?)\n", chat_history, re.DOTALL)
                history = history[-3:]  
            else:
                history = []
            print("till here too")
            # Retrieve relevant documents
            results = conversation_chain.retriever.get_relevant_documents(user_question)
            print(f"Retrieved documents: {results}")
            
            # Filter the results based on either of the user_role
            filtered_results = []
            for doc in results:
                roles = [role.strip() for role in doc.metadata.get("user_role", [])] 
                # Check if either role is present in the document metadata
                if any(user_role.strip() in roles for user_role in user_role):
                    filtered_results.append(doc)
            
            print(f"Filtered documents: {filtered_results}")
            
            if not filtered_results:
                answer = "Sorry, I don't have an answer to this question yet. Please rephrase your question or ask me another one."
            else:
                # Build context only from filtered results
                context = "\n\n".join([doc.page_content for doc in filtered_results])
                print("upper")
                answer = conversation_chain(
                    {"question": user_question, "context": context, "chat_history": history}
                )["answer"]
                print("lower")
            # Update or insert chat history
            if row:
                # Append new interaction to existing chat history
                updated_chat_history = chat_history + f"\nUser: {user_question}\nBot: {answer}"
                # Keep only the last 3 exchanges (6 lines)
                history_lines = updated_chat_history.split('\n')
                if len(history_lines) > 6:
                    updated_chat_history = '\n'.join(history_lines[-6:])
                cursor.execute("UPDATE dbo.ChatHistory SET Content = %s WHERE SessionID = %s", (updated_chat_history, session_id))
            else:
                # Insert new chat history record
                new_chat_history = f"User: {user_question}\nBot: {answer}"
                cursor.execute("INSERT INTO dbo.ChatHistory (SessionID, Content) VALUES (%s, %s)", (session_id, new_chat_history))

            conn.commit()
            print('Chat history updated')  # Debugging print
            return jsonify({'message': answer})

        except Exception as e:
            return jsonify({'error': str(e)}), 500

        finally:
            conn.close()
            cursor.close()

    #Static method to process URL knowledge
    @staticmethod
    def process_URL_knowledge(url, user_role):
        try:
            # Scrape the website data
            websiteData = KnowledgeBaseDataAcess.web_scrapping(url)

            if websiteData["statusCode"] != 200:
                # Return error response if the scraping fails
                return jsonify({
                    "statusCode": websiteData["statusCode"],
                    "statusMessage": websiteData["statusMessage"],
                    "dataAttached": None,
                    "success": False
                })

            print("Website data fetched successfully.")
            data = websiteData["dataAttached"]["scrappedData"]

            # Assuming filename can be derived from the URL or set to a placeholder
            filename = url.split("/")[-1] if url.split("/")[-1] else "scrapped_web_data"
            file_present = True  # Since you have scrapped the website data, the file is considered present

            # Process the data to create vectorstore
            result = KnowledgeBaseDataAcess.__get_vectorstore(data, filename, file_present, user_role, source=url)

            # Return success response
            return jsonify({
                "success": True,
                "message": "Vectorstore successfully created",
            })

        except Exception as e:
            print(f"Error processing URL: {e}")
            return jsonify({
                "success": False,
                "message": f"An error occurred while processing the URL: {str(e)}"
            })

    # Adding the vectors to the cognitive search index
    @staticmethod
    def getvector(data, filename, file_present, user_role, source=None, is_text_chunked=True):
        embeddings = current_app.embeddingsModel
        index_name = "test-indexes"
        vector_store = AzureSearch(
            azure_search_endpoint=vector_store_address,
            azure_search_key=vector_store_password,
            index_name=index_name,
            embedding_function=embeddings.embed_query,
        )

        Id_directory = "File_ids/"
        credential = AzureKeyCredential(vector_store_password)
        service_url = f"https://{account_name}.dfs.core.windows.net"
        service_client = DataLakeServiceClient(account_url=service_url, credential=account_key)
        file_system_client = service_client.get_file_system_client(file_system=container_name)

        # Handle deletion of existing vectors if file_present is True
        if file_present == "True":
            with open("vector_id.txt", "r") as file:
                content = file.readlines()
            search_client = SearchClient(vector_store_address, index_name, credential)
            for id in content:
                id = id.strip()  # Strip any newline characters
                print(f"Deleting vector with id: {id}")
                search_client.delete_documents(documents=[{"id": id}])
            print("Deleted existing vectors")
        else:
            print("Vectors of this file don't exist")

        try:
            # Function to chunk text into smaller pieces
            def chunk_text(text, chunk_size=500):
                words = text.split()
                chunks = []
                current_chunk = []

                for word in words:
                    if len(" ".join(current_chunk + [word])) <= chunk_size:
                        current_chunk.append(word)
                    else:
                        chunks.append(" ".join(current_chunk))
                        current_chunk = [word]
                
                if current_chunk:
                    chunks.append(" ".join(current_chunk))
                
                return chunks

            # If data is a single string, chunk it before processing
            if is_text_chunked and isinstance(data, str):
                data = chunk_text(data)  # Chunk text into smaller pieces

            # Prepare metadata based on document content
            if is_text_chunked:
                # Create metadata list with user_role and source for each document chunk
                metadata = [{"user_role": user_role, "source": source} for _ in data]
                print(f"Adding texts to vector store with user roles: {user_role} and source URL: {source}")

                # Add the chunked text to the vector store
                vec = vector_store.add_texts(data, metadatas=metadata)

                # Store vector IDs in a text file and upload to Azure Data Lake
                with open('vector_id.txt', 'w') as f:
                    for i in vec:
                        f.write(f"{i}\n")

                id_file = filename.rsplit('.', 1)[0]
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                with open("vector_id.txt", "rb") as local_file:
                    file_client.upload_data(local_file, overwrite=True)
                print("Text is added in vector store")
            else:
                vector_list = []
                for ls in data:
                    # Create metadata for each document or chunk
                    metadata = [{"user_role": user_role, "source": source} for _ in ls]
                    print(f"Adding documents to vector store with user roles: {user_role} and source URL: {source}")

                    # Add documents to the vector store
                    vec = vector_store.add_documents(ls, metadatas=metadata)
                    vector_list.extend(vec)  # Flatten the list of vectors
                    print("Added data", len(ls))
                    time.sleep(4)

                # Write vector IDs to a file and upload to Azure Data Lake
                with open('vector_id.txt', 'w') as f:
                    for vectors in vector_list:
                        f.write(f"{vectors}\n")

                id_file = filename.rsplit('.', 1)[0]
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                with open("vector_id.txt", "rb") as local_file:
                    file_client.upload_data(local_file, overwrite=True)
                print("Document is added in vector store")

        except Exception as e:
            logger.exception('An error occurred: %s', str(e))
        print("-------Vector store Created----") 

    def process_youtube_link(url, user_role):
        try:
            # Check if the URL is a YouTube link
            youtube_regex = r"(https?://)?(www\.)?(youtube|youtu|youtube-nocookie)\.(com|be)/.+"
            print(youtube_regex)
            if re.match(youtube_regex, url):
                # Process the YouTube URL
                transcription = KnowledgeBaseDataAcess.transcribe_youtube_video(url)
                print(transcription)
                if not transcription:
                    return jsonify({
                        "success": False,
                        "message": "Failed to transcribe YouTube video.",
                    })

                # Assuming filename can be derived from the URL or set to a placeholder
                filename = url.split("/")[-1] if url.split("/")[-1] else "youtube_video_transcription"
                file_present = True  # Data is processed from YouTube, so file is considered present

                # Process the transcription to create vectorstore
                result = KnowledgeBaseDataAcess.getvector(transcription, filename, file_present, user_role, source=url)

                # Return success response
                return jsonify({
                    "success": True,
                    "message": "Vectorstore successfully created for YouTube video transcription",
                })

            # Scrape the website data for non-YouTube URLs
            websiteData = KnowledgeBaseDataAcess.web_scrapping(url)

            if websiteData["statusCode"] != 200:
                # Return error response if scraping fails
                return jsonify({
                    "statusCode": websiteData["statusCode"],
                    "statusMessage": websiteData["statusMessage"],
                    "dataAttached": None,
                    "success": False
                })

            print("Website data fetched successfully.")
            data = websiteData["dataAttached"]["scrappedData"]

            # Assuming filename can be derived from the URL or set to a placeholder
            filename = url.split("/")[-1] if url.split("/")[-1] else "scrapped_web_data"
            file_present = True  # File is considered present since data is scraped

            # Process the data to create vectorstore
            result = KnowledgeBaseDataAcess.getvector(data, filename, file_present, user_role, source=url)

            # Return success response
            return jsonify({
                "success": True,
                "message": "Vectorstore successfully created",
            })

        except Exception as e:
            print(f"Error processing URL: {e}")
            return jsonify({
                "success": False,
                "message": f"An error occurred while processing the URL: {str(e)}"
            })   
    
    @staticmethod
    def transcribe_youtube_video(url):
        try:
            # Function to extract video ID from the URL
            def extract_video_id(youtube_url):
                # Regular expression patterns to handle multiple YouTube URL formats
                patterns = [
                    r"youtu\.be/([0-9A-Za-z_-]{11})", 
                    r"youtube\.com/watch\?v=([0-9A-Za-z_-]{11})", 
                    r"youtube\.com/embed/([0-9A-Za-z_-]{11})", 
                    r"youtube\.com/v/([0-9A-Za-z_-]{11})", 
                    r"youtube\.com/shorts/([0-9A-Za-z_-]{11})"  
                ]

                for pattern in patterns:
                    match = re.search(pattern, youtube_url)
                    if match:
                        return match.group(1) 

                return None  

            # Extract video ID using the new function
            video_id = extract_video_id(url)

            if not video_id:
                raise ValueError("Could not extract video ID from the URL.")
            print(f"Extracted video ID: {video_id}")  

            # Fetch the transcript
            transcript = YouTubeTranscriptApi.get_transcript(video_id)

            # Initialize an empty list to hold sentences
            sentences = []
            sentence = ""

            # Combine transcript segments into sentences
            for segment in transcript:
                text = segment['text']
                sentence += text + " "  
                if any(text.endswith(p) for p in ['.', '!', '?']):
                    sentences.append(sentence.strip()) 
                    sentence = ""  
            if sentence:
                sentences.append(sentence.strip())
            transcription = " ".join(sentences)
            return transcription
        except Exception as e:
            print(f"Error transcribing YouTube video: {e}")  
            return None    