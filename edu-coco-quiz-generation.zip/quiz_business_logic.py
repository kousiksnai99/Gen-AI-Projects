from quiz_data_access import ContextToQuizDataAccess
from flask import jsonify
from langchain_community.document_loaders import UnstructuredPDFLoader
from langchain_community.document_loaders import UnstructuredWordDocumentLoader
from werkzeug.utils import secure_filename
from flask import current_app
import os
import re
import time
import datetime  
from langchain_core.prompts import PromptTemplate
import openai
import pandas as pd
import codecs
from langchain_community.document_loaders import UnstructuredCSVLoader
#from azure.identity import ManagedIdentityCredential
#from azure.keyvault.secrets import SecretClient
import logging
from opencensus.ext.azure.log_exporter import AzureLogHandler

#----------------------------------------------------------------------

'''credential = ManagedIdentityCredential()
KEYVAULT_NAME = os.environ['KEYVAULT_NAME']
client = SecretClient(f"https://{KEYVAULT_NAME}.vault.azure.net/",credential)'''

#instrumentation_key = client.get_secret("application-insights-instrumentation-key")
instrumentation_key = "fa7c940a-3964-4831-ab9c-85898db7f3aa"

logger = logging.getLogger(__name__)
logger.addHandler(AzureLogHandler(
    connection_string=f'InstrumentationKey={instrumentation_key}')
)

#===============================remove after testing================
#===============================remove after testing================


DEFAULT_QUESTION_COUNT = 10
ALLOWED_EXTENSIONS = {'pdf', 'docx','xls','xlsx','csv'}

class ContextToQuestionService:
    @staticmethod
    def __allowed_file(filename):
        return '.' in filename and \
            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

    #checking the extension and on the basis of extension respective function will call 
    @staticmethod
    def __process_document_cases(fileExt, file_path_to_save,filename):
        if fileExt == 'pdf':
            text = ""
            pdf_reader = UnstructuredPDFLoader(file_path_to_save)
            docs = pdf_reader.load()
            text = ""
            for doc in docs:
                text += doc.page_content
            text = re.sub(r'\s+',' ',text)
            # text.replace("(cid:415)")
            return text
        
        elif fileExt == 'docx':
            unDoc = UnstructuredWordDocumentLoader(file_path_to_save)
            docs = unDoc.load()
            text = ""
            for doc in docs:
                text += doc.page_content
            text = re.sub(r'\s+',' ',text)
            return text
        
        elif (fileExt == 'xlsx') or (fileExt == 'xls'):
            output = os.path.join(current_app.config['UPLOAD_FOLDER'], "output.csv")
            df = pd.read_excel(file_path_to_save, header=0)
            df.to_csv(output, index=False)
            try:
                loader = UnstructuredCSVLoader(output)
                data=loader.load()
                return data
            except:
                BLOCKSIZE = 1048576 # or some other, desired size in bytes
                with codecs.open(output, "r",encoding='utf-8',errors='ignore') as sourceFile:
                    with codecs.open("targetcsv.csv", "w", "utf-8") as targetFile:
                        while True:
                            contents = sourceFile.read(BLOCKSIZE)
                            if not contents:
                                break
                            targetFile.write(contents)
                loader = UnstructuredCSVLoader("targetcsv.csv")
                data=loader.load()
                os.remove("targetcsv.csv")
                os.remove(output)
                return data
        elif (fileExt=="csv"):
            try:
                loader = UnstructuredCSVLoader(file_path_to_save)
                data=loader.load()
                return data
            except:
                BLOCKSIZE = 1048576 # or some other, desired size in bytes
                with codecs.open(file_path_to_save, "r",encoding='utf-8',errors='ignore') as sourceFile:
                    with codecs.open("targetcsv.csv", "w", "utf-8") as targetFile:
                        while True:
                            contents = sourceFile.read(BLOCKSIZE)
                            if not contents:
                                break
                            targetFile.write(contents)
                loader = UnstructuredCSVLoader("targetcsv.csv")
                data=loader.load()
                os.remove("targetcsv.csv")
                return data


    @staticmethod
    def __question_count_validation(question_count):
        validated_count = int(DEFAULT_QUESTION_COUNT)
        if question_count is not None:
            try:
                validated_count = int(question_count)
            except Exception:
                raise ValueError("Invalid question count")

        return validated_count
    
    @staticmethod
    def get_keywords(output_summary):
        template = """
        // AI role
        Generate main covered topics from ${output_summary} and don't exceed to 4 words.If generated covered topic is greater than 6 then generate the most relevant 6 covered topics .
        """
        prompt = PromptTemplate(
            input_variables=["output_summary"],
            template=template,
        )
        final_prompt = prompt.format(output_summary=output_summary)

        messages = [{"role": "user", "content": final_prompt}]
        response = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            model="gpt-35-turbo",
            messages=messages,
            temperature=0,
            max_tokens=2048,
            top_p=0.95,
            frequency_penalty=0,
            presence_penalty=0,
            stop=None
        )
        Tags = response.choices[0].message["content"]
        return Tags

    
    #Generate the summary first and then MCQ
    @staticmethod
    def get_mcq(text, question_count,Tags,summary):
        
        try:
            validated_question_count = ContextToQuestionService.__question_count_validation(question_count)
            if (validated_question_count==0):
                qustions = ContextToQuizDataAccess.generate__level_mcq(validated_question_count, summary, Tags, mcq_diffls)
            else:
                qustions = ContextToQuizDataAccess.generate_mcq(validated_question_count, summary,Tags)
                qustions =  qustions[:validated_question_count]
            
            for i in range(int(validated_question_count)):
                ts = time.time()
                qustions[i]['code'] = datetime.datetime.fromtimestamp(ts).strftime('MCQ-%d%m%Y-%H:%M:%S')
                time.sleep(1)
            return jsonify({ 'mcq': qustions, 'success': True }) 
               
        except Exception as e:
            exception_message = e.args[0]
            return jsonify({ 'mcq': [], 'success': False, 'message': exception_message })
        
    #Document processing for generating  all type of questions
    @staticmethod
    def processDocument_all_cases(file, mcq_count,mcq_diffls,fill_in_the_blank_count, true_false_count,tf_diffls):
        try:
            if file and ContextToQuestionService.__allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path_to_save = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path_to_save)
                response = ContextToQuestionService.__process_document_cases(filename.rsplit('.', 1)[1].lower(), file_path_to_save,filename)                
                os.remove(file_path_to_save)
                
                getAllTypeQuestions = ContextToQuestionService.getAllTypeQuestionsMix(response,mcq_count,mcq_diffls, fill_in_the_blank_count, true_false_count,tf_diffls)
                return getAllTypeQuestions
                # return jsonify({'success': True, 'message': 'Vectorstore successfully created','summary':response})
           
            else:
                return jsonify({'success': False, 'message': 'File type not supported'})

        except Exception as e:
            logger.exception('An error occurred while checking status of file %s', str(e))
            return jsonify({'success': False, 'message': str(e)})
        
    #Generate the summary first and then MCQ
    @staticmethod
    def get_fill_in_the_blanks(text, question_count):
        try:
            validated_question_count = ContextToQuestionService.__question_count_validation(question_count)
            summary = ContextToQuizDataAccess.summarize_text(text)
            fill_in_the_blanks = ContextToQuizDataAccess.generate_fill_inthe_blanks(validated_question_count,summary )
            fill_in_the_blanks =  fill_in_the_blanks[:validated_question_count]
            for i in range(int(validated_question_count)):
                ts = time.time()
                fill_in_the_blanks[i]['code'] = datetime.datetime.fromtimestamp(ts).strftime('MCQ-%d%m%Y-%H:%M:%S')
                time.sleep(1)

            return jsonify({ 'success': True, 'shortanswer': fill_in_the_blanks })

        except Exception as e:
            exception_message = e.args[0]
            return jsonify({ 'success': False, 'shortanswer': [], 'message': exception_message })

    #Generate the summary first and then True and false
    @staticmethod
    def get_true_false_questions(text, question_count,Tags,summary):
        try:
            validated_question_count = ContextToQuestionService.__question_count_validation(question_count)
            true_false_questions = ContextToQuizDataAccess.generate_true_and_false(validated_question_count,summary,Tags)
            true_false_questions =  true_false_questions[:validated_question_count]
            for i in range(int(validated_question_count)):
                ts = time.time()
                true_false_questions[i]['code'] = datetime.datetime.fromtimestamp(ts).strftime('TrueFalse-%d%m%Y-%H:%M:%S')
                time.sleep(1)

            return jsonify({ 'success': True, 'truefalse': true_false_questions })
        except Exception as e:
            exception_message = e.args[0]
            return jsonify({ 'success': False, 'truefalse': [], 'message': exception_message })
    
    #Generate the summary first and then True and false,fill in the blanks,mcq
    @staticmethod
    def getAllTypeQuestionsMix(text, mcq_count,mcq_difflevel, fill_in_the_blank_count, true_false_count,tf_difflevel):
        # summary = ContextToQuizDataAccess.summarize_text(text)
        mcq_count = int(mcq_count)
        fill_in_the_blank_count = int(fill_in_the_blank_count)
        true_false_count = int(true_false_count)
        print("mcq count is ",mcq_count,flush=True)
        print("fill in the blanks count is ",fill_in_the_blank_count,flush=True)
        print("true false count is ",true_false_count,flush=True)
        summary = ContextToQuizDataAccess.summarize_text(text)

        try:
              
            validated_mcq_count = ContextToQuestionService.__question_count_validation(mcq_count)
            validated_mcq_count=int(validated_mcq_count)
            if (validated_mcq_count!=0) or (sum(mcq_difflevel)!=0):
                if(validated_mcq_count==0):
                    mcqQustions = ContextToQuizDataAccess.generate__level_mcq(validated_mcq_count,summary, mcq_difflevel)
                    mcqQustions_len =  len(mcqQustions)
                    for i in range(mcqQustions_len):
                        ts = time.time()
                        mcqQustions[i]['code'] = datetime.datetime.fromtimestamp(ts).strftime('MCQ-%d%m%Y-%H:%M:%S')
                        time.sleep(1)
                else:
                    mcqQustions = ContextToQuizDataAccess.generate_mcq(validated_mcq_count,summary)
                    mcqQustions_len =  len(mcqQustions)
                    for i in range(mcqQustions_len):
                        ts = time.time()
                        mcqQustions[i]['code'] = datetime.datetime.fromtimestamp(ts).strftime('MCQ-%d%m%Y-%H:%M:%S')
                        time.sleep(1)
            else:
                mcqQustions=0


            if fill_in_the_blank_count==0:
                fill_in_the_blanks = 0
            else:
                validated_fill_in_the_blank_count = ContextToQuestionService.__question_count_validation(fill_in_the_blank_count)
                fill_in_the_blanks = ContextToQuizDataAccess.generate_fill_inthe_blanks(validated_fill_in_the_blank_count,summary )

            
            validated_true_false_count = ContextToQuestionService.__question_count_validation(true_false_count)
            validated_true_false_count=int(validated_true_false_count)
            if (validated_true_false_count!=0) or (sum(tf_difflevel)!=0):
                if(validated_true_false_count==0):
                    true_false_questions = ContextToQuizDataAccess.generate_level_true_and_false(validated_true_false_count,summary,tf_difflevel)
                    true_false_questions_len = len(true_false_questions) 
                    for i in range(true_false_questions_len):
                        ts = time.time()
                        true_false_questions[i]['code'] = datetime.datetime.fromtimestamp(ts).strftime('TrueFalse-%d%m%Y-%H:%M:%S')
                        time.sleep(1)
                else:
                    true_false_questions = ContextToQuizDataAccess.generate_true_and_false(validated_true_false_count,summary)
                    true_false_questions_len=len(true_false_questions)
                    for i in range(true_false_questions_len):
                        ts = time.time()
                        true_false_questions[i]['code'] = datetime.datetime.fromtimestamp(ts).strftime('TrueFalse-%d%m%Y-%H:%M:%S')
                        time.sleep(1)
            else:
                true_false_questions=0
            return jsonify({ 'success': True, 'mcq': mcqQustions, 'shortanswer': fill_in_the_blanks, 'truefalse': true_false_questions })

        except Exception as e:
            # exception_message = e.args[0]
            logger.exception('An error occurred while checking status of file %s', str(e))
            return jsonify({ 'success': False, 'mcq': [], 'shortanswer': [], 'truefalse':[], 'message': e })
        

    #Uploading the document in temp folder
    @staticmethod
    def processDocument(file,question_count,task):
        try:
            if file and ContextToQuestionService.__allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path_to_save = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path_to_save)
                response = ContextToQuestionService.__process_document_cases(filename.rsplit('.', 1)[1].lower(), file_path_to_save,filename)  
                summary = ContextToQuizDataAccess.summarize_text(response)
                Tags = ContextToQuestionService.get_keywords(summary)             
                os.remove(file_path_to_save)
                if task=="mcq":
                    mcq = ContextToQuestionService.get_mcq(response,question_count,Tags,summary)
                    return mcq
                elif task=="Fill_in_the_blanks":
                    Fill_in_the_blanks = ContextToQuestionService.get_fill_in_the_blanks(response,question_count,)
                    return Fill_in_the_blanks
                elif task=="True_and_False":
                    True_and_False = ContextToQuestionService.get_true_false_questions(response,question_count,Tags,summary)
                    return True_and_False
                elif task=="All_Type_Ques":
                    All_Type_Ques = ContextToQuestionService.getAllTypeQuestionsMix(response,question_count,Tags,summary)
                    return All_Type_Ques

                # return jsonify({'success': True, 'message': 'Vectorstore successfully created','summary':response})
           
            else:
                print("False")
                # return jsonify({'success': False, 'message': 'File type not supported'})

        except Exception as e:
            logger.exception('An error occurred while checking status of file %s', str(e))
            print("False")
            # return jsonify({'success': False, 'message': str(e)})