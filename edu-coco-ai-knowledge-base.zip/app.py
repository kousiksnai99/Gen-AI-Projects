from flask import Flask, request, jsonify
from flask_cors import cross_origin, CORS
import os
from business_logic import KnowledgeBaseBusinessLogic
from dotenv import load_dotenv
from langchain.llms import OpenAI
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
import openai
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
import logging
from opencensus.ext.azure.log_exporter import AzureLogHandler
from data_access import KnowledgeBaseDataAcess
from search import Search
from stocks import Stocks
from get_ppt import Presentation
from flask import send_file, jsonify
import io

app = Flask(__name__)
CORS(app)
load_dotenv()

UPLOAD_FOLDER = '/uploads'

app = Flask(__name__)

#-----------------------------Intializing secrets------------------------------
'''credential = ManagedIdentityCredential()
KEYVAULT_NAME = os.environ['KEYVAULT_NAME']
client = SecretClient(f"https://{KEYVAULT_NAME}.vault.azure.net/",credential)

openai_api_token = client.get_secret("openai-api-token")
openai_api_token = openai_api_token.value


api_base = client.get_secret("openai-api-base")
api_base = api_base.value

instrumentation_key = client.get_secret("application-insights-instrumentation-key")
instrumentation_key = instrumentation_key.value

application_token = client.get_secret("ai-application-token")
application_token = application_token.value '''

#-------------------------------------------------------------------------------
container_name = os.environ['STORAGE_CONTAINER_NAME']
account_name = os.environ['STORAGE_ACCOUNT_NAME']
instrumentation_key = os.getenv('Instrumentation_Key')
vector_store_address = os.getenv('cognetive-service-endpoint')
vector_store_password = os.getenv('cognetive-service-password')
api_base = os.getenv('openai-api-base')
openai_api_token = os.getenv('openai-api-token')
account_key = os.getenv('ai-knowledge-base-account-key')
application_token = os.getenv('ai-application-token')

api_type = "azure"

#-------------remove for the testing------------
#----------------remove-----------------------  

logger = logging.getLogger(__name__)
logger.addHandler(AzureLogHandler(
    connection_string=f'InstrumentationKey={instrumentation_key}')
)

#Making the openAIembedding model text-embedding-ada-002
app.embeddingsModel =  OpenAIEmbeddings(deployment="text-embedding-ada-002",model="text-embedding-ada-002", chunk_size=1,openai_api_key=openai_api_token,openai_api_base=api_base,openai_api_type =api_type)

#Intialising the llm of gpt-35-turbo
app.llmHuggingFace =AzureChatOpenAI(deployment_name="gpt-4o", temperature=0,openai_api_version="2024-08-01-preview",openai_api_key=openai_api_token,openai_api_base=api_base,openai_api_type =api_type)

#Making the temp folder
try:
    path = os.path.dirname(os.path.abspath(__file__))
    upload_folder=os.path.join(
    path.replace(UPLOAD_FOLDER,""),"tmp")
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder

except Exception as e:
    print("An error occurred while creating temp folder")
    print("Exception occurred : {}".format(e))

@app.route('/', methods = ['GET'])
@cross_origin()
def welcome_to():
    return 'Welcome to AI Knowledge base module:)'
    
# API for uploading a document
@app.route('/api/coco/kb/process/document', methods=['POST'])
@cross_origin()
def process_document():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if auth_header == application_token:
            # Check if it's a file upload
            if 'file' not in request.files:
                return jsonify({'success': False, 'message': 'No file part'})

            file = request.files['file']
            if file.filename == '':
                return jsonify({'success': False, 'message': 'No selected file'})

            user_role = request.form.get('user_role')  # Accepting multiple roles in a single field
            if not user_role:
                return jsonify({'success': False, 'message': 'User roles are missing'})

            user_roles_list = user_role.split(',')  # Split roles by comma
            print(f"Processing file: {file.filename} for user roles: {user_roles_list}")
            return KnowledgeBaseBusinessLogic.processDocument(file, user_roles_list)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

# API for processing URLs
@app.route('/api/coco/kb/process/url', methods=['POST'])
@cross_origin()
def process_url():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if auth_header == application_token:
            # Check if URL is provided
            if 'url' not in request.form:
                return jsonify({'success': False, 'message': 'URL is missing'})

            url = request.form.get('url')
            if not url:
                return jsonify({'success': False, 'message': 'URL is empty'})

            user_role = request.form.get('user_role')  # Accepting multiple roles in a single field
            if not user_role:
                return jsonify({'success': False, 'message': 'User roles are missing'})

            user_roles_list = user_role.split(',')  # Split roles by comma
            print(f"Processing URL: {url} for user roles: {user_roles_list}")
            return KnowledgeBaseDataAcess.process_URL_knowledge(url, user_roles_list)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

# API for processing YouTube link
@app.route('/api/coco/kb/process/yturl', methods=['POST'])
@cross_origin()
def process_Youtube_Link():
    try:
        # Extract form-data
        ytLink = request.form.get('ytLink')  
        user_role = request.form.get('user_role')  

        if not ytLink or not user_role:
            return jsonify({
                "success": False,
                "message": "YouTube link and user role are required."
            }), 
        # Split user_role into a list if multiple roles are passed as comma-separated values
        user_roles_list = user_role.split(',') 
        user_roles_list = [role.strip() for role in user_roles_list]  
        print(f"Processing YouTube link: {ytLink} for user roles: {user_roles_list}")
        # Call the KnowledgeBaseDataAcess method with the YouTube link and user roles list
        return KnowledgeBaseDataAcess.process_youtube_link(ytLink, user_roles_list)
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"An error occurred: {str(e)}"
        }), 

#Api for asking question
@app.route('/api/coco/kb/ask-question', methods=['POST'])
@cross_origin()
def ask_question():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if auth_header == application_token:
            data = request.get_json()
            session_id = data['session_id']
            question = data['question']
            
            # Accept two user roles from the request
            user_role = data.get('user_role', [])  # Expect a list of user roles
            
            if len(user_role) == 0:
                return jsonify({'success': False, 'message': 'user_role not provided'}), 
            
            # Pass both user roles to the business logic
            return KnowledgeBaseBusinessLogic.answerAskedQuestion(question, session_id, user_role)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'}), 
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"}), 

#api for getting list of files
@app.route('/api/coco/kb/get-list-files', methods = ['GET'])
@cross_origin()
def getdatalakefile():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            try:
                return KnowledgeBaseBusinessLogic.getfiles()
            except Exception as e:
                logger.exception('An error occurred while getting file: %s', str(e))
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

#api for deleting the file
@app.route('/api/coco/kb/delete-files', methods = ['POST'])
@cross_origin()
def deletedatalakefile():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            data = request.get_json()   
            filename = data['filename']
            filepath = data['filepath']
            file_datetime=data['file_datetime']
            return KnowledgeBaseBusinessLogic.delete_present_file(filename,filepath,file_datetime)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

#api for editing the file
@app.route('/api/coco/kb/edit-files', methods = ['POST'])
@cross_origin()
def editdatalakefile():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            if 'file' not in request.files:
                return jsonify({'success': False, 'message': 'No file part'})
            file = request.files['file']
            if file.filename == '':
                return jsonify({'success': False, 'message': 'No selected file'})
            print("file name is ",file)
            presentFilename = request.form['presentFilename']
            filepath = request.form['filepath']
            file_datetime=request.form['file_datetime']
            return KnowledgeBaseBusinessLogic.editfile(presentFilename,file,filepath,file_datetime)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

@app.route('/api/coco/kb/process/search', methods = ['POST'])
@cross_origin()
def process_search():
    req_body = request.get_json()
    q = req_body.get("q")
    top = req_body.get("top") or 8
    skip = req_body.get("skip") or 0
    filters = req_body.get("filters") or []
    return Search.main(q,top,skip,filters)

@app.route('/api/coco/kb/process/stocks', methods = ['GET'])
@cross_origin()
def process_stocks():
    return Stocks.process_stock()

@app.route('/api/coco/kb/process/product_details', methods = ['POST'])
@cross_origin()
def process_product():
    req_body = request.get_json()
    id = req_body.get("id")
    return Stocks.get_product(id)

@app.route('/api/coco/kb/process/supplier_details', methods = ['POST'])
@cross_origin()
def process_supplier():
    req_body = request.get_json()
    product_name = req_body.get("product_name")
    top = req_body.get("top") or 8
    skip = req_body.get("skip") or 0
    filters = req_body.get("filters") or []
    price=req_body.get("price")
    supplier_name=req_body.get("supplier_name")
    return Search.product_main(product_name,top,skip,filters,price,supplier_name)

@app.route('/api/coco/kb/process/compare_supliers', methods = ['POST'])
@cross_origin()
def compare_supplier():
    req_body = request.get_json()
    catalog_number = req_body.get("catalog_number")
    top = req_body.get("top") or 8
    skip = req_body.get("skip") or 0
    filters = req_body.get("filters") or []
    return Search.allsupplier(catalog_number,top,skip,filters)

@app.route('/api/process/ppt', methods=['POST'])
@cross_origin()
def process_ppt():
    data = request.get_json()   
    topic = data['topic']

    # Generate the PowerPoint presentation
    ppt_filename = Presentation.main(topic)
    
    # Read the file into a BytesIO object
    ppt_file = io.BytesIO()
    with open(ppt_filename, 'rb') as f:
        ppt_file.write(f.read())
    ppt_file.seek(0)

    # Return the file as an attachment
    return send_file(
        ppt_file,
        as_attachment=True,
        download_name=f"{topic}_presentation.pptx",
        mimetype='application/vnd.openxmlformats-officedocument.presentationml.presentation'
    )

# driver function
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=5002)