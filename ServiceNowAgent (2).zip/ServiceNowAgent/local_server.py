# Project name      : Agentic AI SD
# Business Owner    : ITOA
# Tech Owner        : Kousik Snai -ITOA Project AI Team
# Notebook Author   : Kousik Snai -ITOA Project AI Team
# Date              : 2026-09-10
# Purpose:
#   ONE local endpoint to test the 5 actions in main.py against the real ServiceNow API.
#   Local only, never deployed. main.py is not modified.
#
#   No new packages: only requests / python-dotenv / truststore, which main.py needs
#   anyway. No FastAPI, no uvicorn -- the standard library serves it.
#
#   RUN
#       python local_server.py
#
#   THEN, from Postman or curl:
#       POST http://127.0.0.1:8000/test
#       {"action": "create_incident", "issue_type": "outlook_it", "details": "..."}
#
#   GET http://127.0.0.1:8000/ prints the 5 payloads.

# # Load all the libraries
import importlib.util
import json
import sys
import types
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
PORT = 8000

# Corporate TLS interception breaks certifi; without this every ServiceNow call fails
# with CERTIFICATE_VERIFY_FAILED and looks like an auth problem.
try:
    import truststore

    truststore.inject_into_ssl()
except ImportError:
    print("NOTE: truststore not installed -- pip install truststore")


#=============================Loading main.py======================================================
# main.py imports `app.core.config` and `app.agents.base`, which live in the orchestrator
# repo. Instead of copying that folder tree here, both are registered directly:
# config.py IS the real one, and Agent is a 4-line stand-in holding exactly what deps.py
# passes every agent (settings / foundry / timeout / trace).
def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


for package in ("app", "app.agents", "app.core"):
    stub = types.ModuleType(package)
    stub.__path__ = []
    sys.modules[package] = stub

config = _load("app.core.config", HERE / "config.py")

base = types.ModuleType("app.agents.base")


class Agent:
    def __init__(self, settings=None, foundry=None, timeout=None, trace=None, **extra):
        self.settings = settings
        self.foundry = foundry
        self.timeout = timeout
        self.trace = trace


base.Agent = Agent
sys.modules["app.agents.base"] = base

sn = _load("app.agents.servicenow.main", HERE / "main.py")

# foundry=None, so the Foundry wording step is skipped and the deterministic text is
# used. This is a ServiceNow test, which is the point.
AGENT = sn.ServiceNowAgent(settings=config.settings, foundry=None, timeout=120, trace=None)


#=============================The 5 actions========================================================
# One entry per condition: the argument names main.py's method takes, in order, each
# mapped to the JSON key the request sends. Adding nothing else keeps this honest -- the
# call below is exactly the call app/domain/flow.py makes in production.
ACTIONS = {
    "create_interaction": ("conversation_id", "user_id"),
    "close_interaction": ("conversation_id", "interaction_id"),
    "create_incident": ("conversation_id", "interaction_id", "issue_type", "details"),
    "update_incident": ("conversation_id", "incident_id", "note"),
    "resolve": ("conversation_id", "interaction_id", "incident_id"),
}

USAGE = """ServiceNow agent -- local test server

POST http://127.0.0.1:%d/test      Content-Type: application/json

The 5 conditions, with the payload each one takes:

1. create_interaction
   {"action": "create_interaction",
    "conversation_id": "local-test-001",
    "user_id": "kousik.snai@cognizant.com"}
   -> "" when SN_INTERACTION_PATH is unset, because the gateway has no interaction
      table. That is the documented degrade, not a failure.

2. close_interaction
   {"action": "close_interaction",
    "conversation_id": "local-test-001",
    "interaction_id": "IMS0001234"}
   -> null. Returns nothing by design.

3. create_incident            <- creates a REAL ticket
   {"action": "create_incident",
    "conversation_id": "local-test-001",
    "interaction_id": "",
    "issue_type": "outlook_it",
    "details": "Outlook will not start after the latest Windows update."}
   -> {"incident_id": "INC00xxxxx", "message": "...", ...}
      Copy the incident_id into the next two calls.

4. update_incident
   {"action": "update_incident",
    "conversation_id": "local-test-001",
    "incident_id": "INC00xxxxx",
    "note": "Diagnostics started."}
   -> null. Returns nothing by design.

5. resolve
   {"action": "resolve",
    "conversation_id": "local-test-001",
    "interaction_id": "",
    "incident_id": "INC00xxxxx"}
   -> the line shown to the user. Leave incident_id out and it finds the ticket by
      conversation_id instead, which is the one-incident-per-conversation lookup.

Every field is optional except action; anything missing is sent as "".
""" % PORT


#=============================The endpoint=========================================================
class Handler(BaseHTTPRequestHandler):
    """POST /test -> call one method on the agent. GET / -> the usage above."""

    def do_GET(self):
        self._send(200, USAGE, "text/plain")

    def do_POST(self):
        if self.path.rstrip("/") not in ("/test", ""):
            return self._json(404, {"ok": False, "error": f"POST /test, not {self.path}"})

        length = int(self.headers.get("Content-Length") or 0)
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
        except ValueError as exc:
            return self._json(400, {"ok": False, "error": f"body is not JSON: {exc}"})

        action = str(payload.get("action") or "")
        if action not in ACTIONS:
            return self._json(
                400,
                {"ok": False, "error": f"unknown action {action!r}", "actions": list(ACTIONS)},
            )

        # Read the arguments this action needs, in the order its method declares them.
        args = [str(payload.get(name) or "") for name in ACTIONS[action]]
        print(f"\n--> {action}({', '.join(repr(a) for a in args)})")

        try:
            result = getattr(AGENT, action)(*args)
        except Exception as exc:
            # create_incident and resolve raise by design; the other three swallow their
            # own failures. Returned rather than re-raised so the real ServiceNow message
            # is visible instead of a stack trace.
            print(f"<-- FAILED {type(exc).__name__}: {exc}")
            return self._json(
                500, {"ok": False, "action": action, "error": f"{type(exc).__name__}: {exc}"}
            )

        print(f"<-- {result!r}")
        return self._json(200, {"ok": True, "action": action, "result": result})

    # -- plumbing ----------------------------------------------------------
    def _json(self, status: int, body: dict):
        self._send(status, json.dumps(body, ensure_ascii=False, indent=2), "application/json")

    def _send(self, status: int, text: str, content_type: str):
        raw = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, fmt, *args):
        pass  # the per-call lines printed above are more useful than access logs


if __name__ == "__main__":
    print(USAGE)
    print(f"listening on http://127.0.0.1:{PORT}   (Ctrl+C to stop)")
    HTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
