#####################################################################################
## Project name : Multilingual Service Desk Agent (Agentic AI POC)                  #
## Business owner , Team : Data and AIA                                             #
## Code Author , Team : POC Team                                                    #
## Date: 15th Jul 2026                                                              #
## Purpose of Function:                                                             #
##  HTTP-triggered Azure Function that:                                             #
##      1. Receives a user message from a caller [Service Desk/App].               #
##      2. Detects the language offline [deterministic, no LLM] and blocks any      #
##         language that is not in the supported list.                             #
##      3. For a supported language, forwards the message to the Azure AI Foundry   #
##         'multilingual-agent' and returns its reply in the same language.        #
## Code                                                                             #
#####################################################################################

# # Load all the libraries
import json
import logging
import re
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Optional

import azure.functions as func

# Auth / SDKs
from azure.identity import DefaultAzureCredential

# Azure AI Projects [Foundry agents]
from azure.ai.projects import AIProjectClient
from azure.ai.agents.models import ListSortOrder


#=============================Logging Setup========================================================
# Azure Function configures the root logger but we are ensuring the level.
logging.getLogger().setLevel(logging.INFO)


#=============================Data Class Module====================================================
@dataclass
class FoundryConfig:
    """Configuration required for Azure AI Foundry interactions."""
    endpoint: str
    agent_name: str


@dataclass
class AppConfig:
    """Configuration object for the function."""
    environment: str
    foundry: FoundryConfig


#=========================================Helpers: Loading Configuration===========================
def load_config() -> AppConfig:
    """
    Build AppConfig from hardcoded values.

    Kept inline [no Akeyless / App settings] so the function deploys and runs
    without any post-deployment configuration.
    """
    logging.info("Loading configuration.")
    foundry_cfg = FoundryConfig(
        endpoint="https://aifoundry-rjteh-ais-swce-poc.services.ai.azure.com/api/projects/aifp-uqqnf-ais-swce-poc",
        agent_name="multilingual-agent",
    )
    return AppConfig(environment="dev", foundry=foundry_cfg)


#==============================================Utilities===========================================
def json_response(payload: Dict[str, Any], status: int = 200) -> func.HttpResponse:
    """
    Returns a JSON-formatted HTTP response with consistent headers.

    ensure_ascii=False keeps non-Latin scripts [Hebrew, Japanese, ...] readable
    in the response body.
    """
    return func.HttpResponse(
        body=json.dumps(payload, ensure_ascii=False),
        status_code=status,
        mimetype="application/json",
    )


def get_default_credential() -> DefaultAzureCredential:
    """Create a Default Azure Credential instance suitable for function apps."""
    return DefaultAzureCredential(
        exclude_interactive_browser_credential=True,
        exclude_visual_studio_code_credential=True,
        exclude_shared_token_cache_credential=True,
        exclude_powershell_credential=True,
    )


def extract_message(req: func.HttpRequest) -> Optional[str]:
    """Read the user message from the query string or the JSON body."""
    message = req.params.get("message") or req.params.get("q") or req.params.get("query")
    if message:
        return message

    try:
        body = req.get_json()
    except ValueError:
        body = None

    if isinstance(body, dict):
        return (
            body.get("message")
            or body.get("query")
            or body.get("text")
            or body.get("prompt")
        )
    return None


#==============================================Language Detection==================================
# ISO 639-1 code -> display name, for the SUPPORTED languages only.
SUPPORTED: Dict[str, str] = {
    "en": "English",
    "he": "Hebrew",
    "hr": "Croatian",
    "bg": "Bulgarian",
    "ro": "Romanian",
    "fr": "French",
    "de": "German",
    "cs": "Czech",
    "ru": "Russian",
    "it": "Italian",
    "nl": "Dutch",
    "hu": "Hungarian",
    "pl": "Polish",
    "es": "Spanish",
    "sl": "Slovenian",
    "sk": "Slovak",
    "el": "Greek",
    "pt": "Portuguese",
    "sr": "Serbian",
    "bs": "Bosnian",
    "mk": "Macedonian",
    "kk": "Kazakh",
    "uk": "Ukrainian",
    "ko": "Korean",
    "ja": "Japanese",
    "ms": "Malay",
    "id": "Indonesian",
    "th": "Thai",
    "vi": "Vietnamese",
    "tr": "Turkish",
    # Written text cannot separate Mandarin vs Cantonese, so both map here.
    "zh": "Chinese (Mandarin)",
}

# Languages we deliberately DETECT so they get correctly REJECTED instead of
# being misread as a supported language [all UNSUPPORTED].
DECOYS = ["hi", "ur", "ar", "bn", "ta", "te", "fa", "mr", "pa", "gu", "kn", "ml"]

NOT_SUPPORTED_MESSAGE = (
    "I'm sorry, this language is not currently supported. Please switch to one of "
    "the supported languages to continue. supported languages are: English, Hebrew, "
    "Croatian, Bulgarian, Romanian, French, German, Czech, Russian, Italian, Dutch, "
    "Hungarian, Polish, Spanish, Slovenian, Slovak, Greek, Portuguese, Serbian, "
    "Bosnian, Macedonian, Kazakh, Ukrainian, Korean, Japanese, Malay, Indonesian, "
    "Thai, Vietnamese, Turkish, Chinese (Mandarin), Chinese (Cantonese)"
)

# Below this confidence, and not clearly English, default to English
# [per the rule "if uncertain, respond in English"].
_MIN_CONFIDENCE = 0.55

# Scripts NO supported language uses -> instant, guaranteed reject.
_DEVANAGARI = re.compile("[ऀ-ॿ]")            # Hindi, Marathi, Nepali...
_ARABIC = re.compile("[؀-ۿݐ-ݿ]")   # Arabic, Urdu, Persian...


class LanguageDetector:
    """
    Offline, deterministic language detector [py3langid]. No LLM is used, so it
    cannot hallucinate or reply in the wrong language: the same input always
    returns the same output.
    """

    def __init__(self):
        self._identifier = None

    def _get_identifier(self):
        """Lazy-load and cache the detector, restricted to supported + decoys."""
        if self._identifier is None:
            from py3langid.langid import LanguageIdentifier, MODEL_FILE

            identifier = LanguageIdentifier.from_pickled_model(MODEL_FILE, norm_probs=True)
            identifier.set_languages(list(SUPPORTED.keys()) + DECOYS)
            self._identifier = identifier
        return self._identifier

    def detect(self, text: str) -> Dict[str, Any]:
        """
        Detect the language of `text` and say whether it is supported.

        Returns a dict:
            input      - the original text
            language   - display name if supported, else None
            code       - ISO 639-1 code of the best guess
            supported  - True/False
            confidence - 0.0 .. 1.0
            message    - None if supported, else the exact "not supported" text
        """
        text = (text or "").strip()
        if not text:
            return self._supported("en", 1.0, text)  # nothing to detect -> English

        # Hard deterministic rejects [scripts no supported language uses].
        if _DEVANAGARI.search(text):
            return self._rejected("hi", 1.0, text)
        if _ARABIC.search(text):
            return self._rejected("ar", 1.0, text)

        code, confidence = self._get_identifier().classify(text)

        # Low confidence and not clearly English -> default to English.
        if confidence < _MIN_CONFIDENCE and code != "en":
            return self._supported("en", confidence, text)

        if code in SUPPORTED:
            return self._supported(code, confidence, text)
        return self._rejected(code, confidence, text)

    @staticmethod
    def _supported(code: str, confidence: float, text: str) -> Dict[str, Any]:
        return {
            "input": text,
            "language": SUPPORTED[code],
            "code": code,
            "supported": True,
            "confidence": round(float(confidence), 4),
            "message": None,
        }

    @staticmethod
    def _rejected(code: str, confidence: float, text: str) -> Dict[str, Any]:
        return {
            "input": text,
            "language": None,
            "code": code,
            "supported": False,
            "confidence": round(float(confidence), 4),
            "message": NOT_SUPPORTED_MESSAGE,
        }


# Cache the detector across warm invocations [loading the model is expensive].
_DETECTOR = LanguageDetector()


#=============================================Azure AI Foundry=====================================
class FoundryAgentService:
    """
    Service wrapper for interacting with the Azure AI Foundry multilingual agent.
    The agent is resolved by NAME [no agent id required].
    """

    def __init__(self, config: FoundryConfig, credential: DefaultAzureCredential):
        self.config = config
        self.project = AIProjectClient(endpoint=config.endpoint, credential=credential)
        self.agent = self._resolve_agent(config.agent_name)

    def _resolve_agent(self, agent_name: str):
        """Look up the agent by name; if duplicates exist, the newest one wins."""
        matches = [
            agent for agent in self.project.agents.list_agents()
            if getattr(agent, "name", None) == agent_name
        ]
        if not matches:
            raise RuntimeError(f"Agent '{agent_name}' not found in the project.")

        matches.sort(key=lambda a: str(getattr(a, "created_at", "") or ""))
        agent = matches[-1]
        logging.info("Resolved Foundry agent '%s' -> %s.", agent_name, agent.id)
        return agent

    def resolve_message_user_format(
        self, issue_text: str, language: Optional[str] = None
    ) -> Optional[str]:
        """
        Send the user message to the agent and return its reply.

        `language` steers the agent to answer in the detected language so it does
        not guess and drift into the wrong language.

        Returns:
            The agent's reply text or None if the run failed.
        """
        logging.info("Sending message to Foundry multilingual agent.")
        thread = self.project.agents.threads.create()

        self.project.agents.messages.create(
            thread_id=thread.id,
            role="user",
            content=issue_text,
        )

        run_kwargs: Dict[str, Any] = {"thread_id": thread.id, "agent_id": self.agent.id}
        if language:
            run_kwargs["additional_instructions"] = (
                f"The user's message is in {language}. Respond ONLY in {language}."
            )

        run = self.project.agents.runs.create_and_process(**run_kwargs)

        if run.status == "failed":
            logging.error("Foundry run failed. Error: %s", getattr(run, "last_error", None))
            return None

        messages = self.project.agents.messages.list(
            thread_id=thread.id,
            order=ListSortOrder.ASCENDING,
        )

        reply: Optional[str] = None
        for message in messages:
            if not message.text_messages:
                continue
            reply = message.text_messages[-1].text.value

        if reply:
            logging.info("Foundry multilingual agent returned a reply.")
        else:
            logging.warning("Foundry multilingual agent did not return any text.")
        return reply


#==============================================Azure Function Entry================================
def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP-triggered Azure Function entry point.
    Responsibilities:
    - Validate and parse the request.
    - Detect the language offline and block unsupported languages.
    - For a supported language, call the Foundry multilingual agent.
    - Return a structured JSON response with detailed status.
    """
    correlation_id = req.headers.get("x-correlation-id", str(uuid.uuid4()))
    logging.info(
        "Request received for Multilingual Agent function. CORRELATION_ID = %s",
        correlation_id,
    )

    try:
        # 1. Read the user message
        user_message = extract_message(req)
        if not user_message or not str(user_message).strip():
            return json_response(
                {
                    "Success": False,
                    "error": {
                        "message": "Input Error.",
                        "details": "message is required [query string or JSON body].",
                    },
                },
                status=400,
            )

        # 2. Deterministic language gate [offline, no LLM] - runs BEFORE the agent
        detection = _DETECTOR.detect(str(user_message))
        if not detection["supported"]:
            return json_response(
                {
                    "Success": True,
                    "supported": False,
                    "language": None,
                    "detected_code": detection["code"],
                    "correlation_id": correlation_id,
                    "reply": detection["message"],
                }
            )

        # 3. Load configuration and credential
        config = load_config()
        credential = get_default_credential()

        # 4. Call the Foundry agent, steering it to the detected language
        foundry_service = FoundryAgentService(config.foundry, credential)
        reply = foundry_service.resolve_message_user_format(
            str(user_message), detection["language"]
        )

        return json_response(
            {
                "Success": True,
                "supported": True,
                "language": detection["language"],
                "environment": config.environment,
                "correlation_id": correlation_id,
                "reply": reply,
            }
        )

    except Exception as unhandled_exception:
        # Final safeguard: log and return generic error
        logging.exception("Unhandled exception in Multilingual Agent function.")
        return json_response(
            {
                "Success": False,
                "error": {
                    "message": "Unhandled server error. Please contact the automation team.",
                    "details": str(unhandled_exception),
                },
            },
            status=500,
        )
