import json
import os

# Cache to store loaded JSON files
_cached_data = {}

def load_json_file(file_name):
    """Loads and caches a JSON file from the same directory as the script."""
    global _cached_data

    if file_name in _cached_data:
        return _cached_data[file_name]  # Return cached version if available

    json_file_path = os.path.join(os.path.dirname(__file__), file_name)

    if not os.path.exists(json_file_path):
        raise FileNotFoundError(f"Configuration file not found: {json_file_path}")

    try:
        with open(json_file_path, "r", encoding="utf-8") as file:
            _cached_data[file_name] = json.load(file)  # Cache the loaded data
            return _cached_data[file_name]
    except json.JSONDecodeError as e:
        raise ValueError(f"Error parsing JSON file {file_name}: {e}")

def get_static_values():
    """Loads static values with dynamic enum configuration, using cached JSON files."""
    functions = load_json_file("functions.json")
    apis = load_json_file("api.json")

    return {
        "functions": functions.get("functions", []),
        "initial_messages": functions.get("initial_messages", []),
        "apis": apis.get("apis", {}),
        "dynamic_enums": apis.get("apis", {}).get("dynamic_enums", {})
    }