import logging
import tiktoken
from typing import List, Dict, Any
from azure.storage.blob import BlobServiceClient
from langchain.text_splitter import RecursiveCharacterTextSplitter
from app.config.settings import AZURE_STORAGE_CONFIG
from app.repositories.vector_store import get_vector_store

class AzureSearchRepository:
    @staticmethod
    def upload_vector_ids_to_azure(filename: str, vector_ids: List[str]):
        try:
            blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONFIG["connection_string"])
            container_client = blob_service_client.get_container_client(AZURE_STORAGE_CONFIG["container_name"])
            blob_name = f"vector_ids/{filename}_vector_id.txt"
            vector_id_content = "\n".join(vector_ids)
            container_client.upload_blob(name=blob_name, data=vector_id_content, overwrite=True)
            logging.info(f"Uploaded vector IDs for {filename} to Azure Blob Storage")
        except Exception as e:
            logging.error(f"Error uploading vector IDs for {filename} to Azure: {e}")
            raise Exception(f"Failed to upload vector IDs to Azure: {e}") from e

    @staticmethod
    def get_vectorstore():
        return get_vector_store("azure")

    @staticmethod
    def save_to_vectorstore(filename: str, text: str) -> Dict[str, Any]:
        try:
            encoding = tiktoken.get_encoding("cl100k_base")
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=500,
                chunk_overlap=100,
                length_function=lambda x: len(encoding.encode(x)),
                add_start_index=True
            )
            text_chunks = text_splitter.split_text(text)
            metadata = [{"source": filename, "start_index": i * 500} for i in range(len(text_chunks))]

            vector_store = AzureSearchRepository.get_vectorstore()
            vector_ids = vector_store.add_texts(texts=text_chunks, metadatas=metadata)

            AzureSearchRepository.upload_vector_ids_to_azure(filename, vector_ids)

            summary = f"Text extracted and indexed from {filename}"
            return {
                "success": True,
                "message": "Vectorstore successfully created",
                "summary": summary
            }
        except Exception as e:
            logging.error(f"Error saving to vectorstore for {filename}: {e}")
            return {
                "success": False,
                "message": f"Failed to save to vectorstore: {str(e)}",
                "summary": ""
            }