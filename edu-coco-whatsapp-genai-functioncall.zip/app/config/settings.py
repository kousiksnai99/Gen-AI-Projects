import json
import os
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    "server": os.getenv("DB_SERVER"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME"),
}


OPENAI_CONFIG = {
    "OPENAI_API_KEY": os.getenv("OPENAI_API_KEY"),
    "OPENAI_API_BASE": os.getenv("OPENAI_API_BASE"),
}

AZURE_STORAGE_CONFIG = {
    "account_name": os.getenv("AZURE_STORAGE_ACCOUNT_NAME"),
    "account_key": os.getenv("AZURE_STORAGE_ACCOUNT_KEY"),
    "container_name": os.getenv("AZURE_STORAGE_CONTAINER_NAME"),
}

AZURE_SEARCH_CONFIG = {
    "endpoint": os.getenv("AZURE_SEARCH_ENDPOINT"),
    "key": os.getenv("AZURE_SEARCH_KEY"),
    "index_name": os.getenv("AZURE_SEARCH_INDEX_NAME", "test-indexes"),
}

PGVECTOR_CONFIG = {
    "host": os.getenv("PG_HOST"),
    "port": os.getenv("PG_PORT"),
    "database": os.getenv("PG_DATABASE"),
    "user": os.getenv("PG_USER"),
    "password": os.getenv("PG_PASSWORD"),
}

VECTOR_STORE_TYPE = os.getenv("VECTOR_STORE_TYPE", "pgvector")  # Default to pgvector


File_directory = "Uploaded-files/"
Id_directory = "File_ids/"
ALLOWED_EXTENSIONS = {'pdf', 'docx'}

# Cache for JSON files
_cached_data = {}

def load_json_file(file_name):
    if file_name in _cached_data:
        return _cached_data[file_name]

    json_file_path = os.path.join(os.path.dirname(__file__), file_name)

    if not os.path.exists(json_file_path):
        raise FileNotFoundError(f"Configuration file not found: {json_file_path}")

    try:
        with open(json_file_path, "r", encoding="utf-8") as file:
            _cached_data[file_name] = json.load(file)
            return _cached_data[file_name]
    except json.JSONDecodeError as e:
        raise ValueError(f"Error parsing JSON file {file_name}: {e}")

def get_static_values():
    functions = load_json_file("functions.json")
    apis = load_json_file("api.json")

    return {
        "functions": functions.get("functions", []),
        "initial_messages": functions.get("initial_messages", []),
        "apis": apis.get("apis", {}),
        "dynamic_enums": apis.get("apis", {}).get("dynamic_enums", {})
    }

def configure_logging():
    from app.utils.logging_utils import configure_logging as setup_logging
    setup_logging()