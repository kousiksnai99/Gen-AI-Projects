from abc import ABC, abstractmethod
from typing import List, Dict, Any
from langchain_community.vectorstores.pgvector import PGVector
from langchain.embeddings import OpenAIEmbeddings
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from app.config.settings import OPENAI_CONFIG, PGVECTOR_CONFIG, AZURE_SEARCH_CONFIG
from urllib.parse import quote

class VectorStore(ABC):
    @abstractmethod
    def add_texts(self, texts: List[str], metadatas: List[Dict[str, Any]]) -> List[str]:
        pass

    @abstractmethod
    def search(self, query: str, k: int = 5) -> List[str]:
        pass

class PGVectorStore(VectorStore):
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(
            deployment="text-embedding-ada-002",
            model="text-embedding-ada-002",
            chunk_size=1,
            openai_api_key=OPENAI_CONFIG["OPENAI_API_KEY"],
            openai_api_base=OPENAI_CONFIG["OPENAI_API_BASE"],
            openai_api_type="azure"
        )
        self.connection_string = (
            f"postgresql://{quote(PGVECTOR_CONFIG['user'])}:{quote(PGVECTOR_CONFIG['password'])}@"
            f"{PGVECTOR_CONFIG['host']}:{PGVECTOR_CONFIG['port']}/{PGVECTOR_CONFIG['database']}?sslmode=require"
        )
        self.vector_store = PGVector(
            connection_string=self.connection_string,
            embedding_function=self.embeddings,
            collection_name="knowledge_base_vectors"
        )

    def add_texts(self, texts: List[str], metadatas: List[Dict[str, Any]]) -> List[str]:
        return self.vector_store.add_texts(texts=texts, metadatas=metadatas)

    def search(self, query: str, k: int = 5) -> List[str]:
        search_results = self.vector_store.similarity_search(query=query, k=k)
        return [doc.page_content for doc in search_results]

class AzureSearchVectorStore(VectorStore):
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(
            deployment="text-embedding-ada-002",
            model="text-embedding-ada-002",
            chunk_size=1,
            openai_api_key=OPENAI_CONFIG["OPENAI_API_KEY"],
            openai_api_base=OPENAI_CONFIG["OPENAI_API_BASE"],
            openai_api_type="azure"
        )
        self.search_client = SearchClient(
            endpoint=AZURE_SEARCH_CONFIG["endpoint"],
            index_name=AZURE_SEARCH_CONFIG["index_name"],
            credential=AzureKeyCredential(AZURE_SEARCH_CONFIG["key"])
        )

    def add_texts(self, texts: List[str], metadatas: List[Dict[str, Any]]) -> List[str]:
        documents = []
        vector_ids = []
        for i, (text, metadata) in enumerate(zip(texts, metadatas)):
            embedding = self.embeddings.embed_query(text)
            doc_id = f"doc_{i}_{metadata.get('source', 'unknown')}"
            document = {
                "id": doc_id,
                "content": text,
                "embedding": embedding,
                "metadata": metadata
            }
            documents.append(document)
            vector_ids.append(doc_id)
        self.search_client.upload_documents(documents=documents)
        return vector_ids

    def search(self, query: str, k: int = 5) -> List[str]:
        query_embedding = self.embeddings.embed_query(query)
        search_results = self.search_client.search(
            search_text=None,
            vector=query_embedding,
            top_k=k,
            vector_fields="embedding"
        )
        return [result["content"] for result in search_results]

def get_vector_store(vector_store_type: str = "pgvector") -> VectorStore:
    if vector_store_type.lower() == "azure":
        return AzureSearchVectorStore()
    elif vector_store_type.lower() == "pgvector":
        return PGVectorStore()
    else:
        raise ValueError(f"Unsupported vector store type: {vector_store_type}")