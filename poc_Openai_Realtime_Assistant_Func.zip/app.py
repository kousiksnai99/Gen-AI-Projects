import os
import asyncio
from openai import AsyncAzureOpenAI

import chainlit as cl
from uuid import uuid4
from chainlit.logger import logger

from realtime import RealtimeClient
from realtime.tools import tools  # Import tools from tools.py

# Initialize the OpenAI client
client = AsyncAzureOpenAI(
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT"],
    api_version="2024-10-01-preview"
)


def is_supported_language(text: str) -> bool:
    """
    Check if the given text is in a supported language (English or Hindi).
    """
    # Check for Hindi script characters: Unicode range \u0900-\u097F
    hindi_script = any('\u0900' <= char <= '\u097F' for char in text)
    # Check for English script characters
    english_script = any(char.isascii() and char.isalpha() for char in text)
    return hindi_script or english_script


async def setup_openai_realtime(system_prompt: str):
    """Instantiate and configure the OpenAI Realtime Client"""
    openai_realtime = RealtimeClient(system_prompt=system_prompt)
    cl.user_session.set("track_id", str(uuid4()))

    async def handle_conversation_updated(event):
        """Handle updates in the conversation and stream audio back to the client."""
        delta = event.get("delta")
        if delta:
            if 'audio' in delta:
                audio = delta['audio']  # Int16Array, audio added
                await cl.context.emitter.send_audio_chunk(
                    cl.OutputAudioChunk(mimeType="pcm16", data=audio, track=cl.user_session.get("track_id"))
                )
            if 'arguments' in delta:
                arguments = delta['arguments']

    async def handle_item_completed(item):
        """Generate the transcript once an item is completed and populate the chat context."""
        try:
            transcript = item['item']['formatted']['transcript']
            if transcript:
                if is_supported_language(transcript):
                    await cl.Message(content=transcript).send()
                else:
                    await cl.ErrorMessage(content="Only English and Hindi languages are supported.").send()
        except Exception as e:
            logger.error(f"Error in handle_item_completed: {e}")

    async def handle_conversation_interrupt(event):
        """Cancel the previous audio playback."""
        cl.user_session.set("track_id", str(uuid4()))
        await cl.context.emitter.send_audio_interrupt()

    async def handle_input_audio_transcription_completed(event):
        """Send transcribed user audio as a message."""
        delta = event.get("delta")
        if 'transcript' in delta:
            transcript = delta['transcript']
            if is_supported_language(transcript):
                await cl.Message(author="You", type="user_message", content=transcript).send()
            else:
                await cl.ErrorMessage(content="Only English and Hindi languages are supported.").send()

    async def handle_error(event):
        logger.error(event)

    # Set event handlers for the Realtime Client
    openai_realtime.on('conversation.updated', handle_conversation_updated)
    openai_realtime.on('conversation.item.completed', handle_item_completed)
    openai_realtime.on('conversation.interrupted', handle_conversation_interrupt)
    openai_realtime.on('conversation.item.input_audio_transcription.completed', handle_input_audio_transcription_completed)
    openai_realtime.on('error', handle_error)

    cl.user_session.set("openai_realtime", openai_realtime)

    # Register all tool handlers from tools.py
    coros = [openai_realtime.add_tool(tool_def, tool_handler) for tool_def, tool_handler in tools]
    await asyncio.gather(*coros)


# System prompt for the OpenAI client
system_prompt = """Provide helpful and empathetic support responses to student and customer inquiries for Nagarro University, addressing their requests, concerns, or feedback professionally.
Maintain a friendly and service-oriented tone throughout the interaction to ensure a positive experience for each individual.
Respond only in English or Hindi, depending on the language of the user's query. Do not respond in any other language.

# Steps
1. **Identify the Issue:** Carefully read the student's or customer's inquiry to understand the question or issue they are presenting.
2. **Gather Relevant Information:** Check for any necessary additional details, such as order numbers or account identifiers, while ensuring the privacy and security of personal information.
3. **Formulate a Response:** Develop a solution or informative response based on the issue's context. The response should be clear, concise, and address all parts of the inquiry.
4. **Offer Further Assistance:** Invite the individual to reach out again if they need more help or have additional questions.
5. **Close Politely:** End the conversation with a polite closing statement that reinforces Nagarro University's commitment to student and customer satisfaction.

# Output Format
Provide a clear and concise paragraph addressing the inquiry in English or Hindi, including:
- Acknowledgment of the concern
- Suggested solution or response
- Offer for further assistance
- Polite closing
# Notes
- Greet the user with "Welcome to Nagarro University" for the first interaction only.
- Ensure all personal data is handled according to relevant privacy and data protection laws and Nagarro University's privacy policy.
- For high sensitivity or complex cases, escalate the issue to a human support agent.
- Keep responses concise to ensure they are easy to read and understand.
# Example Use Cases
- Ordering books, checking order status, or canceling orders
- Providing information on course resources and university services
- General inquiries about university policies or procedures.
"""


# Handlers for different events in the Chainlit app
@cl.on_chat_start
async def start():
    await cl.Message(content="Hi, Welcome to Nagarro University. How can I help you? Press `P` to talk!").send()
    await setup_openai_realtime(system_prompt=system_prompt + "\n\n Customer ID: 12121")


@cl.on_message
async def on_message(message: cl.Message):
    openai_realtime: RealtimeClient = cl.user_session.get("openai_realtime")
    if openai_realtime and openai_realtime.is_connected():
        if is_supported_language(message.content):
            await openai_realtime.send_user_message_content([{"type": 'input_text', "text": message.content}])
        else:
            await cl.ErrorMessage(content="Only English and Hindi languages are supported.").send()
    else:
        await cl.Message(content="Please activate voice mode before sending messages!").send()


@cl.on_audio_start
async def on_audio_start():
    try:
        openai_realtime: RealtimeClient = cl.user_session.get("openai_realtime")
        await openai_realtime.connect()
        logger.info("Connected to OpenAI realtime")
        return True
    except Exception as e:
        await cl.ErrorMessage(content=f"Failed to connect to OpenAI realtime: {e}").send()
        return False


@cl.on_audio_chunk
async def on_audio_chunk(chunk: cl.InputAudioChunk):
    openai_realtime: RealtimeClient = cl.user_session.get("openai_realtime")
    if openai_realtime:
        if openai_realtime.is_connected():
            await openai_realtime.append_input_audio(chunk.data)
        else:
            logger.info("RealtimeClient is not connected")


@cl.on_audio_end
@cl.on_chat_end
@cl.on_stop
async def on_end():
    openai_realtime: RealtimeClient = cl.user_session.get("openai_realtime")
    if openai_realtime and openai_realtime.is_connected():
        await openai_realtime.disconnect()
