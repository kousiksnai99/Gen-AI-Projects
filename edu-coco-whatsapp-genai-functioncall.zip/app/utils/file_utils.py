import os
from werkzeug.utils import secure_filename

def save_file_temp(file, filename):
    upload_folder = 'Uploads'
    os.makedirs(upload_folder, exist_ok=True)
    file_path = os.path.join(upload_folder, filename)
    file.save(file_path)
    return file_path