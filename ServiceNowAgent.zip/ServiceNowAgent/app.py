"""FastAPI app: one endpoint per ServiceNow operation.

    GET  /health
    POST /create-interaction     open the conversation's record
    POST /create-incident        create the incident (or record the issue on the existing one)
    POST /update-incident        add a work note
    POST /resolve-incident       resolve, then report what actually stored
    POST /close-interaction      mark the chat as ended
    GET  /get-status             where the ticket stands

Every endpoint goes: agent writes the wording  ->  real ServiceNow call  ->  the number
ServiceNow issued. All of that is in logic.py; this file is only the HTTP layer.

Run:  python -m uvicorn app:app --reload --port 8000
Docs: http://127.0.0.1:8000/docs   (try every endpoint from there)
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from logic import CLIENT_SECRET, FOUNDRY_AGENT, FOUNDRY_ENDPOINT, ServiceNowAgent, ServiceNowError

app = FastAPI(title="ServiceNow Agent", version="1.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["GET", "POST"], allow_headers=["*"]
)

agent = ServiceNowAgent()


# Every field is its own named parameter: `details` and `note` are the user's own words,
# so as JSON values they can contain anything without becoming a second instruction.
class InteractionIn(BaseModel):
    conversation_id: str = Field(min_length=1, max_length=100)
    user_id: str = Field(default="", max_length=100)
    # Optional, but send it if you have it: the gateway's PUT cannot write
    # short_description, so the summary set here is permanent.
    details: str = Field(default="", max_length=4000)


class IncidentIn(BaseModel):
    conversation_id: str = Field(min_length=1, max_length=100)
    details: str = Field(min_length=1, max_length=4000)
    issue_type: str = Field(default="", max_length=60)
    interaction_id: str = Field(default="", max_length=40)


class UpdateIn(BaseModel):
    conversation_id: str = Field(min_length=1, max_length=100)
    note: str = Field(min_length=1, max_length=4000)
    incident_id: str = Field(default="", max_length=40)


class ResolveIn(BaseModel):
    conversation_id: str = Field(min_length=1, max_length=100)
    incident_id: str = Field(default="", max_length=40)
    interaction_id: str = Field(default="", max_length=40)


class CloseIn(BaseModel):
    conversation_id: str = Field(min_length=1, max_length=100)
    interaction_id: str = Field(default="", max_length=40)


def run(operation, *args, **kwargs):
    """Call one operation, turning a ServiceNow failure into a clear HTTP error.

    502 because the failure is upstream: this app worked, ServiceNow did not. A ticket
    that was never created must never be reported as one.
    """
    try:
        return operation(*args, **kwargs)
    except ServiceNowError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"{type(exc).__name__}: {exc}") from exc


@app.get("/health")
def health():
    return {
        "status": "ok",
        "servicenow_configured": bool(CLIENT_SECRET),
        "agent_configured": bool(FOUNDRY_ENDPOINT and FOUNDRY_AGENT),
    }


@app.post("/create-interaction")
def create_interaction(body: InteractionIn):
    """Open the conversation's record and return the number ServiceNow issued."""
    return run(agent.create_interaction, body.conversation_id, body.user_id, body.details)


@app.post("/create-incident")
def create_incident(body: IncidentIn):
    """Create the incident. Called twice for the same conversation, it adds a work note
    to the existing ticket rather than raising a duplicate."""
    return run(agent.create_incident, body.conversation_id, body.details,
               body.issue_type, body.interaction_id)


@app.post("/update-incident")
def update_incident(body: UpdateIn):
    """Add a work note. `incident_id` is optional -- the ticket is found from the
    conversation_id when it is omitted."""
    return run(agent.update_incident, body.conversation_id, body.note, body.incident_id)


@app.post("/resolve-incident")
def resolve_incident(body: ResolveIn):
    """Resolve the incident.

    Read `resolved` in the response, not the message alone: this gateway cannot currently
    write `state`, so a resolve is accepted and does not persist. The app re-reads the
    record and reports the truth.
    """
    return run(agent.resolve, body.conversation_id, body.incident_id, body.interaction_id)


@app.post("/close-interaction")
def close_interaction(body: CloseIn):
    """Mark the chat as ended. A work note -- the ticket stays open."""
    return run(agent.close_interaction, body.conversation_id, body.interaction_id)


@app.get("/get-status")
def get_status(conversation_id: str = "", incident_id: str = ""):
    """Where the ticket stands. Pass `incident_id` (e.g. INC09485371) or `conversation_id`."""
    if not (conversation_id or incident_id):
        raise HTTPException(status_code=422, detail="Pass conversation_id or incident_id.")
    return run(agent.get_status, conversation_id, incident_id)
