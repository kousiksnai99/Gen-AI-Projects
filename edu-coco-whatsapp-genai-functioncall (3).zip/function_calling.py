import json
import requests
import openai
import os
from dotenv import load_dotenv
from static_values import get_static_values
from call_functions import process_function_call
from database_utils import save_chat_to_db, get_chat_history_from_db
from cachetools import TTLCache

# Load environment variables
load_dotenv()

GPT_MODEL = "gpt-4o-mini"
# These lines configure the OpenAI API, potentially triggering HTTP requests when used
openai.api_key = os.getenv("OPENAI_API_KEY")  # Commented: Sets API key, could trigger logging if verbose
openai.api_base = os.getenv("OPENAI_API_BASE")  # Commented: Sets API base URL, affects request destination
openai.api_type = "azure"  # Commented: Specifies Azure as API type, could tie into Azure-related logging
openai.api_version = "2024-08-01-preview"  # Commented: API version, part of request configuration

class DynamicFunctionHandler:
    def __init__(self):
        self.static_values = get_static_values()
        self.dynamic_enums = self.static_values.get("dynamic_enums", {})
        self.caches = self._initialize_caches()

    def _initialize_caches(self):
        """Initialize caches dynamically based on TTL values from api.json."""
        caches = {}
        for enum_name, config in self.dynamic_enums.items():
            ttl = config.get("ttl", 3600)  # Default TTL to 1 hour if not specified
            caches[enum_name] = TTLCache(maxsize=100, ttl=ttl)
            # print(f"Initialized cache for {enum_name} with TTL: {ttl} seconds.")  # Commented out
        return caches

    def fetch_dynamic_enum(self, enum_name, user_id):
        """Fetch dynamic enum values with caching and print cache status."""
        api_config = self.dynamic_enums.get(enum_name, {})
        cache_key = f"{enum_name}_{user_id}" if "{user_id}" in api_config.get("url", "") else enum_name

        if enum_name not in self.caches:
            # print(f"Cache not initialized for {enum_name}.")  # Commented out
            return self._fetch_dynamic_enum(enum_name, user_id)

        if cache_key in self.caches[enum_name]:
            # print(f"Fetching {enum_name} from cache.")  # Commented out
            return self.caches[enum_name][cache_key]
        else:
            # print(f"Fetching {enum_name} from API (not found in cache).")  # Commented out
            result = self._fetch_dynamic_enum(enum_name, user_id)
            self.caches[enum_name][cache_key] = result
            return result

    def _fetch_dynamic_enum(self, enum_name, user_id):
        """Fetch dynamic enum values with proper LeaveName extraction."""
        if enum_name not in self.dynamic_enums:
            # print(f"Configuration missing for dynamic enum: {enum_name}")  # Commented out
            return []

        api_config = self.dynamic_enums[enum_name]
        url = api_config["url"].replace("{user_id}", str(user_id))

        try:
            # This line makes an HTTP request, which could trigger logging in a verbose setup
            response = requests.request(  # Commented: HTTP request that might log if library is verbose
                method=api_config["method"],
                url=url,
                headers=api_config.get("headers", {}),
                timeout=10
            )

            if response.status_code != 200:
                return []

            json_response = response.json()
            response_key = api_config.get("response_key", "")

            if isinstance(json_response, list):
                return [str(item[response_key]) for item in json_response if response_key in item] if response_key else [str(item) for item in json_response]
            
            return []

        except Exception as e:
            # print(f"Error processing {enum_name}: {str(e)}")  # Commented out
            return []

    def update_functions(self, functions, user_id):
        """Update functions dynamically with latest values."""
        updated_functions = []
        for func in functions.copy():
            for param_name, param_config in func["parameters"]["properties"].items():
                if "dynamic_enum" in param_config:
                    enum_name = param_config["dynamic_enum"]
                    param_config["enum"] = self.fetch_dynamic_enum(enum_name, user_id)
                    del param_config["dynamic_enum"]
            updated_functions.append(func)
        return updated_functions

def chat_completion_request(messages, username, userphonenumber, functions=None, function_call="auto", model=GPT_MODEL):
    try:
        enum_handler = DynamicFunctionHandler()
        updated_functions = enum_handler.update_functions(functions or [], userphonenumber)

        # This line calls the OpenAI API, likely causing HTTP requests and potential logging
        response = openai.ChatCompletion.create(  # Commented: Main API call to OpenAI, ties to Azure infrastructure
            engine=GPT_MODEL,
            model=model,
            messages=messages,
            functions=updated_functions,
            function_call=function_call,
        )

        assistant_message = response["choices"][0]["message"]

        if assistant_message.get("function_call"):
            fn_name = assistant_message["function_call"]["name"]
            arguments = json.loads(assistant_message["function_call"]["arguments"])
            arguments.update({"username": username, "userphonenumber": userphonenumber})

            assistant_message["content"] = process_function_call(fn_name, arguments)

        if assistant_message.get("content"):
            assistant_message["content"] = assistant_message["content"].replace("**", "*")

        return response

    except Exception as e:
        # print(f"Error in chat completion: {e}")  # Commented out
        return {"error": str(e)}