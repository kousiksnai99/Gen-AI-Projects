from flask import Flask, request,jsonify
from flask_cors import cross_origin, CORS
import torch
from quiz_business_logic import ContextToQuestionService
import os
#from azure.identity import ManagedIdentityCredential
#from azure.keyvault.secrets import SecretClient

app = Flask(__name__)
CORS(app)
UPLOAD_FOLDER = '/uploads'

#-----------------------------Intializing secrets------------------------------
'''credential = ManagedIdentityCredential()
KEYVAULT_NAME = os.environ['KEYVAULT_NAME']
client = SecretClient(f"https://{KEYVAULT_NAME}.vault.azure.net/",credential)
application_token = client.get_secret("ai-application-token")
application_token = application_token.value'''
#-----------------------------Intializing secrets------------------------------
application_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0.eyJ1c2VyX2lkIjoxMjMsInVzZXJuYW1lIjoiZXhhbXBsZV91c2VyIiwic3ViIjoiNDI0MiIsIm5pY2tuYW1lIjoiSmVzcyJ9."
#-------------remove for the testing------------
#----------------remove--------------------

#making a temp folder for uploading the document 
try:
    path = os.path.dirname(os.path.abspath(__file__))
    upload_folder=os.path.join(
    path.replace(UPLOAD_FOLDER,""),"tmp")
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder

except Exception as e:
    print("An error occurred while creating temp folder")
    print("Exception occurred : {}".format(e))

@app.route('/', methods = ['GET'])
@cross_origin()
def welcome_to():
    return 'Welcome to NLP Questions-Answer module:)'
    
#API for generating the MCQ
@app.route('/api/coco/questions/mcq', methods = ['POST'])
@cross_origin()
def get_questions():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            data = request.get_json()   
            context = data['context']
            question_count = data.get('question_count')
            Tags = data.get("Tags", "default_tag")  
            summary = data.get("summary", "default_summary")
            return ContextToQuestionService.get_mcq(context, question_count, Tags, summary)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})


#Api for uploading the document  for MCQ
@app.route('/api/process/document/mcq', methods = ['POST'])
@cross_origin()
def process_document_mcq():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            if 'file' not in request.files:
                return jsonify({'success': False, 'message': 'No file part'})
            file = request.files['file']
            print("The filename is ",file)
            count = request.form['question_count']

            if file.filename == '':
                return jsonify({'success': False, 'message': 'No selected file'})

            return ContextToQuestionService.processDocument(file,count,"mcq")
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

#Api for uploading the document  for fill_in_the_blank
@app.route('/api/questions/fill_in_the_blank', methods = ['POST'])
@cross_origin()
def get_fill_in_the_blank():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            data = request.get_json()   
            context = data['context']
            question_count = data.get('question_count')

            return ContextToQuestionService.get_fill_in_the_blanks(context, question_count)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

#Api for uploading the document for fill_in_the_blank
@app.route('/api/process/document/fill_in_the_blank', methods = ['POST'])
@cross_origin()
def process_document_fill_in_the_blank():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            if 'file' not in request.files:
                return jsonify({'success': False, 'message': 'No file part'})
            file = request.files['file']
            count = request.form['question_count']

            if file.filename == '':
                return jsonify({'success': False, 'message': 'No selected file'})

            return ContextToQuestionService.processDocument(file,count,"Fill_in_the_blanks")
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})


#Api for uploading the document  for True_false
@app.route('/api/questions/true_false', methods = ['POST'])
@cross_origin()
def get_true_false_questions():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            data = request.get_json()   
            context = data['context']
            question_count = data.get('question_count')

            return ContextToQuestionService.get_true_false_questions(context, question_count)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

#Api for uploading the document for True and False
@app.route('/api/process/document/true_false', methods = ['POST'])
@cross_origin()
def process_document_true_false():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):

            if 'file' not in request.files:
                return jsonify({'success': False, 'message': 'No file part'})
            file = request.files['file']
            count = request.form['question_count']

            if file.filename == '':
                return jsonify({'success': False, 'message': 'No selected file'})

            return ContextToQuestionService.processDocument(file,count,"True_and_False")
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})



#Api for uploading the document  all type of questions
@app.route('/api/questions/all', methods = ['POST'])
@cross_origin()
def get_all_type_questions():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            data = request.get_json()   
            context = data['context']
            mcq_count = data.get('mcq_count')
            mcq_easy_count = data.get('mcq_easy_count')
            mcq_medium_count = data.get('mcq_medium_count')
            mcq_hard_count = data.get('mcq_hard_count')
            fill_in_the_blank_count = data.get('fill_in_the_blank_count')
            print("before")
            true_false_count = data.get('true_false_count')
            print("after")
            tf_easy_count = data.get('tf_easy_count')
            tf_medium_count = data.get('tf_medium_count')
            tf_hard_count = data.get('tf_hard_count')
            try:
                mcq_count=int(mcq_count)
            except:
                mcq_count=0
            try:
                mcq_easy_count=int(mcq_easy_count)
            except:
                mcq_easy_count=0
            try:
                mcq_medium_count=int(mcq_medium_count)
            except:
                mcq_medium_count=0
            try:
                mcq_hard_count=int(mcq_hard_count)
            except:
                mcq_hard_count=0
            try:
                fill_in_the_blank_count=int(fill_in_the_blank_count)
            except:
                fill_in_the_blank_count=0
            try:
                true_false_count=int(true_false_count)
            except:
                true_false_count=0
            try:
                tf_easy_count=int(tf_easy_count)
            except:
                tf_easy_count=0
            try:
                tf_medium_count=int(tf_medium_count)
            except:
                tf_medium_count=0
            try:
                tf_hard_count=int(tf_hard_count)
            except:
                tf_hard_count=0

            
            mcq_difflevel=[mcq_easy_count,mcq_medium_count,mcq_hard_count]
            tf_difflevel = [tf_easy_count,tf_medium_count,tf_hard_count]    

            return ContextToQuestionService.getAllTypeQuestionsMix(context, mcq_count,mcq_difflevel ,fill_in_the_blank_count, true_false_count,tf_difflevel)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})

#Api for uploading the document for all type of question
@app.route('/api/process/document/all', methods = ['POST'])
@cross_origin()
def process_document_all():
    if 'Authorization' in request.headers:
        auth_header = request.headers.get('Authorization')
        if(auth_header==application_token):
            if 'file' not in request.files:
                return jsonify({'success': False, 'message': 'No file part'})
            file = request.files['file']
            mcq_count = request.form['mcq_count']
            mcq_easy_count = request.form['mcq_easy_count']
            mcq_medium_count = request.form['mcq_medium_count']
            mcq_hard_count = request.form['mcq_hard_count']
            fill_in_the_blank_count = request.form['fill_in_the_blank_count']
            true_false_count = request.form['true_false_count']
            tf_easy_count = request.form['tf_easy_count']
            tf_medium_count = request.form['tf_medium_count']
            tf_hard_count = request.form['tf_hard_count']
            try:
                mcq_count=int(mcq_count)
            except:
                mcq_count=0
            try:
                mcq_easy_count=int(mcq_easy_count)
            except:
                mcq_easy_count=0
            try:
                mcq_medium_count=int(mcq_medium_count)
            except:
                mcq_medium_count=0
            try:
                mcq_hard_count=int(mcq_hard_count)
            except:
                mcq_hard_count=0
            try:
                fill_in_the_blank_count=int(fill_in_the_blank_count)
            except:
                fill_in_the_blank_count=0
            try:
                true_false_count=int(true_false_count)
            except:
                true_false_count=0
            try:
                tf_easy_count=int(tf_easy_count)
            except:
                tf_easy_count=0
            try:
                tf_medium_count=int(tf_medium_count)
            except:
                tf_medium_count=0
            try:
                tf_hard_count=int(tf_hard_count)
            except:
                tf_hard_count=0

            if file.filename == '':
                return jsonify({'success': False, 'message': 'No selected file'})
            print(file)
            mcq_difflevel=[mcq_easy_count,mcq_medium_count,mcq_hard_count]
            tf_difflevel = [tf_easy_count,tf_medium_count,tf_hard_count]
            return ContextToQuestionService.processDocument_all_cases(file, mcq_count,mcq_difflevel, fill_in_the_blank_count, true_false_count,tf_difflevel)
        else:
            return jsonify({'success': False, 'message': 'Invalid request'})
    else:
        return jsonify({'success': False, 'message': "Authorization header missing"})
# driver function
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=5002)