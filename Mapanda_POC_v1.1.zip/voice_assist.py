import random
import re
import streamlit as st
import azure.cognitiveservices.speech as speechsdk
from autogen import AssistantAgent, UserProxyAgent
from typing import Annotated

# Azure Speech Service Configuration
SPEECH_KEY = "216ba0fd67b64d0b80f65fa7845302c8"
SPEECH_REGION = "centralindia"

# Define your LLM configuration
llm_config = {
    "model": "gpt-35-turbo",
    "api_version": "2023-03-15-preview",
    "temperature": 0.0,
    "api_key": "e4f02201204c42a6beeb67e3e30e2831",
    "api_type": "azure",
    "base_url": "https://rfp-openai-service.openai.azure.com/"
}

# Define simple calculator functions with print statements for testing
def add_numbers(
    a: Annotated[int, "First number"], b: Annotated[int, "Second number"]
) -> str:
    st.write(f"Calling add_numbers with a={a} and b={b}")
    return f"The sum of {a} and {b} is {a + b}."

def multiply_numbers(
    a: Annotated[int, "First number"], b: Annotated[int, "Second number"]
) -> str:
    st.write(f"Calling multiply_numbers with a={a} and b={b}")
    return f"The product of {a} and {b} is {a * b}."

# Initialize the Mickey agent
Mickey_agent = AssistantAgent(
    name="MickeyAgent",
    llm_config=llm_config,
    system_message="You are Mickey, a friendly, patient, and playful tutor for children aged 4-5 years. "
                   "You must use very simple language, keep your sentences short, and provide clear answers that a child can easily understand. "
                   "Always stay within 40 words. Speak in a soft and encouraging tone. "
                   "Make learning fun, be patient, and give answers that are easy to grasp for a 4-5-year-old child.",
    description="You are Mickey, a playful online tutor for children aged 4-5 years",
    human_input_mode="NEVER"
)

# Register the tool signatures with the assistant agent.
Mickey_agent.register_for_llm(name="add_numbers", description="Add two numbers")(add_numbers)
Mickey_agent.register_for_llm(name="multiply_numbers", description="Multiply two numbers")(multiply_numbers)

# Initialize the UserAgent
User_agent = UserProxyAgent(
    name="UserAgent",
    llm_config=llm_config,
    description="A human user capable of interacting with AI agents.",
    code_execution_config=False,
    human_input_mode="NEVER",
    is_termination_msg=lambda msg: "tool_calls" not in msg and msg["role"] != "tool"
)

# Global variable to store the message history and current quiz state
message_history = {
    "Mickey_agent": [],
    "user_agent": []
}
current_quiz = None

def save_history(history):
    global message_history
    message_history = history

def get_history():
    global message_history
    return message_history

# Predefined questions for the quiz
quiz_questions = [
    {"question": "What color is the sky?", "options": ["Blue", "Green", "Red"], "answer": "Blue"},
    {"question": "How many legs does a dog have?", "options": ["2", "3", "4"], "answer": "4"},
    {"question": "What sound does a cat make?", "options": ["Woof", "Meow", "Moo"], "answer": "Meow"},
]

def generate_quiz():
    global current_quiz
    current_quiz = random.choice(quiz_questions)
    question = current_quiz["question"]
    options = current_quiz["options"]
    return {"question": question, "options": options}

def validate_quiz_answer(user_answer):
    if current_quiz and user_answer.lower() == current_quiz["answer"].lower():
        return "That's correct! Well done!"
    else:
        return f"Oops! The correct answer is {current_quiz['answer']}."

def recognize_speech():
    speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
    speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)
    st.write("🎤 Listening...")
    result = speech_recognizer.recognize_once()
    if result.reason == speechsdk.ResultReason.RecognizedSpeech:
        return result.text
    else:
        return None

def synthesize_speech(text):
    speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
    speech_config.speech_synthesis_voice_name = "en-US-JennyNeural"
    audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
    speech_synthesizer.speak_text_async(text).get()

def display_message(sender, message):
    if sender == "user":
        st.markdown(f"<div style='text-align: right; background-color: #DCF8C6; padding: 8px; border-radius: 10px; margin: 5px;'>"
                    f"<strong>You:</strong> {message}</div>", unsafe_allow_html=True)
    else:
        st.markdown(f"<div style='text-align: left; background-color: #FFF9C4; padding: 8px; border-radius: 10px; margin: 5px;'>"
                    f"<strong>Mickey:</strong> {message}</div>", unsafe_allow_html=True)

def main():
    global current_quiz

    st.title("🧸 MICKEY: A FRIENDLY TUTOR FOR KIDS")
    st.write("Welcome to Mickey's chat! Press 'Start Chat' to begin speaking. Say 'please stop' to exit.")

    if st.button('🟢 Start Chat'):
        # Initial greeting by Mickey
        initial_greeting = "Hi, I am Mickey, a tutor for children aged 4-5 years. How may I help you?"
        display_message("mickey", initial_greeting)
        synthesize_speech(initial_greeting)
        
        user_input = ""
        while "please stop" not in (user_input or "").lower():
            user_input = recognize_speech()
            if user_input:
                display_message("user", user_input)

                if "please stop" in user_input.lower():
                    farewell_message = "Okay, It was nice talking to you. Have a great day!"
                    display_message("mickey", farewell_message)
                    synthesize_speech(farewell_message)
                    break

                if current_quiz:
                    validation_message = validate_quiz_answer(user_input)
                    display_message("mickey", validation_message)
                    synthesize_speech(validation_message)
                    current_quiz = None
                else:
                    if "quiz" in user_input.lower() or "play quiz" in user_input.lower():
                        quiz = generate_quiz()
                        question = quiz["question"]
                        options = ", ".join(quiz["options"])
                        display_message("mickey", f"{question}. Options: {options}")
                        synthesize_speech(f"{question}. Your options are {options}")
                    else:
                        # Check for arithmetic expressions and call the appropriate function
                        match = re.match(r"(\d+)\s*([+*])\s*(\d+)", user_input)
                        if match:
                            a, operator, b = int(match.group(1)), match.group(2), int(match.group(3))
                            if operator == '+':
                                result_message = add_numbers(a, b)
                            elif operator == '*':
                                result_message = multiply_numbers(a, b)
                            else:
                                result_message = "I can only add or multiply two numbers."
                            display_message("mickey", result_message)
                            synthesize_speech(result_message)
                        else:
                            history = get_history()
                            User_agent._oai_messages = {Mickey_agent: history["user_agent"]}
                            response = User_agent.initiate_chat(Mickey_agent, message=user_input, clear_history=False, summary_method="last_msg")
                            save_history({"user_agent": User_agent.chat_messages.get(Mickey_agent)})
                            display_message("mickey", response.summary[:40])  # Limit response to 40 words
                            synthesize_speech(response.summary[:40])

if __name__ == "__main__":
    main()
