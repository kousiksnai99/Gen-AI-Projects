from flask import Flask, request, jsonify
import uuid
import copy
import json
import logging
from flask_cors import CORS
from static_values import get_static_values
from function_calling import chat_completion_request, save_chat_to_db, get_chat_history_from_db
from datetime import date
from knowledge_base import KnowledgeBaseBusinessLogic
from werkzeug.utils import secure_filename

# Initialize Flask App
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configure Logging
logging.basicConfig(level=logging.INFO)

# Load static values
static_values = get_static_values()
functions = static_values["functions"]
initial_messages = static_values["initial_messages"]

@app.route('/', methods=['GET'])
def welcome_to():
    return 'Welcome to AI Knowledge Base Module :)'

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.json
        session_id = data.get("session_id", str(uuid.uuid4()))
        user_input = data.get("user_input", "").strip()

        if not user_input:
            return jsonify({"error": "User input is required."}), 400

        username = data.get("username", "Unknown User")
        userphonenumber = data.get("userphonenumber", "Unknown Number")
        
        # Mask user phone number in logs
        masked_phone = userphonenumber[:2] + "*" * (len(userphonenumber) - 4) + userphonenumber[-2:]
        logging.info(f"Received input: {user_input} (Session ID: {session_id}, User: {username}, Phone: {masked_phone})")

        # Retrieve existing chat history
        chat_history = get_chat_history_from_db(session_id)

        # Prepare messages for ChatGPT
        messages = copy.deepcopy(initial_messages)
        messages[0]["content"] = messages[0]["content"].replace("{current_date}", date.today().strftime("%B %d, %Y"))

        for entry in chat_history:
            messages.append({"role": "user", "content": entry["user_input"]})
            messages.append({"role": "assistant", "content": entry["assistant_response"]})

        # Append the current user input
        messages.append({"role": "user", "content": user_input})

        # Call ChatGPT API
        chat_response = chat_completion_request(messages, username, userphonenumber, functions=functions)
        assistant_message = chat_response.get("choices", [{}])[0].get("message", {})
        response_content = {}

        if "content" in assistant_message:
            response_content["response"] = assistant_message["content"]
            chat_history.append({"user_input": user_input, "assistant_response": assistant_message["content"]})
        elif "function_call" in assistant_message:
            fn_name = assistant_message["function_call"]["name"]
            try:
                arguments = json.loads(assistant_message["function_call"]["arguments"])
            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in function arguments: {assistant_message['function_call']['arguments']}")
                return jsonify({"error": "Invalid function arguments format."}), 400

            response_content["function_call"] = {"name": fn_name, "arguments": arguments}
        # Save updated chat history
        save_chat_to_db(session_id, user_input, response_content.get("response", ""))

        return jsonify(response_content)

    except Exception as e:
        logging.error(f"An error occurred: {e}", exc_info=True)
        return jsonify({"error": "Internal server error. Please try again later."}), 500

# New API route for document upload
@app.route('/savekb', methods=['POST'])
def process_document():
    try:
        # Check if file is present in request
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': 'No file part'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No selected file'}), 400

        logging.info(f"Processing file: {file.filename}")

        # Call the processing logic from KnowledgeBaseBusinessLogic
        response = KnowledgeBaseBusinessLogic.processDocument(file)
        return response

    except Exception as e:
        logging.error(f"Error processing document: {e}", exc_info=True)
        return jsonify({'success': False, 'message': 'Internal server error'}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002, debug=False)