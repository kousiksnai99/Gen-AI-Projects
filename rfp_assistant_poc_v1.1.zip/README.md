# Setup
+ Setup Python environment version `3.10.9`
+ Create Virtual Environment    
    + RUN `python -m venv myEnv`
    + Activate environment [Reference Document - `https://docs.python.org/3/library/venv.html`]
+ Run cmd `pip install -r requirements.txt`
+ open .env file and setup all API keys
+ RunApp  `python app.py`


## API Endpoints


+ To Feed the PDF
    + [POST] /api/v1/kb/process/document
        + Request Body - 
            ``` 'file' : 'attchment' ```
