# Multilingual Service Desk Agent — Azure Function App

Calls your existing Azure AI Foundry agent **`multilingual-agent`** over HTTP.
The prompt/instructions live in Foundry, NOT in this code.

Structure (Azure Functions v1 Python model — `function.json` + `__init__.py`):

```
Multilingual_Agent/
├─ host.json
├─ requirements.txt
├─ local.settings.json          # local only, NOT deployed
└─ MultilingualAgent/
   ├─ __init__.py
   └─ function.json
```

Endpoint after deploy: `POST/GET https://<your-func-app>.azurewebsites.net/api/MultilingualAgent`

## 1. Config — hardcoded (nothing to set in App settings)

Endpoint and agent name are hardcoded at the top of `MultilingualAgent/__init__.py`.
Optionally paste the agent id into `AGENT_ID` there to skip the name lookup.

## 2. Auth — DefaultAzureCredential (the ONE required Azure step)

Auth uses `DefaultAzureCredential`, which on the deployed app reads the Function App's
**Managed Identity**. This is the only thing that is NOT in code — it MUST be set up
or every call returns 401:

1. Function App → **Identity** → System assigned → **On** → Save.
2. On the **Azure AI Foundry project** (or its parent resource) → **Access control (IAM)** →
   **Add role assignment** → role **`Azure AI User`** (or `Azure AI Developer`) →
   assign to the Function App's managed identity.

No API key is used — the API key you have is for the `*.openai.azure.com` endpoint and
does NOT authenticate the Foundry `projects` endpoint.

## 3. Deploy

VS Code: Azure Functions extension → right-click the folder → **Deploy to Function App**.

Or CLI (from the `Multilingual_Agent` folder):
```
func azure functionapp publish <your-func-app-name>
```

## 4. Test

```
curl "https://<your-func-app>.azurewebsites.net/api/MultilingualAgent?message=hello&code=<function-key>"
```
POST:
```
curl -X POST "https://<your-func-app>.azurewebsites.net/api/MultilingualAgent?code=<function-key>" \
  -H "Content-Type: application/json" -d "{\"message\":\"my laptop won't connect to wifi\"}"
```
Get `<function-key>` from Function App → the function → **Function Keys**.

## Fixing the Hindi issue (do this in Foundry, not in code)

Because the agent runs in Foundry, its instructions live there. Open the
`multilingual-agent` agent in the Foundry portal and make the language gate the
FIRST, unconditional step — explicitly stating Hindi is NOT supported and covering
romanized Hindi (e.g. "mujhe help chahiye"), so unsupported languages always return
the exact English "not supported" message. Also set the agent **temperature to 0**.
