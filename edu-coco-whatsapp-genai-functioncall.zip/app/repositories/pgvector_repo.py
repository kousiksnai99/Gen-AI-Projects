import logging
import tiktoken
import psycopg2
import uuid
from typing import List, Dict, Any
from azure.storage.blob import BlobServiceClient
from langchain.text_splitter import RecursiveCharacterTextSplitter
from app.config.settings import AZURE_STORAGE_CONFIG, PGVECTOR_CONFIG
from app.repositories.vector_store import get_vector_store

class PGVectorRepository:
    @staticmethod
    def get_db_connection():
        return psycopg2.connect(
            host=PGVECTOR_CONFIG["host"],
            port=PGVECTOR_CONFIG["port"],
            database=PGVECTOR_CONFIG["database"],
            user=PGVECTOR_CONFIG["user"],
            password=PGVECTOR_CONFIG["password"],
            sslmode="require"
        )

    @staticmethod
    def ensure_vector_extension():
        try:
            with PGVectorRepository.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
                conn.commit()
                logging.info("Vector extension created or already exists")
        except Exception as e:
            logging.error(f"Failed to create vector extension: {e}")
            raise Exception(f"Failed to create vector extension: {e}") from e

    @staticmethod
    def ensure_vector_ids_table():
        create_table_query = """
        CREATE TABLE IF NOT EXISTS vector_ids (
            id SERIAL PRIMARY KEY,
            filename VARCHAR(255) NOT NULL,
            vector_id VARCHAR(255) NOT NULL,
            UNIQUE (filename, vector_id)
        );
        """
        try:
            with PGVectorRepository.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(create_table_query)
                conn.commit()
                logging.info("vector_ids table created or already exists")
        except Exception as e:
            logging.error(f"Error creating vector_ids table: {e}")
            raise Exception(f"Failed to create vector_ids table: {e}") from e

    @staticmethod
    def store_vector_ids(filename: str, vector_ids: List[str]):
        insert_query = """
        INSERT INTO vector_ids (filename, vector_id)
        VALUES (%s, %s)
        ON CONFLICT (filename, vector_id) DO NOTHING;
        """
        try:
            with PGVectorRepository.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    for vector_id in vector_ids:
                        cursor.execute(insert_query, (filename, vector_id))
                conn.commit()
                logging.info(f"Stored {len(vector_ids)} vector IDs for {filename}")
        except Exception as e:
            logging.error(f"Error storing vector IDs for {filename}: {e}")
            raise Exception(f"Failed to store vector IDs: {e}") from e

    @staticmethod
    def delete_vectors_by_filename(filename: str):
        select_query = """
        SELECT vector_id FROM vector_ids WHERE filename = %s;
        """
        delete_query = """
        DELETE FROM vector_ids WHERE filename = %s;
        """
        try:
            with PGVectorRepository.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(select_query, (filename,))
                    vector_ids = [row[0] for row in cursor.fetchall()]
                    if vector_ids:
                        cursor.execute(delete_query, (filename,))
                        logging.info(f"Deleted {len(vector_ids)} vector IDs for {filename}")
                    else:
                        logging.info(f"No vector IDs found for {filename}")
                conn.commit()
            return vector_ids
        except Exception as e:
            logging.error(f"Error deleting vectors for {filename}: {e}")
            raise Exception(f"Failed to delete vectors: {e}") from e

    @staticmethod
    def upload_vector_ids_to_azure(filename: str, vector_ids: List[str]):
        try:
            blob_service_client = BlobServiceClient.from_connection_string(AZURE_STORAGE_CONFIG["connection_string"])
            container_client = blob_service_client.get_container_client(AZURE_STORAGE_CONFIG["container_name"])
            blob_name = f"vector_ids/{filename}_vector_id.txt"
            vector_id_content = "\n".join(vector_ids)
            container_client.upload_blob(name=blob_name, data=vector_id_content, overwrite=True)
            logging.info(f"Uploaded vector IDs for {filename} to Azure Blob Storage")
        except Exception as e:
            logging.error(f"Error uploading vector IDs for {filename} to Azure: {e}")
            raise Exception(f"Failed to upload vector IDs to Azure: {e}") from e

    @staticmethod
    def get_vectorstore():
        PGVectorRepository.ensure_vector_extension()
        PGVectorRepository.ensure_vector_ids_table()
        return get_vector_store("pgvector")

    @staticmethod
    def save_to_vectorstore(filename: str, text: str) -> Dict[str, Any]:
        try:
            encoding = tiktoken.get_encoding("cl100k_base")
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=500,
                chunk_overlap=100,
                length_function=lambda x: len(encoding.encode(x)),
                add_start_index=True
            )
            text_chunks = text_splitter.split_text(text)
            metadata = [{"source": filename, "start_index": i * 500} for i in range(len(text_chunks))]

            vector_store = PGVectorRepository.get_vectorstore()
            vector_ids = vector_store.add_texts(texts=text_chunks, metadatas=metadata)

            PGVectorRepository.store_vector_ids(filename, vector_ids)
            PGVectorRepository.upload_vector_ids_to_azure(filename, vector_ids)

            summary = f"Text extracted and indexed from {filename}"
            return {
                "success": True,
                "message": "Vectorstore successfully created",
                "summary": summary
            }
        except Exception as e:
            logging.error(f"Error saving to vectorstore for {filename}: {e}")
            return {
                "success": False,
                "message": f"Failed to save to vectorstore: {str(e)}",
                "summary": ""
            }