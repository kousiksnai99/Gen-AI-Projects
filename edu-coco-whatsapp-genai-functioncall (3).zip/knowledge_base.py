import os
import re
import logging
from flask import current_app, jsonify
from werkzeug.utils import secure_filename
from azure.storage.filedatalake import DataLakeServiceClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from langchain.text_splitter import TokenTextSplitter
from langchain_community.document_loaders import UnstructuredWordDocumentLoader
from langchain_community.vectorstores.azuresearch import AzureSearch
import pymupdf
from langchain.embeddings import OpenAIEmbeddings

# Load environment variables
vector_store_address = os.getenv("AZURE_SEARCH_ENDPOINT")
vector_store_password = os.getenv("AZURE_SEARCH_KEY")
account_name = os.getenv("AZURE_STORAGE_ACCOUNT_NAME")
account_key = os.getenv("AZURE_STORAGE_ACCOUNT_KEY")
container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME")
File_directory = "Uploaded-files/"
Id_directory = "File_ids/"
openai_api_token = os.getenv("OPENAI_API_KEY")
api_base = os.getenv("OPENAI_API_BASE")
region= "eastus"

'''# Debug: Print credentials
print("Account Name:", account_name)
print("Account Key:", account_key)
print("Container Name:", container_name)

# Validate credentials
if not all([account_name, account_key, container_name]):
    raise ValueError("One or more Azure Storage credentials are missing.")
'''
ALLOWED_EXTENSIONS = {'pdf', 'docx'}

# Initialize embeddings
embeddingsModel = OpenAIEmbeddings(
    deployment="text-embedding-ada-002",
    model="text-embedding-ada-002",
    chunk_size=1,
    openai_api_key=openai_api_token,
    openai_api_base=api_base,
    openai_api_type="azure"
)

class KnowledgeBaseDataAccess:
    @staticmethod
    def extract_text_from_pdf(pdf_path):
        pdf_document = pymupdf.open(pdf_path)
        extracted_content = ""

        for page in pdf_document:
            text = page.get_text()
            extracted_content += text + " "

        extracted_content = re.sub(r'[^A-Za-z0-9\s]', '', extracted_content)
        extracted_content = re.sub(r'\s+', ' ', extracted_content).strip()
        pdf_document.close()
        return extracted_content

    @staticmethod
    def extract_text_from_docx(docx_path):
        unDoc = UnstructuredWordDocumentLoader(docx_path)
        docs = unDoc.load()
        text = ""
        for doc in docs:
            text += doc.page_content + " "
        
        text = re.sub(r'[^A-Za-z0-9\s]', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    @staticmethod
    def get_text_chunks(text):
        text_splitter = TokenTextSplitter(chunk_size=500, chunk_overlap=100)
        chunks = text_splitter.split_text(text)
        logging.info(f"Created {len(chunks)} text chunks")
        return chunks

    @staticmethod
    def get_vectorstore(text_chunks, filename, file_present):
        index_name = "test-indexes"
        vector_store = AzureSearch(
            azure_search_endpoint=vector_store_address,
            azure_search_key=vector_store_password,
            index_name=index_name,
            embedding_function=embeddingsModel.embed_query,
        )

        service_client = DataLakeServiceClient(
            account_url=f"https://{account_name}.dfs.core.windows.net",
            credential=account_key
        )
        file_system_client = service_client.get_file_system_client(file_system=container_name)
        credential = AzureKeyCredential(vector_store_password)
        search_client = SearchClient(vector_store_address, index_name, credential)

        if file_present == "True":
            with open("vector_id.txt", "r") as file:
                content = file.readlines()
            for id in content:
                id = id.strip()
                logging.info(f"Deleting vector with id: {id}")
                search_client.delete_documents(documents=[{"id": id}])
            logging.info("Deleted existing vectors")

        metadata = [{"source": filename} for _ in text_chunks]
        vec = vector_store.add_texts(text_chunks, metadatas=metadata)

        with open('vector_id.txt', 'w') as f:
            for i in vec:
                f.write(f"{i}\n")

        file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
        with open("vector_id.txt", "rb") as local_file:
            file_client.upload_data(local_file, overwrite=True)
        logging.info("Text added to vector store")

        try:
            os.remove('vector_id.txt')
        except:
            logging.info("vector_id.txt not found for deletion")

class KnowledgeBaseBusinessLogic:
    @staticmethod
    def allowed_file(filename):
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

    @staticmethod
    def file_exist_check(filename, file_path_to_save):
        try:
            service_client = DataLakeServiceClient(
                account_url=f"https://{account_name}.dfs.core.windows.net",
                credential=account_key
            )
            file_system_client = service_client.get_file_system_client(file_system=container_name)

            # Ensure directories exist (create if they don’t)
            try:
                file_system_client.create_directory(File_directory)
                file_system_client.create_directory(Id_directory)
            except Exception as e:
                logging.info(f"Directories already exist or error: {e}")

            # Check and delete existing file
            paths = file_system_client.get_paths(path="Uploaded-files/")
            filename = filename.replace(" ", "_")
            for path in paths:
                res = path.name.split('/')[-1]
                if filename == res:
                    file_client = file_system_client.get_file_client(path.name)
                    file_client.delete_file()
                    logging.info(f"Deleted existing file: {path.name}")

            # Upload new file
            file_client = file_system_client.get_file_client(f"{File_directory}{filename}")
            with open(file_path_to_save, "rb") as local_file:
                file_client.upload_data(local_file, overwrite=True, connection_timeout=300000)
                logging.info(f"Uploaded file: {filename}")

            # Check for existing vector IDs
            paths = file_system_client.get_paths(path=Id_directory)
            for path in paths:
                name = path.name.split('/')[-1].rsplit('.', 1)[0]
                if filename == name:
                    file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                    download = file_client.download_file()
                    with open("vector_id.txt", "wb") as my_file:
                        my_file.write(download.readall())
                    file_client.delete_file()
                    logging.info(f"Found and processed existing vector ID for: {filename}")
                    return "True"
            return "False"
        except Exception as e:
            logging.error(f"Error in file_exist_check: {e}", exc_info=True)
            raise

    @staticmethod
    def process_pdf(file_path, filename, file_present):
        text = KnowledgeBaseDataAccess.extract_text_from_pdf(file_path)
        text_chunks = KnowledgeBaseDataAccess.get_text_chunks(text)
        KnowledgeBaseDataAccess.get_vectorstore(text_chunks, filename, file_present)
        return "Text extracted and indexed"

    @staticmethod
    def process_docx(file_path, filename, file_present):
        text = KnowledgeBaseDataAccess.extract_text_from_docx(file_path)
        text_chunks = KnowledgeBaseDataAccess.get_text_chunks(text)
        KnowledgeBaseDataAccess.get_vectorstore(text_chunks, filename, file_present)
        return "Text extracted and indexed"

    @staticmethod
    def processDocument(file):
        try:
            if not KnowledgeBaseBusinessLogic.allowed_file(file.filename):
                return jsonify({'success': False, 'message': 'File type not supported'})

            filename = secure_filename(file.filename)
            extension = filename.rsplit('.', 1)[1].lower()
            file_path_to_save = os.path.join(current_app.config.get('UPLOAD_FOLDER', 'uploads'), filename)
            os.makedirs(os.path.dirname(file_path_to_save), exist_ok=True)
            file.save(file_path_to_save)

            logging.info(f"File saved at {file_path_to_save}. Extension: {extension}")

            file_present = KnowledgeBaseBusinessLogic.file_exist_check(filename, file_path_to_save)

            if extension == 'pdf':
                response = KnowledgeBaseBusinessLogic.process_pdf(file_path_to_save, filename, file_present)
            elif extension == 'docx':
                response = KnowledgeBaseBusinessLogic.process_docx(file_path_to_save, filename, file_present)

            os.remove(file_path_to_save)
            return jsonify({'success': True, 'message': 'Vectorstore successfully created', 'summary': response})

        except Exception as e:
            logging.error(f"Error processing document: {e}", exc_info=True)
            return jsonify({'success': False, 'message': str(e)})