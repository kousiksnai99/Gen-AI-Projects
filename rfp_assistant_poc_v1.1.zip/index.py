import os
from langchain.text_splitter import TokenTextSplitter
from flask import current_app
import time
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from langchain_community.vectorstores import AzureSearch
from azure.core.credentials import AzureKeyCredential
import fitz  # PyMuPDF
import pymupdf
from PIL import Image
import itertools
import google.generativeai as genai
from dotenv import load_dotenv
from pathlib import Path
import re
import hashlib
from llm import LangModel
import pandas as pd
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import openpyxl
from openpyxl.styles import Font, Alignment
from langchain_community.vectorstores import AzureSearch
from langchain_community.chat_models import AzureChatOpenAI


vector_store_password = os.getenv("vector_store_password")
vector_store_address = os.getenv("vector_store_address")
output_folder = "spireimages"
index_name = "rfp-vector-indexes"

class DataIndex:
    @staticmethod
    def get_data_fromgemini(image_path):
        input_prompt = """
               You are an expert in understanding and analyzing images, flowcharts.
               You will receive images as input &
               you have to describe the image properly with all key information included.
               Describe the image and if the whole image is black or grey in color then give "Nothing" as a response.
               Don't make any assumption for the image.
               """
        img = Path(image_path)
        image_parts = [
            {
                "mime_type": "image/png",
                "data": img.read_bytes()
            }
        ]
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content([input_prompt, image_parts[0], "Give all the details of the image if there is text present"])
        print(response.text)
        return response.text

    @staticmethod
    def extract_images_unique(pdf_document, images_path):
        """
        Extracts images from a PDF file and saves them, removing duplicates based on hash.
        
        Args:
            pdf_document (fitz.Document): PDF document.
            images_path (str): Path to the directory for saving extracted images.
        
        Returns:
            List of paths to the saved images.
        """
        page_nums = len(pdf_document)
        images_list = []
        processed_hashes = set()  # Store hashes of processed images to avoid duplicates
        saved_images = []  # List to store paths of saved images

        # Extract all images information from each page
        for page_num in range(page_nums):
            page_content = pdf_document[page_num]
            images_list.extend(page_content.get_images(full=True))

        # Save all unique extracted images
        for i, img in enumerate(images_list, start=1):
            xref = img[0]
            base_image = pdf_document.extract_image(xref)
            image_bytes = base_image['image']
            image_ext = base_image['ext']

            # Calculate image data hash
            image_hash = hashlib.md5(image_bytes).hexdigest()

            if image_hash not in processed_hashes:
                # Not a duplicate, process and save the image
                image_name = f"image_{i}.{image_ext}"
                image_path = os.path.join(images_path, image_name)
                with open(image_path, 'wb') as image_file:
                    image_file.write(image_bytes)
                processed_hashes.add(image_hash)
                saved_images.append(image_path)  # Add to list of saved images

        return saved_images

    @staticmethod
    def extract_text_and_images_from_pdf(pdf_path):
        pdf_document = pymupdf.open(pdf_path)
        os.makedirs(output_folder, exist_ok=True)
        extracted_content = ""
        all_image_descriptions = ""

        def process_page(page):
            text = page.get_text()
            print("Page text:", text)
            return text

        for page in pdf_document:
            extracted_content += process_page(page)

        unique_images = DataIndex.extract_images_unique(pdf_document, output_folder)
        for img_path in unique_images:
            image_description = DataIndex.get_data_fromgemini(img_path)
            all_image_descriptions += " " + image_description

        extracted_content += " " + all_image_descriptions
        extracted_content = re.sub(r'[^A-Za-z0-9\s]', '', extracted_content)
        extracted_content = re.sub(r'\s+', ' ', extracted_content)
        extracted_content = extracted_content.strip()

        with open("extracted_text.txt", "w", encoding="utf-8") as text_file:
            text_file.write(extracted_content)
        return extracted_content

    @staticmethod
    def process_pdf(pdfPath, filename, file_present):
        text = DataIndex.extract_text_and_images_from_pdf(pdfPath)
        text_chunks = DataIndex._DataIndex__get_text_chunks(text)
        DataIndex._DataIndex__get_vectorstore(text_chunks, filename, file_present)
        try:
            os.remove('vector_id.txt')
        except FileNotFoundError:
            print("file not exist")
        print("Vector store created")
        merged_output = LangModel.key_extraction()
        
        # Save the merged output to an Excel file
        basename = os.path.splitext(filename)[0]
        excel_file_path = basename + ".xlsx"
        #DataIndex.save_to_excel(merged_output, excel_file_path)
        #print(f"Excel file saved to {excel_file_path}")
        DataIndex.export_to_excel(merged_output,excel_file_path)
        
        # Upload the Excel file to Azure Blob Storage
        DataIndex.upload_to_blob(excel_file_path)
        # Create a client
        client = SearchIndexClient(vector_store_address, AzureKeyCredential(vector_store_password))

        # Delete the index
        client.delete_index(index_name)
        print(f"Index '{index_name}' deleted successfully.")
        return merged_output
    

    # Function to export results to Excel
    @staticmethod
    def export_to_excel(final_output,excel_file_path):
        # Convert lists to DataFrames
        important_dates_df = pd.DataFrame(final_output["Important_Dates"], columns=["Important_Dates"])
        
        # Convert categorized requirements to DataFrame without repeating category names
        functional_requirements = []
        for category, requirements in final_output["Functional_Requirements"].items():
            functional_requirements.append({"Category": category, "Requirement": requirements[0]})
            for requirement in requirements[1:]:
                functional_requirements.append({"Category": "", "Requirement": requirement})
        functional_requirements_df = pd.DataFrame(functional_requirements)
        
        nonfunctional_requirements = []
        for category, requirements in final_output["NonFunctional_Requirements"].items():
            nonfunctional_requirements.append({"Category": category, "Requirement": requirements[0]})
            for requirement in requirements[1:]:
                nonfunctional_requirements.append({"Category": "", "Requirement": requirement})
        nonfunctional_requirements_df = pd.DataFrame(nonfunctional_requirements)
        
        current_challenges_df = pd.DataFrame(final_output["Current_Challenges"], columns=["Current_Challenges"])
        key_expectations_df = pd.DataFrame(final_output["Key_Expectations"], columns=["Key_Expectations"])

        # Create a Pandas Excel writer using Openpyxl as the engine
        with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
            # Write each DataFrame to a different sheet
            important_dates_df.to_excel(writer, sheet_name='Important_Dates', index=False)
            functional_requirements_df.to_excel(writer, sheet_name='Functional_Requirements', index=False)
            nonfunctional_requirements_df.to_excel(writer, sheet_name='NonFunctional_Requirements', index=False)
            current_challenges_df.to_excel(writer, sheet_name='Current_Challenges', index=False)
            key_expectations_df.to_excel(writer, sheet_name='Key_Expectations', index=False)


    @staticmethod
    def upload_to_blob(file_path):
        connect_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container_name = os.getenv("container_name")
        
        blob_service_client = BlobServiceClient.from_connection_string(connect_str)
        blob_client = blob_service_client.get_blob_client(container=container_name, blob="rfp-assistant-api/Rfp_Files/" + os.path.basename(file_path))
        
        with open(file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
            print(f"{file_path} uploaded to Azure Blob Storage in container '{container_name}'.")

    @staticmethod
    def __get_text_chunks(text, doc=False):
        text_splitter = TokenTextSplitter(chunk_size=500, chunk_overlap=100)
        if not doc:
            chunks = text_splitter.split_text(text)
        else:
            chunks = text_splitter.split_documents(text)
        print("length of chunk")
        return chunks

    @staticmethod
    def __get_vectorstore(data, filename, file_present, is_text_chunked=True):
        embeddings = current_app.embeddingsModel
        index_name = "rfp-vector-indexes"
        vector_store = AzureSearch(
            azure_search_endpoint=vector_store_address,
            azure_search_key=vector_store_password,
            index_name=index_name,
            embedding_function=embeddings.embed_query,
        )

        credential = AzureKeyCredential(vector_store_password)
        search_client = SearchClient(vector_store_address, index_name, credential)
        
        if file_present == "True":
            with open("vector_id.txt", "r") as file:
                content = file.readlines()
            for id in content:
                id = id.replace("\n", "")
                search_client.delete_documents(documents=[{"id": id}])
            print("Deleted existing vector")
        else:
            print("Vectors of this file don't exist")

        try:
            if is_text_chunked:
                vec = vector_store.add_texts(data)
                with open('vector_id.txt', 'w') as f:
                    for i in vec:
                        f.write("%s\n" % i)
                print("Text is added in vector store")
            else:
                vector_list = []
                for ls in data:
                    vec = vector_store.add_documents(ls)
                    vector_list.append(vec)
                    print("Added data", len(ls))
                    time.sleep(4)
                with open('vector_id.txt', 'w') as f:
                    for ls in vector_list:
                        for vectors in ls:
                            f.write("%s\n" % vectors)
                print("Document is added in vector store")
        except Exception as e:
            print(e)
        print("-------Vector store Created----")
        return