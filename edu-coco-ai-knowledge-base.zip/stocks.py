import pymssql
import json
from flask import jsonify
import os
from dotenv import load_dotenv
load_dotenv()

# Define the connection details
server=os.getenv("server")
database=os.getenv("database")
username=os.getenv("db_username")
password=os.getenv("password")
# Establish the connection
class Stocks():
    def process_stock():
        conn = pymssql.connect(server=server, user=username, password=password, database=database)
        cursor = conn.cursor()

        # Define your SQL statement
        sql_statement = "SELECT Top(5) id,product_description FROM dbo.stocks where stock<=5"

        # Execute the SQL statement
        cursor.execute(sql_statement)

        # Fetch the results
        # rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        json_response = json.dumps(rows, default=str) 
        # conn.commit()

        # Close the connection
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'message': json_response})
    
    def get_product(product_id):
        conn = pymssql.connect(server=server, user=username, password=password, database=database)
        cursor = conn.cursor()
        
        if(str(type(product_id))=="<class 'int'>"):

            # Execute the SQL statement
            cursor.execute('SELECT id,product_description,previous_purchase_date,price,supplier_name FROM dbo.product_details WHERE id = %s', [product_id])


            # Fetch the results
            # rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            json_response = json.dumps(rows, default=str) 
            # conn.commit()

            # Close the connection
            cursor.close()
            conn.close()
            return jsonify({'success': True, 'message': json_response})
        else:
            return jsonify({'success': False, 'message': "pass the integer value"})
        
    # def compare_suppliers(id):
    #     conn = pymssql.connect(server=server, user=username, password=password, database=database)
    #     cursor = conn.cursor()
    #     ls=[]
    #     for i in id:
    #         if(isinstance(i,int)):
    #             cursor.execute('SELECT id,product_description,previous_purchase_date,price,supplier_name FROM dbo.product_details WHERE id = %s', [i])
    #             columns = [desc[0] for desc in cursor.description]
    #             rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
    #             rows[0]["URL"]="https://steducocodev.blob.core.windows.net/output/Invoice?sp=r&st=2024-06-20T07:45:48Z&se=2024-06-20T15:45:48Z&spr=https&sv=2022-11-02&sr=b&sig=NQkOmKKcfp7dz%2B%2B2bi334YEA8z1%2FgyKtzNxcQXwYtC0%3D"
    #             ls.append(rows)
    #             json_response = json.dumps(ls, default=str) 
    #         else:
    #             continue
    #     print("json_response === ",json_response)
    #     cursor.close()
    #     conn.close()
    #     return jsonify({'success': True, 'message': json_response})