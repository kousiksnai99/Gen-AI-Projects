import json
import random
import chainlit as cl
from datetime import datetime, timedelta

# Function Definitions
check_order_status_def = {
    "name": "check_order_status",
    "description": "Check the status of a customer's order",
    "parameters": {
      "type": "object",
      "properties": {
        "customer_id": {
          "type": "string",
          "description": "The unique identifier for the customer"
        },
        "order_id": {
          "type": "string",
          "description": "The unique identifier for the order"
        }
      },
      "required": ["customer_id", "order_id"]
    }
}

process_return_def = {
    "name": "process_return",
    "description": "Initiate a return process for a customer's order",
    "parameters": {
      "type": "object",
      "properties": {
        "customer_id": {
          "type": "string",
          "description": "The unique identifier for the customer"
        },
        "order_id": {
          "type": "string",
          "description": "The unique identifier for the order to be returned"
        },
        "reason": {
          "type": "string",
          "description": "The reason for the return"
        }
      },
      "required": ["customer_id", "order_id", "reason"]
    }
}

get_product_info_def = {
    "name": "get_product_info",
    "description": "Retrieve information about a specific product",
    "parameters": {
      "type": "object",
      "properties": {
        "customer_id": {
          "type": "string",
          "description": "The unique identifier for the customer"
        },
        "product_id": {
          "type": "string",
          "description": "The unique identifier for the product"
        }
      },
      "required": ["customer_id", "product_id"]
    }
}

update_account_info_def = {
    "name": "update_account_info",
    "description": "Update a customer's account information",
    "parameters": {
      "type": "object",
      "properties": {
        "customer_id": {
          "type": "string",
          "description": "The unique identifier for the customer"
        },
        "field": {
          "type": "string",
          "description": "The account field to be updated (e.g., 'email', 'phone', 'address')"
        },
        "value": {
          "type": "string",
          "description": "The new value for the specified field"
        }
      },
      "required": ["customer_id", "field", "value"]
    }
}


  
cancel_order_def = {  
    "name": "cancel_order",  
    "description": "Cancel a customer's order before it is processed",  
    "parameters": {  
        "type": "object",  
        "properties": {  
            "customer_id": {
                "type": "string",
                "description": "The unique identifier for the customer"
            },
            "order_id": {  
                "type": "string",  
                "description": "The unique identifier of the order to be cancelled"  
            },  
            "reason": {  
                "type": "string",  
                "description": "The reason for cancelling the order"  
            }  
        },  
        "required": ["customer_id", "order_id", "reason"]  
    }  
}  

schedule_callback_def = {  
    "name": "schedule_callback",  
    "description": "Schedule a callback with a customer service representative",  
    "parameters": {  
        "type": "object",  
        "properties": {  
            "customer_id": {
                "type": "string",
                "description": "The unique identifier for the customer"
            },
            "callback_time": {  
                "type": "string",  
                "description": "Preferred time for the callback in ISO 8601 format"  
            }  
        },  
        "required": ["customer_id", "callback_time"]  
    }  
}  

get_customer_info_def = {  
    "name": "get_customer_info",  
    "description": "Retrieve information about a specific customer",  
    "parameters": {  
        "type": "object",  
        "properties": {  
            "customer_id": {  
                "type": "string",  
                "description": "The unique identifier for the customer"  
            }  
        },  
        "required": ["customer_id"]  
    }  
}  

# Define a new function to retrieve course information based on course ID
get_course_info_def = {
    "name": "get_course_info",
    "description": "Retrieve information about a specific course",
    "parameters": {
        "type": "object",
        "properties": {
            "customer_id": {
                "type": "string",
                "description": "The unique identifier for the student"
            },
            "course_id": {
                "type": "string",
                "description": "The unique identifier for the course"
            }
        },
        "required": ["customer_id", "course_id"]
    }
}

# New Template Definitions
course_cancellation_def = {
    "name": "course_cancellation",
    "description": "Cancel a course enrollment for a student",
    "parameters": {
        "type": "object",
        "properties": {
            "customer_id": {"type": "string", "description": "The unique identifier for the student"},
            "course_name": {"type": "string", "description": "The name of the course to be cancelled"}
        },
        "required": ["customer_id", "course_name"]
    }
}

course_purchase_def = {
    "name": "course_purchase",
    "description": "Confirm a student's course purchase",
    "parameters": {
        "type": "object",
        "properties": {
            "customer_id": {"type": "string", "description": "The unique identifier for the student"},
            "course_name": {"type": "string", "description": "The name of the course purchased"},
            "purchase_date": {"type": "string", "description": "The date of the course purchase in ISO 8601 format"}
        },
        "required": ["customer_id", "course_name", "purchase_date"]
    }
}

fees_paid_courses_def = {
    "name": "fees_paid_courses",
    "description": "Confirm a student's fee payment for one or more courses",
    "parameters": {
        "type": "object",
        "properties": {
            "customer_id": {"type": "string", "description": "The unique identifier for the student"},
            "course_names": {"type": "string", "description": "The names of the courses for which fees were paid"},
            "payment_date": {"type": "string", "description": "The date of the payment in ISO 8601 format"},
            "total_amount": {"type": "number", "description": "The total amount paid for the courses"}
        },
        "required": ["customer_id", "course_names", "payment_date", "total_amount"]
    }
}  

async def cancel_order_handler(customer_id, order_id, reason):  
    status = "Cancelled"
    
    # Generate random cancellation details
    cancellation_date = datetime.now()
    refund_amount = round(random.uniform(10, 500), 2)
    
    # Read the HTML template
    with open('order_cancellation_template.html', 'r') as file:
        html_content = file.read()
    
    # Replace placeholders with actual data
    html_content = html_content.format(
        order_id=order_id,
        customer_id=customer_id,
        cancellation_date=cancellation_date.strftime("%B %d, %Y"),
        refund_amount=refund_amount,
        status=status
    )
    
    # Return the Chainlit message with HTML content
    await cl.Message(content=f"Your order has been cancelled. Here are the details:\n{html_content}").send()
    return f"Order {order_id} for customer {customer_id} has been cancelled. Reason: {reason}. A confirmation email has been sent."  
  
async def schedule_callback_handler(customer_id, callback_time):  
        # Read the HTML template
    with open('callback_schedule_template.html', 'r') as file:
        html_content = file.read()

    # Replace placeholders with actual data
    html_content = html_content.format(
        customer_id=customer_id,
        callback_time=callback_time
    )

    # Return the Chainlit message with HTML content
    await cl.Message(content=f"Your callback has been scheduled. Here are the details:\n{html_content}").send()
    return f"Callback scheduled for customer {customer_id} at {callback_time}. A representative will contact you then."
  
async def check_order_status_handler(customer_id, order_id):
    status = "In Transit"
    
    # Generate random order details
    order_date = datetime.now() - timedelta(days=random.randint(1, 10))
    estimated_delivery = order_date + timedelta(days=random.randint(3, 7))
    # Read the HTML template
    with open('order_status_template.html', 'r') as file:
        html_content = file.read()

    # Replace placeholders with actual data
    html_content = html_content.format(
        order_id=order_id,
        customer_id=customer_id,
        order_date=order_date.strftime("%B %d, %Y"),
        estimated_delivery=estimated_delivery.strftime("%B %d, %Y"),
        status=status
    )

    # Return the Chainlit message with HTML content
    await cl.Message(content=f"Here is the detail of your order \n {html_content}").send()
    return f"Order {order_id} status for customer {customer_id}: {status}"
    

async def process_return_handler(customer_id, order_id, reason):
    return f"Return for order {order_id} initiated by customer {customer_id}. Reason: {reason}. Please expect a refund within 5-7 business days."

async def get_product_info_handler(customer_id, product_id):
    products = {
        "B001": {"title": "The Great Gatsby", "author": "F. Scott Fitzgerald", "price": 10.99, "stock": 120},
        "B002": {"title": "To Kill a Mockingbird", "author": "Harper Lee", "price": 7.99, "stock": 200},
        "B003": {"title": "1984", "author": "George Orwell", "price": 8.99, "stock": 150},
        "B004": {"title": "Pride and Prejudice", "author": "Jane Austen", "price": 6.99, "stock": 180},
        "B005": {"title": "The Catcher in the Rye", "author": "J.D. Salinger", "price": 9.99, "stock": 75},
        "B006": {"title": "Moby-Dick", "author": "Herman Melville", "price": 11.99, "stock": 90}
    }
    
    product_info = products.get(product_id, "Product not found")
    return f"Product information for customer {customer_id}: {json.dumps(product_info)}"

# Handler for get_course_info
async def get_course_info_handler(customer_id, course_id):
    courses = {
        "C001": {"name": "Python Programming", "instructor": "Alice Smith", "price": 99.99, "duration": "8 weeks"},
        "C002": {"name": "Data Science Fundamentals", "instructor": "Bob Johnson", "price": 149.99, "duration": "12 weeks"},
        "C003": {"name": "Machine Learning Basics", "instructor": "Carol Lee", "price": 199.99, "duration": "10 weeks"},
        "C004": {"name": "Web Development Bootcamp", "instructor": "David Kim", "price": 129.99, "duration": "6 weeks"},
        "C005": {"name": "AI for Everyone", "instructor": "Eve Brown", "price": 79.99, "duration": "4 weeks"}
    }
    
    course_info = courses.get(course_id, "Course not found")
    return f"Course information for student {customer_id}: {json.dumps(course_info)}"

async def update_account_info_handler(customer_id, field, value):
    return f"Account information updated for customer {customer_id}. {field.capitalize()} changed to: {value}"

async def get_customer_info_handler(customer_id):  
    # Simulated customer data (using placeholder information)  
    customers = {  
        "C001": {"membership_level": "Gold", "account_status": "Active"},  
        "C002": {"membership_level": "Silver", "account_status": "Pending"},  
        "C003": {"membership_level": "Bronze", "account_status": "Inactive"},  
    }  
    customer_info = customers.get(customer_id)  
    if customer_info:  
        # Return customer information in JSON format  
        return json.dumps({  
            "customer_id": customer_id,  
            "membership_level": customer_info["membership_level"],  
            "account_status": customer_info["account_status"]  
        })  
    else:  
        return f"Customer with ID {customer_id} not found."  

async def course_cancellation_handler(**json_arguments):
    html_content = """
    <html>
        <body style="font-family: {font_family};">
            <h1>Cancellation Confirmed</h1>
            <p>Your course {course_name} has been canceled.</p>
        </body>
    </html>
    """
    html_content = html_content.format(
        font_family="Arial",  # Default font
        course_name=json_arguments.get("course_name", "Unknown Course")
    )
    return html_content

    
    # Replace placeholders with actual data
    html_content = html_content.format(
        course_name=course_name,
        customer_id=customer_id,
        cancellation_date=cancellation_date.strftime("%B %d, %Y"),
        refund_amount=refund_amount,
        status=status
    )
    
    # Return HTML message
    await cl.Message(content=f"Your course cancellation details:\n{html_content}").send()
    return f"Course {course_name} for customer {customer_id} has been cancelled."

async def course_purchase_handler(customer_id, course_name, purchase_date):
    # Load HTML template
    with open('course_purchased_template.html', 'r') as file:
        html_content = file.read()
    
    # Format HTML content with course details
    html_content = html_content.format(
        course_name=course_name,
        customer_id=customer_id,
        purchase_date=purchase_date
    )
    
    # Send confirmation message with formatted HTML
    await cl.Message(content=f"Course purchase confirmation:\n{html_content}").send()
    
    # Return confirmation message
    return f"Purchase confirmed for course {course_name} for student {customer_id}."

async def fees_paid_courses_handler(customer_id, course_names, payment_date, total_amount):
    # Read the template file
    with open('fees_paid_courses_template.html', 'r') as file:
        html_content = file.read()
    
    # Format the HTML with actual values
    html_content = html_content.format(
        customer_id=customer_id,
        course_names=", ".join(course_names),  # Ensure course names are comma-separated
        payment_date=payment_date,
        total_amount=total_amount
    )
    
    # Send the HTML content
    await cl.Message(content=f"Fees payment confirmation:\n{html_content}").send()
    return f"Fees of ${total_amount} paid by student {customer_id} for courses: {', '.join(course_names)}."



# Update the tools list with new handlers and definitions
tools = [
    (get_customer_info_def, get_customer_info_handler),
    (check_order_status_def, check_order_status_handler),
    (process_return_def, process_return_handler),
    (get_product_info_def, get_product_info_handler),
    (update_account_info_def, update_account_info_handler),
    (cancel_order_def, cancel_order_handler),
    (schedule_callback_def, schedule_callback_handler),
    # New tools for course templates
    (course_cancellation_def, course_cancellation_handler),
    (course_purchase_def, course_purchase_handler),
    (fees_paid_courses_def, fees_paid_courses_handler),
    (get_course_info_def, get_course_info_handler)
    # Add the new tool to the tools list

]