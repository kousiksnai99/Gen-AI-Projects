import os
from dotenv import load_dotenv
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
import json
from langchain_text_splitters import TokenTextSplitter
from langchain.output_parsers import PydanticOutputParser
from langchain.pydantic_v1 import BaseModel, Field, validator
from langchain_core.prompts import PromptTemplate
from langchain_openai import AzureOpenAI
from langchain.chains import LLMChain
from langchain.callbacks import get_openai_callback
from langchain.chains import RetrievalQA
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores.azuresearch import AzureSearch
from langchain.chat_models import AzureChatOpenAI
import re
import concurrent.futures
import pandas as pd
from langchain_community.vectorstores import AzureSearch
from langchain_community.chat_models import AzureChatOpenAI
from langchain_openai import AzureChatOpenAI
# from langchain.chat_models import AzureChatOpenAI


load_dotenv()

# Define your data model
class InitialRequirements(BaseModel):
    Important_Dates: list[str] = Field(description="List all the important dates identified in the document, along with the reason why they are considered significant (in YYYY-MM-DD format).")
    Functional_Requirements: list[str] = Field(description="Describe the functional requirements of the project, detailing what the system should do")
    NonFunctional_Requirements: list[str] = Field(description="Describe the non-functional requirements of the project, specifying performance, usability, reliability, etc.")
    Current_Challenges: list[str] = Field(description="List and describe the current challenges or issues faced in the project.")
    Key_Expectations: list[str] = Field(description="Outline the key expectations and goals for the project.")

# Define additional models for categorization
class CategorizedRequirements(BaseModel):
    Functional_Requirements: dict[str, list[str]] = Field(description="Functional requirements categorized into subcategories.")
    NonFunctional_Requirements: dict[str, list[str]] = Field(description="Non-functional requirements categorized into subcategories.")

# Configuration for Azure OpenAI
azure_endpoint = os.getenv("api_base")
openai_api_version = os.getenv("OPENAI_API_VERSION")
openai_api_key = os.getenv("OPENAI_API_KEY")

# Configuration for Azure Search
search_service_endpoint = os.getenv("vector_store_address")
index_name = "rfp-vector-indexes"
search_api_key = os.getenv("vector_store_password")

llm = AzureChatOpenAI(
    azure_endpoint="https://rfp-openai-service.openai.azure.com/",
    openai_api_version="2024-02-15-preview",
    openai_api_key="e4f02201204c42a6beeb67e3e30e2831",
    openai_api_type="azure",
    deployment_name="gpt-4", 
    model_name="gpt-4",
    temperature=0,
    max_retries=1,
    max_tokens=1000,
)

# Set up the output parser and prompt templates
combined_output_parser = PydanticOutputParser(pydantic_object=InitialRequirements)
combined_prompt_template = PromptTemplate.from_template(
    "You are a highly skilled expert in text analysis specializing in extracting key information from complex documents. "
    "Your task is to read the following article carefully and provide detailed and accurate information based strictly on the content provided. "
    "Do not infer or assume any information not explicitly stated in the article.\n\n"
    "Article:\n<{chunks}>\n\n"
    "Based on the article, provide the Important dates with their specific relevance and following information in the specified format:\n\n"
    "{format_instructions}",    
    partial_variables={
        "format_instructions": combined_output_parser.get_format_instructions()
    },
)

categorize_prompt_template = PromptTemplate.from_template(
    "Based on the extracted requirements, categorize the following list into appropriate subcategories:\n\n"
    "{requirements}\n\n"
    "Return the categorized requirements in a dictionary format with subcategories as keys and lists of related requirements as values."
)

# Create the LLM chains
combined_chain = LLMChain(llm=llm, prompt=combined_prompt_template)
categorize_chain = LLMChain(llm=llm, prompt=categorize_prompt_template)

class LangModel:
    # Function to get all chunks from Azure Search Index
    @staticmethod
    def get_all_chunks_from_azure_search(query):
        search_client = SearchClient(endpoint=search_service_endpoint,
                                     index_name=index_name,
                                     credential=AzureKeyCredential(search_api_key))
        results = search_client.search(query)
        chunks = []
        for result in results:
            chunks.append(result['content'])  # Adjust this based on your actual field name
        return chunks
    
    @staticmethod
    def key_extraction():
        # Get all chunks from Azure Search
        query = ""
        chunks = LangModel.get_all_chunks_from_azure_search(query)
        if not chunks:
            raise ValueError("No articles found for the given query.")
        # Combine the chunks
        combined_text = "\n".join(chunks)

        # Brute force: split the combined text into smaller chunks
        text_splitter = TokenTextSplitter(
            chunk_size=8192,  # Controls the size of each chunk
            chunk_overlap=30  # Controls overlap between chunks
        )
        chunked_texts = text_splitter.split_text(combined_text)

        # Limit to the first n chunks for quicker re-runs
        first_few_chunks = chunked_texts[:]

        # Process chunks concurrently
        all_results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            future_to_chunk = {executor.submit(LangModel.process_chunk, chunk): chunk for chunk in first_few_chunks}
            for future in concurrent.futures.as_completed(future_to_chunk):
                chunk = future_to_chunk[future]
                try:
                    result = future.result()
                    all_results.append(result)
                except Exception as exc:
                    print(f'Chunk generated an exception: {exc}')

        # Merge all results
        merged_output = LangModel.merge_results(all_results)

        # Categorize the requirements
        categorized_requirements = LangModel.categorize_requirements(merged_output)

        # Structure the final JSON response
        final_output = {
            "Important_Dates": merged_output['Important_Dates'],
            "Functional_Requirements": categorized_requirements['Functional_Requirements'],
            "NonFunctional_Requirements": categorized_requirements['NonFunctional_Requirements'],
            "Current_Challenges": merged_output['Current_Challenges'],
            "Key_Expectations": merged_output['Key_Expectations']
        }

        # Print the categorized output
        print(json.dumps(final_output, indent=4, default=str))
        
        return final_output
    
    # Function to process each chunk
    @staticmethod
    def process_chunk(chunk):
        with get_openai_callback() as cb:
            token_costs = {}
            combined_results = combined_chain.run({"chunks": chunk})
            token_costs['total_tokens'] = cb.total_tokens
            token_costs['prompt_tokens'] = cb.prompt_tokens
            token_costs['completion_tokens'] = cb.completion_tokens
            token_costs['Total Cost'] = cb.total_cost
            print(token_costs)

        # Parse and collect the results
        parsed_combined_results = combined_output_parser.parse(combined_results)
        return parsed_combined_results

    # Function to merge results
    @staticmethod
    def merge_results(results):
        merged_result = {
            'Important_Dates': [],
            'Functional_Requirements': [],
            'NonFunctional_Requirements': [],
            'Current_Challenges': [],
            'Key_Expectations': [],
        }
        for result in results:
            merged_result['Important_Dates'].extend(result.Important_Dates)
            merged_result['Functional_Requirements'].extend(result.Functional_Requirements)
            merged_result['NonFunctional_Requirements'].extend(result.NonFunctional_Requirements)
            merged_result['Current_Challenges'].extend(result.Current_Challenges)
            merged_result['Key_Expectations'].extend(result.Key_Expectations)
            
        return merged_result

    # Function to categorize requirements
    @staticmethod
    def categorize_requirements(merged_output):
        categorized_requirements = {
            'Functional_Requirements': {},
            'NonFunctional_Requirements': {},
        }

        functional_requirements_text = "\n".join(merged_output['Functional_Requirements'])
        nonfunctional_requirements_text = "\n".join(merged_output['NonFunctional_Requirements'])

        functional_categorized = categorize_chain.run({"requirements": functional_requirements_text})
        nonfunctional_categorized = categorize_chain.run({"requirements": nonfunctional_requirements_text})

        # Add error handling to ensure valid JSON is returned
        try:
            categorized_requirements['Functional_Requirements'] = json.loads(functional_categorized.strip('```json\n').strip('```'))
        except json.JSONDecodeError as e:
            print(f"Error parsing Functional_Requirements JSON: {e}")
            print("Functional_Requirements raw output:", functional_categorized)
            categorized_requirements['Functional_Requirements'] = {functional_categorized}

        try:
            categorized_requirements['NonFunctional_Requirements'] = json.loads(nonfunctional_categorized.strip('```json\n').strip('```'))
        except json.JSONDecodeError as e:
            print(f"Error parsing NonFunctional_Requirements JSON: {e}")
            print("NonFunctional_Requirements raw output:", nonfunctional_categorized)
            categorized_requirements['NonFunctional_Requirements'] = {nonfunctional_categorized}
        
        return categorized_requirements