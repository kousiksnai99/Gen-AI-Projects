# ServiceNow Agent — local test guide

**Project** Agentic AI SD · **Business Owner** ITOA · **Tech Owner** Kousik Snai, ITOA Project AI Team

How to run the ServiceNow agent on a dev server and test all 5 actions against the real
Teva ServiceNow ticketing API.

---

## 1. What is in this folder

| File | What it is | Ships to the repo? |
|---|---|---|
| `main.py` | **The deliverable.** The ServiceNow agent — all 5 actions and the real API calls. | **Yes** → `app/agents/servicenow/main.py` |
| `local_server.py` | Test harness. Exposes the 5 actions as one HTTP endpoint so Postman can call them. | **No** — local only |
| `config.py` | Reference copy of the orchestrator's `app/core/config.py`. `local_server.py` loads the real one from here. | No — already in the repo |
| `deps.py` | Reference copy of the orchestrator's `deps.py`, showing how the agent is constructed. Not executable on its own. | No — already in the repo |
| `.env` | The two secrets. **Never commit this.** | No |
| `.env.example` | The full list of settings, with the non-secret values filled in. | Yes → repo root |
| `requirements.txt` | The orchestrator's runtime dependencies. | Yes → repo root |

`main.py` is an **in-process class**, not a web service. In production
`app/domain/flow.py` calls its methods directly and `deps.py` builds it per request —
there is no HTTP endpoint. `local_server.py` exists only to put one in front of it for
testing.

---

## 2. Prerequisites

- **Python 3.10 or newer.** Verified on 3.13.2.
- Outbound access to `login.microsoftonline.com` and `apidev.tevapharm.com`.

```bash
python --version
```

---

## 3. Create and activate a virtual environment

Run from inside this folder.

**Windows — PowerShell**

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

If PowerShell blocks the script (`running scripts is disabled on this system`):

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

**Windows — cmd.exe**

```bat
python -m venv .venv
.venv\Scripts\activate.bat
```

**Linux / macOS dev server**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

You know it worked when the prompt is prefixed `(.venv)`. To leave it later: `deactivate`.

---

## 4. Install dependencies

```bash
pip install requests python-dotenv truststore
```

That is everything `main.py` and `local_server.py` need — three packages. No FastAPI and
no uvicorn: `local_server.py` uses the standard library.

**`truststore` is only needed behind a TLS-inspecting corporate proxy** (which the Teva
network is). Without it every call to `apidev.tevapharm.com` fails with
`CERTIFICATE_VERIFY_FAILED`. It is harmless everywhere else. On a Linux dev server with no
interception you can skip it.

Do **not** `pip install -r requirements.txt` here — that is the orchestrator's full
runtime list (fastapi, gunicorn, mssql-python, azure-*) and none of it is needed to test
this agent.

---

## 5. Configure the secrets

Everything `main.py` needs already has a working dev default in the code **except two
values**, which have no default on purpose: a client secret written into a source file is
rejected by Azure DevOps push protection (SEC101/205).

Create a file named `.env` in this folder:

```
SN_CLIENT_SECRET=1c98Q~KxkROmy8Uyw8gSixhI6Dv7tdhnAzIO1a2n
SN_API_KEY=531b46e7-b089-4225-a998-325accf964e1
USE_OS_CERT_STORE=true
```

- `SN_CLIENT_SECRET` — the client secret of app registration
  `e91e93ca-955f-47d5-a491-a41985414c57`. Entra ID → App registrations → that app →
  Certificates & secrets. **Rotate it** — it has been in source control.
- `SN_API_KEY` — the gateway's `x-Gateway-APIKey`. Optional; the Bearer token alone is
  sufficient (verified). Leave it empty and the header is simply not sent.
- **Never commit `.env`.** On App Service these go in Application Settings instead, where
  they arrive as ordinary environment variables — `config.py` reads both the same way.

`.env.example` lists every other setting with its current value, if you need to override
one per environment.

---

## 6. Run

```bash
python local_server.py
```

```
listening on http://127.0.0.1:8000   (Ctrl+C to stop)
```

Open `http://127.0.0.1:8000/` in a browser to see the 5 payloads printed as plain text.

Each call is logged in the console with the arguments it passed and what came back, so you
can watch exactly what `main.py` does per request.

> **On a shared dev server:** `local_server.py` binds to `127.0.0.1`, so it is reachable
> only from that machine. To reach it from your laptop, change the last line to
> `HTTPServer(("0.0.0.0", PORT), Handler)` — and only on an internal dev box, since the
> endpoint has no authentication.

---

## 7. Postman — the 5 payloads

One endpoint for all of them:

```
POST http://127.0.0.1:8000/test
Content-Type: application/json
```

Run them in this order — steps 3–5 act on the same ticket.

### 1. create_interaction

```json
{
  "action": "create_interaction",
  "conversation_id": "local-test-001",
  "user_id": "kousik.snai@cognizant.com"
}
```

```json
{ "ok": true, "action": "create_interaction", "result": "" }
```

**`""` is the correct answer, not a failure.** The gateway exposes no `interaction` table
(it answers 404), so this degrades quietly by design — an interaction we cannot create must
not cost anyone a conversation. Incidents simply carry no interaction link, which the flow
already handles. If the client ever issues a resourcePath for `interaction`, put it in
`SN_INTERACTION_PATH` and this starts doing real work with no code change.

### 2. close_interaction

```json
{
  "action": "close_interaction",
  "conversation_id": "local-test-001",
  "interaction_id": "IMS0001234"
}
```

```json
{ "ok": true, "action": "close_interaction", "result": null }
```

`null` is correct — the method returns nothing. Best-effort, same reason as above.

### 3. create_incident — creates a REAL ticket

```json
{
  "action": "create_incident",
  "conversation_id": "local-test-001",
  "interaction_id": "",
  "issue_type": "outlook_it",
  "details": "Outlook will not start after the latest Windows update."
}
```

```json
{
  "ok": true,
  "action": "create_incident",
  "result": {
    "incident_id": "INC0012345",
    "issue_type": "outlook_it",
    "state": "1",
    "message": "Thanks, I've raised ticket INC0012345 for this. The service desk will take it from here."
  }
}
```

**Copy `incident_id` into steps 4 and 5.** The ticket is real and cannot be deleted from
the client's instance afterwards — only resolved, which step 5 does. Prefix `details` with
`[TEST]` if you want it obvious in the queue.

`conversation_id` is stamped on the ticket as `u_inbound_key`. It persists **only on
create**, and it is what lets steps 4 and 5 find the same ticket without an id.

### 4. update_incident

```json
{
  "action": "update_incident",
  "conversation_id": "local-test-001",
  "incident_id": "INC0012345",
  "note": "Diagnostics started."
}
```

```json
{ "ok": true, "action": "update_incident", "result": null }
```

Adds a work note. `null` is correct — nothing here is user-facing, so a failure is logged
and the conversation continues. Check the note landed in the ServiceNow UI.

### 5. resolve

```json
{
  "action": "resolve",
  "conversation_id": "local-test-001",
  "interaction_id": "",
  "incident_id": "INC0012345"
}
```

```json
{
  "ok": true,
  "action": "resolve",
  "result": "Glad that's sorted. I've closed ticket INC0012345 for you."
}
```

**Leave `incident_id` out** and it finds the ticket by `conversation_id` instead — that is
the one-incident-per-conversation lookup, and it is worth testing separately:

```json
{ "action": "resolve", "conversation_id": "local-test-001" }
```

**If the reply is instead:**

```
"I've sent the request to close ticket INC0012345, and the service desk will confirm once it's done."
```

then ServiceNow accepted the resolve but a server-side rule reverted the state. **This is a
known open item with the client, not a code fault.** `main.py` re-reads the record after
every resolve — this API echoes the state it *attempted* to set, not what it stored — and
picks the wording from what actually persisted, because telling someone their ticket is
closed when it is still open is the worst outcome available here.

---

## 8. Troubleshooting

| Message | Cause | Fix |
|---|---|---|
| `SN_CLIENT_SECRET is not set` | No `.env`, or it is not in this folder | Create `.env` beside `config.py` (section 5) |
| `CERTIFICATE_VERIFY_FAILED` | Corporate TLS interception; certifi does not trust the proxy CA | `pip install truststore` |
| `AADSTS7000215` | Wrong or expired client secret | New secret in Entra ID |
| `AADSTS700016` | That client id is not in this tenant | Check `SN_CLIENT_ID` / `SN_TENANT_ID` |
| `AADSTS500011` | The scope's API is not exposed in this tenant | Check `SN_SCOPE` |
| HTTP 401 from the gateway | Token issued but refused — usually the scope | Check `SN_SCOPE` |
| HTTP 403 from the gateway | Authenticated but not authorised for this table | Check `SN_RESOURCE_PATH` with the client |
| `No record found with the query ...` | Nothing matches — this gateway raises instead of returning an empty result | Expected when the id or `conversation_id` does not exist |
| `'details' is required to create an incident.` | `details` was empty | `description` is mandatory; there is no ticket to be had |
| Data-policy rejection on create | `u_customer_ci` is wrong | **The value in the code is a placeholder** the business must confirm |
| `Address already in use` | Port 8000 is taken | Change `PORT` at the top of `local_server.py` |
| `ModuleNotFoundError: requests` | The venv is not active, or install went to a different Python | Re-activate (section 3) and re-install (section 4) |

To see whether auth works without creating anything, call any action that only reads —
e.g. `resolve` with a `conversation_id` that has no ticket. A `No record found` back means
the token was issued and the gateway accepted it.

---

## 9. Shipping it

Only **one file** goes into the orchestrator repo:

```
main.py   →   app/agents/servicenow/main.py
```

Nothing else changes. `deps.py` already imports
`from app.agents.servicenow.main import ServiceNowAgent` and builds it with
`ServiceNowAgent(**shared)`, and the class name, the 5 method names and their signatures
are unchanged — which is what makes this a drop-in replacement.

`config.py`, `deps.py` and `requirements.txt` need **no edits**. The `SN_*` settings live
in the agent's own file on purpose: `config.py` says so itself — *"whatever an agent needs
to reach its own backend (a Foundry agent name, a Graph permission, a KB index) is that
agent's configuration and is read in its own folder"*.

Then, in App Service → Configuration → Application Settings, add:

| Setting | Value |
|---|---|
| `SN_CLIENT_SECRET` | the rotated client secret |
| `SN_API_KEY` | the gateway key, or leave unset |

Everything else has a working default in the code. Add `truststore` to the root
`requirements.txt` only if you want the local-development switch available on the server;
Azure itself does not need it.

**Do not deploy `local_server.py`.** It has no authentication and exists only to give
Postman something to call.
