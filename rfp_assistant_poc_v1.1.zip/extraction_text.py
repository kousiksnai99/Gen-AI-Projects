import fitz  
from PIL import Image
import io
import os
import itertools
import google.generativeai as genai
from dotenv import load_dotenv
from pathlib import Path
import re
from index import DataIndex
from werkzeug.utils import secure_filename
from flask import current_app, jsonify
from azure.storage.filedatalake import DataLakeServiceClient
from azure.identity import ManagedIdentityCredential
from azure.storage.blob import BlobServiceClient

load_dotenv() 
from datetime import datetime
today = datetime.today()
month = today.month
year=today.year

os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

ALLOWED_EXTENSIONS = {'pdf'}

vector_store_password = os.getenv("vector_store_password")
vector_store_address = os.getenv("vector_store_address")
account_key = os.getenv("account_key")
container_name = os.getenv("container_name")
account_name = os.getenv("account_name")

File_directory = f"rfp-assistant-api/Rfp_Files/"
service_url = f"https://{account_name}.dfs.core.windows.net"
Id_directory = "File_ids/"
service_client = DataLakeServiceClient(account_url=service_url, credential=account_key)

try:
    file_system_client = service_client.create_file_system(file_system=container_name)
except:
    file_system_client = service_client.get_file_system_client(container_name)

class Extraction:
    @staticmethod
    def __allowed_file(filename):
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

    @staticmethod
    def __process_document_cases(fileExt, file_path_to_save, filename, file_present):
        if fileExt == 'pdf':
            response = DataIndex.process_pdf(file_path_to_save, filename, file_present)
            return response
        else:
            raise AttributeError('Extension is not valid')

    @staticmethod
    def processDocument(file):
        try:
            if file and Extraction.__allowed_file(file.filename):
                filename = secure_filename(file.filename)
                print(filename)
                extension = filename.rsplit('.', 1)[1].lower()
                file_path_to_save = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path_to_save)

                if extension == 'pdf':
                    status = Extraction.file_exist_check(filename, file_path_to_save)
                    status = str(status)
                    if status == "True":
                        file_present = "True"
                    else:
                        file_present = "False"
                    response = Extraction.__process_document_cases(filename.rsplit('.', 1)[1].lower(), file_path_to_save, filename, file_present)              
                    os.remove(file_path_to_save)
                    return jsonify({'success': True, 'message': 'Vectorstore successfully created', 'summary': response})
                else:
                    return jsonify({'success': False, 'message': 'File is not exists'})
            else:
                return jsonify({'success': False, 'message': 'File type not supported'})

        except Exception as e:
            return jsonify({'success': False, 'message': str(e)})

    @staticmethod
    def file_exist_check(filename, file_path_to_save):
        try:
            file_system_client.create_directory(f'{File_directory}')
        except:
            file_system_client.get_directory_client(f'{File_directory}')
        try:
            file_system_client.create_directory(f'{Id_directory}')
        except:
            file_system_client.get_directory_client(f'{Id_directory}')
        
        paths = file_system_client.get_paths("rfp-assistant-api/")
        for path in paths:  
            res = path.name.split('/')[-1]
            filename = filename.replace(" ", "_")
            if filename == res:
                file_client = file_system_client.get_file_client(path.name)
                file_client.delete_file()

        file_client = file_system_client.get_file_client(f"{File_directory}{filename}")
        with open(file_path_to_save, "rb") as local_file:
            file_client.upload_data(local_file, overwrite=True, connection_timeout=300000)
        
        paths = file_system_client.get_paths(f'{Id_directory}')
        for path in paths:  
            name = path.name
            res = name.index('/')
            val = name[res:].split('/')[1]
            val = val.rsplit('.', 1)[0]
        
            if filename == val:
                file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                download = file_client.download_file() 
                with open("./vector_id.txt", "wb") as my_file:
                    my_file.write(download.readall())
                    my_file.close()
                    file_client.delete_file()
                    return "True"
        return "False"