import os
import re
import logging
import psycopg2
from psycopg2.extras import execute_values
from urllib.parse import quote
from azure.storage.filedatalake import DataLakeServiceClient
from langchain.text_splitter import TokenTextSplitter
from langchain_community.document_loaders import UnstructuredWordDocumentLoader
from langchain_community.vectorstores.pgvector import PGVector
import pymupdf
from langchain.embeddings import OpenAIEmbeddings
from app.config.settings import (
    AZURE_STORAGE_CONFIG, OPENAI_CONFIG, PGVECTOR_CONFIG, File_directory, Id_directory, ALLOWED_EXTENSIONS
)

# Initialize embeddings
embeddingsModel = OpenAIEmbeddings(
    deployment="text-embedding-ada-002",
    model="text-embedding-ada-002",
    chunk_size=1,
    openai_api_key=OPENAI_CONFIG["OPENAI_API_KEY"],
    openai_api_base=OPENAI_CONFIG["OPENAI_API_BASE"],
    openai_api_type="azure"
)

# PostgreSQL connection string for pgvector with escaped credentials
CONNECTION_STRING = (
    f"postgresql://{quote(PGVECTOR_CONFIG['user'])}:{quote(PGVECTOR_CONFIG['password'])}@"
    f"{PGVECTOR_CONFIG['host']}:{PGVECTOR_CONFIG['port']}/{PGVECTOR_CONFIG['database']}?sslmode=require"
)

class KnowledgeBaseDataAccess:
    @staticmethod
    def get_db_connection():
        """Returns a new PostgreSQL connection."""
        try:
            conn = psycopg2.connect(
                host=PGVECTOR_CONFIG["host"],
                port=PGVECTOR_CONFIG["port"],
                database=PGVECTOR_CONFIG["database"],
                user=PGVECTOR_CONFIG["user"],
                password=PGVECTOR_CONFIG["password"],
                sslmode="require"  # Required for Azure PostgreSQL
            )
            return conn
        except Exception as e:
            logging.error(f"Failed to connect to PostgreSQL: {e}")
            raise Exception(f"Database connection error: {e}") from e

    @staticmethod
    def ensure_vector_extension():
        """Ensures the vector extension is enabled in the database."""
        try:
            with KnowledgeBaseDataAccess.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
                conn.commit()
            logging.info("Vector extension enabled or already exists")
        except Exception as e:
            logging.error(f"Failed to create vector extension: {e}")
            raise Exception(f"Failed to create vector extension: {e}") from e

    @staticmethod
    def ensure_vector_ids_table():
        """Creates the vector_ids table if it doesn't exist."""
        create_table_query = """
        CREATE TABLE IF NOT EXISTS vector_ids (
            id SERIAL PRIMARY KEY,
            filename VARCHAR(255) NOT NULL,
            vector_id VARCHAR(255) NOT NULL,
            UNIQUE (filename, vector_id)
        );
        """
        try:
            with KnowledgeBaseDataAccess.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(create_table_query)
                conn.commit()
            logging.info("vector_ids table created or already exists")
        except Exception as e:
            logging.error(f"Error creating vector_ids table: {e}")
            raise Exception(f"Failed to create vector_ids table: {e}") from e

    @staticmethod
    def extract_text_from_pdf(pdf_path):
        pdf_document = pymupdf.open(pdf_path)
        extracted_content = ""

        for page in pdf_document:
            text = page.get_text()
            extracted_content += text + " "

        extracted_content = re.sub(r'[^A-Za-z0-9\s]', '', extracted_content)
        extracted_content = re.sub(r'\s+', ' ', extracted_content).strip()
        pdf_document.close()
        return extracted_content

    @staticmethod
    def extract_text_from_docx(docx_path):
        unDoc = UnstructuredWordDocumentLoader(docx_path)
        docs = unDoc.load()
        text = ""
        for doc in docs:
            text += doc.page_content + " "
        
        text = re.sub(r'[^A-Za-z0-9\s]', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    @staticmethod
    def get_text_chunks(text):
        text_splitter = TokenTextSplitter(chunk_size=500, chunk_overlap=100)
        chunks = text_splitter.split_text(text)
        logging.info(f"Created {len(chunks)} text chunks")
        return chunks

    @staticmethod
    def get_vectorstore(text_chunks, filename, file_present):
        # Ensure vector extension and vector_ids table
        KnowledgeBaseDataAccess.ensure_vector_extension()
        KnowledgeBaseDataAccess.ensure_vector_ids_table()
        
        # Initialize PGVector store
        try:
            vector_store = PGVector(
                connection_string=CONNECTION_STRING,
                embedding_function=embeddingsModel,
                collection_name="knowledge_base_vectors"
            )
        except Exception as e:
            logging.error(f"Failed to initialize PGVector: {e}")
            raise Exception(f"PGVector initialization error: {e}") from e

        # If file exists, delete existing vectors
        if file_present == "True":
            try:
                with KnowledgeBaseDataAccess.get_db_connection() as conn:
                    with conn.cursor() as cursor:
                        cursor.execute("SELECT vector_id FROM vector_ids WHERE filename = %s", (filename,))
                        vector_ids = [row[0] for row in cursor.fetchall()]
                        if vector_ids:
                            # Delete vectors from PGVector table
                            cursor.execute(
                                "DELETE FROM langchain_pg_embedding WHERE cmetadata->>'source' = %s",
                                (filename,)
                            )
                            # Delete vector IDs from vector_ids table
                            cursor.execute("DELETE FROM vector_ids WHERE filename = %s", (filename,))
                        conn.commit()
                logging.info(f"Deleted existing vectors for filename: {filename}")
            except Exception as e:
                logging.error(f"Error deleting existing vectors: {e}")
                raise Exception(f"Vector deletion error: {e}") from e

        # Add texts to vector store
        try:
            metadata = [{"source": filename} for _ in text_chunks]
            vector_ids = vector_store.add_texts(texts=text_chunks, metadatas=metadata)
        except Exception as e:
            logging.error(f"Error adding texts to vector store: {e}")
            raise Exception(f"Vector store insertion error: {e}") from e

        # Store vector IDs in vector_ids table
        try:
            with KnowledgeBaseDataAccess.get_db_connection() as conn:
                with conn.cursor() as cursor:
                    execute_values(
                        cursor,
                        "INSERT INTO vector_ids (filename, vector_id) VALUES %s",
                        [(filename, vid) for vid in vector_ids]
                    )
                conn.commit()
            logging.info(f"Stored {len(vector_ids)} vector IDs for filename: {filename}")
        except Exception as e:
            logging.error(f"Error storing vector IDs: {e}")
            raise Exception(f"Vector ID storage error: {e}") from e

        # Upload vector IDs to Azure Data Lake for consistency
        try:
            service_client = DataLakeServiceClient(
                account_url=f"https://{AZURE_STORAGE_CONFIG['account_name']}.dfs.core.windows.net",
                credential=AZURE_STORAGE_CONFIG['account_key']
            )
            file_system_client = service_client.get_file_system_client(file_system=AZURE_STORAGE_CONFIG['container_name'])

            # Write vector IDs to temporary file
            with open("vector_id.txt", "w") as f:
                for vid in vector_ids:
                    f.write(f"{vid}\n")

            # Upload to Azure Data Lake
            file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
            with open("vector_id.txt", "rb") as local_file:
                file_client.upload_data(local_file, overwrite=True)
            logging.info(f"Uploaded vector IDs to Azure Data Lake for filename: {filename}")
        except Exception as e:
            logging.error(f"Error uploading vector IDs to Azure Data Lake: {e}")
            raise Exception(f"Azure Data Lake upload error: {e}") from e

        try:
            os.remove("vector_id.txt")
        except:
            logging.info("vector_id.txt not found for deletion")

    @staticmethod
    def file_exist_check(filename, file_path_to_save):
        try:
            service_client = DataLakeServiceClient(
                account_url=f"https://{AZURE_STORAGE_CONFIG['account_name']}.dfs.core.windows.net",
                credential=AZURE_STORAGE_CONFIG['account_key']
            )
            file_system_client = service_client.get_file_system_client(file_system=AZURE_STORAGE_CONFIG['container_name'])

            try:
                file_system_client.create_directory(File_directory)
                file_system_client.create_directory(Id_directory)
            except Exception as e:
                logging.info(f"Directories already exist or error: {e}")

            paths = file_system_client.get_paths(path="Uploaded-files/")
            filename = filename.replace(" ", "_")
            for path in paths:
                res = path.name.split('/')[-1]
                if filename == res:
                    file_client = file_system_client.get_file_client(path.name)
                    file_client.delete_file()
                    logging.info(f"Deleted existing file: {path.name}")

            file_client = file_system_client.get_file_client(f"{File_directory}{filename}")
            with open(file_path_to_save, "rb") as local_file:
                file_client.upload_data(local_file, overwrite=True, connection_timeout=300000)
                logging.info(f"Uploaded file: {filename}")

            paths = file_system_client.get_paths(path=Id_directory)
            for path in paths:
                name = path.name.split('/')[-1].rsplit('.', 1)[0]
                if filename == name:
                    file_client = file_system_client.get_file_client(f"{Id_directory}{filename}.txt")
                    download = file_client.download_file()
                    with open("vector_id.txt", "wb") as my_file:
                        my_file.write(download.readall())
                    file_client.delete_file()
                    logging.info(f"Found and processed existing vector ID for: {filename}")
                    return "True"
            return "False"
        except Exception as e:
            logging.error(f"Error in file_exist_check: {e}", exc_info=True)
            raise

    @staticmethod
    def process_pdf(file_path, filename, file_present):
        text = KnowledgeBaseDataAccess.extract_text_from_pdf(file_path)
        text_chunks = KnowledgeBaseDataAccess.get_text_chunks(text)
        KnowledgeBaseDataAccess.get_vectorstore(text_chunks, filename, file_present)
        return "Text extracted and indexed"

    @staticmethod
    def process_docx(file_path, filename, file_present):
        text = KnowledgeBaseDataAccess.extract_text_from_docx(file_path)
        text_chunks = KnowledgeBaseDataAccess.get_text_chunks(text)
        KnowledgeBaseDataAccess.get_vectorstore(text_chunks, filename, file_present)
        return "Text extracted and indexed"