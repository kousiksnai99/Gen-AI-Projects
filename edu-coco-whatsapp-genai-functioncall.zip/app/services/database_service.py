import json
import pymssql
from app.config.settings import DB_CONFIG

def get_db_connection():
    return pymssql.connect(
        server=DB_CONFIG["server"],
        user=DB_CONFIG["user"],
        password=DB_CONFIG["password"],
        database=DB_CONFIG["database"]
    )

def save_chat_to_db(session_id, user_input, assistant_response):
    chat_history = {
        "user_input": user_input,
        "assistant_response": assistant_response
    }

    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT chat_history FROM dbo.WhatsappChat WHERE session_id = %s", (session_id,))
                existing_record = cursor.fetchone()

                if existing_record:
                    existing_chat_history = json.loads(existing_record[0])
                    if isinstance(existing_chat_history, list):
                        existing_chat_history.append(chat_history)
                    else:
                        existing_chat_history = [existing_chat_history, chat_history]
                    trimmed_history = existing_chat_history[-5:]
                    cursor.execute("""
                    UPDATE dbo.WhatsappChat SET chat_history = %s WHERE session_id = %s
                    """, (json.dumps(trimmed_history), session_id))
                else:
                    cursor.execute("""
                    INSERT INTO dbo.WhatsappChat (session_id, chat_history)
                    VALUES (%s, %s)
                    """, (session_id, json.dumps([chat_history])))

            conn.commit()
    except Exception as e:
        print(f"Error saving chat to database: {e}")

def get_chat_history_from_db(session_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT chat_history FROM dbo.WhatsappChat WHERE session_id = %s", (session_id,))
                row = cursor.fetchone()
                return json.loads(row[0]) if row else []
    except Exception as e:
        print(f"Error retrieving chat history: {e}")
        return []